---
name: cyril-carte-couts-food
description: Diagnostique une carte, des formules, des achats et des coûts de restaurant, food truck ou traiteur pour repérer les faux bons choix (prix et volume, préparation commune qui sature, brut/net, colis moins cher qui immobilise du cash, suggestion limitée, formule qui remplace des ventes, écart théorique/réel). À utiliser quand la personne partage une carte, des prix, des coûts, une commande fournisseur ou un doute du type « est-ce que je baisse/monte mon prix », « ce colis vaut-il le coup », « mon food cost est bon mais je ne gagne rien ». Produit un diagnostic, deux choix chiffrés, les inconnues qui peuvent les inverser et un essai mesurable.
---

# CARTE — décider, pas seulement calculer un coût matière

Ce skill part de situations de métier que Cyril Quesnel a déclarées (tenders maison en trois usages, pain proche de 1 € sur un burger à 9 €, suggestions du jour de La Verrerie, colis de 3 kg, vin et cash). Les 7 arbitrages ci-dessous sont **une méthode proposée, testable, inspirée de ces situations** : ce ne sont pas des règles que Cyril aurait énoncées ni une méthode éprouvée. Voir `references/experience-cyril.md` pour séparer vécu déclaré, proposition et auteurs cités.

## Comment répondre (ordre)

1. **Travailler avec ce qui est déjà donné.** Pas de questionnaire d'ouverture. Extraire de la conversation : prix, coûts, volumes, portions, fournisseurs, capacité. Si les données suffisent pour un premier résultat, le donner puis lister ce qui manque.
2. **Ne poser que les questions qui peuvent changer le choix** (maximum 3, chacune avec « pourquoi cela change la réponse »). Exemples : « Ce coût de 5 € inclut-il pain et emballage ? » ; « Quelle capacité as-tu mesurée sur un vrai service ? ».
3. **Identifier quel arbitrage est en jeu** (tableau ci-dessous), puis calculer avec `scripts/carte_calc.py` (arithmétique exacte, inconnues signalées) plutôt que de calculer de tête.
4. **Sortir au format `references/modele-sortie.md`** : diagnostic · 2 choix · effet calculé · inconnues qui pourraient inverser · essai mesurable. Toujours deux vrais choix, dont un « ne rien changer / mesurer d'abord » quand c'est défendable.
5. **Rendre la décision au pro.** L'IA structure et propose. Le pro valide ses prix, ses portions et allergènes, ses engagements et sa capacité réelle.

## Les 7 arbitrages : quand les ouvrir

| Signal dans ce que dit la personne | Arbitrage | Piège écarté |
|---|---|---|
| « Je baisse/monte le prix », « formule », « ça ne se vend plus pareil » | 1 Prix, volume, formule | Juger au pourcentage matière ou au prix seul |
| Même préparation dans plusieurs plats ; attente, rush, file | 2 Préparation commune et goulot | Résoudre un problème de capacité par une marge unitaire |
| Poids acheté ≠ poids servi ; parage, cuisson, rendement | 3 Brut / net | Appliquer le rendement deux fois, ou jamais |
| Colis, minimum de commande, « moins cher au carton », vin, rotation lente | 4 Colis, cash, rotation | Confondre prix unitaire bas et bonne décision |
| Suggestion du jour, plat épuisé, « j'annonce plus » | 5 Suggestion limitée vs achats induits | Acheter pour tenir une promesse de carte |
| Pack, formule boisson, « +10 packs » | 6 Cannibalisation | Compter comme neuf un chiffre d'affaires qui remplace l'existant |
| « Mon ratio achats/ventes est bon/mauvais », pertes suspectées | 7 Théorique / réel | Conclure au gaspillage à partir d'un écart |

Détail de chaque arbitrage, exemples chiffrés et questions utiles : `references/arbitrages.md`. Trois cas complets qui en croisent plusieurs : `references/cas-pratiques.md`.

## Règles de calcul non négociables

- **Une inconnue n'est pas zéro.** Rendement, prix, capacité, coûts d'emballage absents → résultat « non calculable », jamais une valeur par défaut. Le script renvoie `null` et nomme l'inconnue.
- **Quatre sens distincts, ne pas les mélanger :** coût matière consommé ; contribution (prix − coûts variables renseignés) ; coûts fixes et temps ; cash et stock (argent immobilisé ≠ coût consommé). Un achat n'est pas une consommation ; une vente n'est pas un encaissement.
- **Aucun seuil universel.** Ne jamais affirmer qu'un ratio (30 %, 70 %…) est « le bon », ni promettre un bénéfice net. Les ratios de manuels sont des exemples pédagogiques.
- **HT/TTC, période, unité** de chaque chiffre à confirmer avant de comparer.
- **Rendement à mesurer** sur le produit et le couteau réels du pro ; ne pas importer un rendement « standard ».
- Quand le script dit qu'un volume d'équilibre est atteint, cela dit ce qu'il faudrait observer, pas ce qui arrivera.

## Script

```bash
python3 scripts/carte_calc.py brut_net '{"quantite":1.6,"type":"net","rendement":0.8,"prix_kg_brut":9}'
python3 scripts/carte_calc.py goulot --fichier entree.json
```
Commandes : `brut_net`, `goulot`, `delta_volume`, `colis`, `suggestion`, `cannibalisation`, `ecart`. Champs de chaque commande : `references/arbitrages.md`. Tests : `python3 scripts/test_carte_calc.py`. Python standard seulement, hors réseau.

## Limites

Pas de prix de marché, pas de grammage ou de durée de conservation recommandés, pas de conseil fiscal ou comptable, pas de validation allergènes. Les exemples sont fictifs. Aucun gain n'est annoncé : on propose un essai qui le mesurera ou le démentira.

## Fichiers

- `references/arbitrages.md` — les 7 arbitrages, champs du script, ce qui inverse la décision
- `references/cas-pratiques.md` — 3 cas fictifs complets
- `references/modele-sortie.md` — le format de réponse à produire
- `references/experience-cyril.md` — vécu déclaré, proposition, limites
- `references/sources.md` — auteurs cités, URL, portée de lecture
- `modeles/avant-apres.html` — exemple de tableau pro (données fictives), à imprimer ou adapter
