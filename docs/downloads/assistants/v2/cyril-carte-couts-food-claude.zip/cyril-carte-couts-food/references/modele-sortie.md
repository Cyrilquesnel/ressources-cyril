# Modèle de réponse (à reproduire)

Format court. Chaque section répond à une décision.

```
CARTE — <nom du pro / de l'offre> — <date>   (données : celles que tu m'as données ; marqué ? si estimé)

1. DIAGNOSTIC (3 lignes max)
   Ce que je constate, et le faux bon choix à éviter.

2. DEUX CHOIX
   A. <choix>  — ce qu'il suppose
   B. <choix, dont « mesurer d'abord » si pertinent>  — ce qu'il suppose

3. EFFET CALCULÉ (script, hypothèses nommées)
   | | A | B |
   contribution / cash / capacité / stock selon le cas — avec unités et période.
   Hypothèses reprises : <liste>.

4. INCONNUES QUI POURRAIENT INVERSER
   - <inconnue> → si <valeur>, le choix B devient meilleur.

5. ESSAI MESURABLE
   Quoi changer, sur quelle durée/combien de services, ce qu'on relève (ventes, attente, restes, cash), 
   et le seuil qui fait dire « on garde » ou « on arrête » — fixé AVANT l'essai.

À TOI DE VALIDER : prix, portions et allergènes, capacité, engagements fournisseurs.
```

Règles : pas de bénéfice net annoncé ; pas de « bon ratio » ; une inconnue reste une inconnue ; seuil d'essai défini par le pro. Si une donnée manque, écrire « non calculable : il manque X » au lieu de la remplacer par une valeur.
