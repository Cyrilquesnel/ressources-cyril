# Sources — consultées le 10 novembre 2026 (voir SOURCES-MARGE-PILOTAGE.md du lot bibliothèque)

Mécanismes reformulés ; aucun contenu redistribué. Les exemples chiffrés des sources ne sont pas des repères français.

| Réf. | Source | URL | Lu | Mécanisme retenu | Limite |
|---|---|---|---|---|---|
| M1 | BC Cook Articulation Committee, *Basic Kitchen and Food Service Management*, ch. 15 « Principles of Menu Engineering » (BCcampus, 2015, CC BY 4.0) | https://opentextbc.ca/basickitchenandfoodservicemanagement/chapter/describe-the-principles-of-menu-engineering/ | Chapitre HTML : calcul de portion, pourcentage matière, contribution, analyse des ventes, limites des moyennes | Chiffrer tous les composants ; regarder ce que chaque vente laisse en euros ET le volume ; moyennes = repères | Exemples en dollars canadiens ; prix − ingrédients ≠ bénéfice net |
| M2 | Sheryl Kimes, eCornell « Menu Design and Engineering » | https://ecornell.cornell.edu/corporate-programs/courses/hospitality-and-foodservice-management/menu-design-and-engineering/ | Page de présentation seulement ; **cours payant non suivi** | Rentabilité et volume vus ensemble ; nom, description et position font partie du choix | Ne démontre aucun résultat ni la méthode complète |
| A1 | Lean Enterprise Institute, *Lean Lexicon* « Inventory » | https://www.lean.org/lexicon-terms/inventory/ | Entrée complète | Un stock a une fonction (tampon) ; relier sa taille aux variations et à la fiabilité amont | Référentiel industriel ; ne prescrit pas de quantité ni de conservation |
| A2 | BCcampus, ch. 9 « Purchasing » | https://opentextbc.ca/basickitchenandfoodservicemanagement/chapter/purchasing/ | Chapitre HTML | Relier commande, portions prévues, stock et prochain réapprovisionnement ; produit décrit pour comparer ; prix bloqué = stabilité contre flexibilité | Exemples canadiens, pas de grammage recommandé |
| A3 | ADEME / IFWC, actions antigaspi restauration collective et hôtellerie (2023) | https://librairie.ademe.fr/agriculture-alimentation-foret-bioeconomie/6318-actions-antigaspi-dans-la-restauration-collective-et-l-hotellerie.html | **Notice seulement ; rapport de 27 p. non obtenu** | Définir comment mesurer avant de comparer ; rôle des portions | Aucun pourcentage transposable ; pas de « méthode ADEME » inventée |

Aucune source n'établit un ratio universel, un bénéfice net, un prix de marché ni la méthode de Cyril. Contribution, volume d'équilibre, goulot, cannibalisation sont des **propositions de ce skill** (voir `experience-cyril.md` § 2).
