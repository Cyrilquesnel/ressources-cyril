# Les 7 arbitrages — méthode proposée

Nature : **proposition de décision, testable**, adaptée aux indépendants. Inspirée de situations déclarées par Cyril ; ce n'est pas sa méthode historique. Tous les chiffres ci-dessous sont **fictifs** et servent à montrer le raisonnement. Commande du script entre crochets.

Pour chaque arbitrage : le faux bon choix, le calcul, ce qui inverse la décision, la question utile.

---

## 1. Qualité / prix / formule, et effet d'une baisse de volume  [`delta_volume`]

**Faux bon choix :** « Si je monte mon prix, je perds des clients, donc je ne touche pas » — ou l'inverse, « mon pourcentage matière baisse, donc c'est bon ».

**Calcul fictif (unités explicites, € HT).** Ancien prix unitaire 12,00 € ; coût variable unitaire 5,00 € ; 100 ventes. Contribution unitaire 7,00 € × 100 = **700,00 €**. Nouveau prix unitaire 13,00 € (coût variable inchangé 5,00 €) ; 80 ventes observées : 8,00 € × 80 = **640,00 €**, soit **60,00 € de moins** malgré un prix plus haut (le CA passe de 1 200,00 € à 1 040,00 €). Pour **dépasser** 700,00 € avec 8,00 € par vente : 700 / 8 = **87,5 ventes** (point d'équilibre théorique) ; l'entier strictement supérieur est **88 ventes**. Avec 80 ventes, il en manque 8 ; un recul de 100 à 88 ventes (−12 %) suffit à faire mieux, un recul à 80 (−20 %) ne suffit pas.
Dans l'autre sens, baisser le prix unitaire de 12,00 € à 10,80 € ramène la contribution unitaire de 7,00 € à 5,80 € ; le script donne le volume à atteindre pour compenser.

**Ce qui inverse :** le coût variable réel (pain, emballage, sauce inclus) ; les ventes associées perdues avec le plat (boisson, dessert) ; la capacité si le volume monte ; l'image de qualité. Si la qualité du produit baisse pour tenir un prix (pain « à 0,50 € »), les clients qui partent ne reviennent pas forcément : à tester, pas à supposer.
**Question utile :** « Ton coût de 5 € contient quoi exactement, pain et emballage compris ? Et que prennent les clients avec ce plat ? »
**Marges nulles ou négatives :** si la nouvelle contribution unitaire est ≤ 0 (`statut: nouvelle_marge_non_positive`) ou si l'ancien résultat est ≤ 0 (`statut: reference_non_positive`, ex. prix 6, coût 8, 25 ventes = −50,00 €), le script ne rend ni volume d'équilibre ni pourcentage de baisse tolérable (`null`) et demande de revoir l'offre. Zéro vente « dépasse » un résultat négatif, mais ce n'est pas une recommandation commerciale.
**Entrée script :** `prix_avant, cout_variable_avant, volume_avant, prix_apres` ; optionnels `cout_variable_apres, volume_apres`. Sans `volume_apres` : seuls le point d'équilibre (`volume_equilibre_theorique`, 87,50) et le plus petit entier strictement supérieur (`volume_minimum_pour_depasser`, 88) sont calculés.

---

## 2. Préparation commune et goulot  [`goulot`]

**Faux bon choix :** « Les tenders servent trois plats, donc c'est rentable » — en regardant la marge unitaire de chaque plat.

**Calcul fictif.** Dans un créneau : 8 burgers + 4 tapas à 1,5 portion + 3 menus enfant = 8 + 6 + 3 = **17 portions** de la même préparation. Capacité mesurée du poste : 12. **5 portions attendent.** Une marge unitaire plus haute ne crée aucune capacité ; ce sont l'étalement, la limitation d'une déclinaison, la préparation en amont ou un second poste qui jouent.

**Ce qui inverse :** capacité mal mesurée (à chronométrer sur un vrai service) ; part de la préparation faisable en avance sans perte de qualité ; la déclinaison qui consomme le plus de capacité par euro de contribution (comparer contribution **par portion de capacité**, pas par plat).
**Question utile :** « Combien de portions sort ce poste en un créneau quand tout va bien, mesuré ? Qu'est-ce qui attend quand ça sature ? »
**Entrée :** `capacite_mesuree, lignes[{nom, quantite, portions_par_unite}]`. Un poids par unité manquant est signalé, la ligne est exclue et le total devient un minimum.

---

## 3. Brut / net / rendement  [`brut_net`]

**Faux bon choix :** coûter la recette au poids net avec le prix du brut ; ou appliquer le rendement deux fois.

**Calcul fictif.** Besoin net 1,6 kg, rendement 80 % : brut = 1,6 / 0,8 = **2 kg** ; à 9 €/kg : **18 €**. Si la fiche contient déjà 2 kg bruts, ne pas diviser encore : le script (`type: "brut"`) n'applique pas le rendement une seconde fois et ne l'utilise que pour déduire le net.

**Ce qui inverse :** le rendement réel (mesuré, par fournisseur et par parage) ; l'usage des parures ; les pertes de cuisson distinctes du parage.
**Question utile :** « La quantité de ta fiche est-elle en brut (acheté) ou en net (dans l'assiette) ? Quel rendement as-tu mesuré ? »
**Entrée :** `quantite, type ("net"|"brut"), rendement (fraction 0–1), prix_kg_brut`. Net sans rendement = refusé.

---

## 4. Colis moins cher, cash et rotation  [`colis`]

**Faux bon choix :** « Le carton de 12 est moins cher à l'unité, je le prends. »

**Calcul fictif.** 12 bouteilles à 28 = **336** contre 6 à 30 = **180**. Le grand colis décaisse **156 de plus** ; l'autre option coûte **2 de plus par bouteille**, soit 12 sur 6 bouteilles. Selon le besoin jusqu'au prochain achat (par ex. 5 bouteilles), 7 bouteilles du grand colis restent en stock (196 immobilisés) contre 1 (30). **Un surplus est un stock, pas une perte certaine** : il devient perte s'il ne se vend pas, vieillit ou casse la trésorerie.

**Ce qui inverse :** rotation réelle ; durée de vie ; prochain créneau de livraison ; coût de l'argent et des autres décaissements du mois ; possibilité de marché / cash & carry / proximité pour les faibles rotations (options à comparer, pas à imposer).
**Question utile :** « Combien en vends-tu avant la prochaine commande possible ? Que peut-il se passer d'autre sur ta trésorerie ce mois-ci ? »
**Entrée :** `options[{nom, unites, prix_unitaire}]`, `besoin_unites_jusqu_au_prochain_achat` (sans lui, surplus inconnu).

---

## 5. Suggestion limitée contre achats induits  [`suggestion`]

**Faux bon choix :** annoncer 12 portions parce que « la suggestion marche bien », alors qu'on n'en a que 8 de validées.

**Calcul fictif.** 1,2 kg utilisable validé / 150 g = **8 portions**. En annoncer 12 demande **0,6 kg de plus**, donc un achat arrondi au colis, avec un reste. Le manque se calcule **en masse** avant l'arrondi au colis, sans jeter les fractions : par exemple 6 portions de 0,18 kg avec 0,95 kg validé → besoin 0,13 kg → 1 colis de 0,15 kg, 1,50 € à 10 €/kg, surplus 0,02 kg (et non une portion complète de 0,18 kg). L'ingrédient déjà acheté **garde son coût** même s'il n'est pas vendu : « utilisable » est une décision du pro (parage, date, qualité), pas un calcul de l'assistant.
Alternative : annoncer 8 et basculer sur autre chose quand c'est fini (ce que Cyril décrit pour La Verrerie), ce qui limite l'achat induit mais suppose une alternative prête.

**Ce qui inverse :** le reste a-t-il un autre usage dans la semaine (réemploi dans une autre recette) ? La demande réelle dépasse-t-elle 8 ? Le coût de l'alternative ?
**Entrée :** `quantite_utilisable_validee, grammage_portion, portions_annoncees` ; optionnels `prix_unitaire_achat, taille_colis`.

---

## 6. Formule additionnelle et cannibalisation  [`cannibalisation`]

**Faux bon choix :** « Le pack boisson a fait 54 de CA, c'est 54 de gagné ».

**Calcul fictif.** Avant : 20 boissons × 2,20 = **44**. Après : 30 packs × 1,80 = **54**. Le supplément est **10**, pas 54, si les packs remplacent les 20 ventes d'avant. Avec un coût variable de 0,60 par unité (fictif), la contribution passe de 32 à 36 : **+4**.

**Ce qui inverse :** la part des ventes d'avant qui migre vers la formule ; le coût variable de chaque version ; le volume d'achats de plats lié à la formule ; la durée d'observation.
**Question utile :** « Avant la formule, combien de clients prenaient déjà la boisson seule ? »
**Entrée :** `unites_avant, prix_avant, unites_apres, prix_apres` ; optionnels `cout_variable_avant, cout_variable_apres`.

---

## 7. Théorique / réel  [`ecart`]

**Faux bon choix :** « J'ai un écart, donc on gaspille. » Ou : « Mes achats/ventes sont bons, donc tout va bien. »

**Calcul fictif.** 100 plats × 2 = 200 de consommation théorique. Stock initial 400 + achats 300 − stock final 450 = **250 consommés**. Écart **50** à expliquer. Pistes : portions plus généreuses, recette pas à jour, inventaire incomplet ou valorisé autrement, livraison non saisie, offerts et repas du personnel, ventes non passées en caisse, pertes réelles. Le rapport achats / ventes ne tient pas compte de la variation de stock : il ne dit pas ce qui a été consommé.

**Ce qui inverse :** la qualité de l'inventaire ; les offerts non enregistrés. Mesurer pertes et restes sur quelques services avant d'agir.
**Entrée :** `unites_vendues, cout_theorique_unitaire, stock_initial, achats, stock_final` ; optionnels `offerts_et_repas_personnel, pertes_declarees`.

---

## Croisements fréquents

- 1 + 2 : une hausse de prix augmente la contribution mais le volume qu'elle retient sature le poste → vérifier la capacité.
- 3 + 4 : un colis moins cher au kilo brut qui rend moins au parage → comparer le coût par kilo net.
- 5 + 4 + 7 : le plat du jour oblige un achat par colis, le reste gonfle le stock, l'écart théorique/réel augmente.
- 6 + 1 : une formule à prix réduit baisse la contribution unitaire ; à compenser par du volume réel, pas du volume déplacé.
