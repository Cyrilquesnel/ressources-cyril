# Trois natures à ne pas confondre

Source : `strategie-3-mois/references/faits-editoriaux-vocaux-2026-11-10.md` et `reponses-integrales-cyril-2026-11-10.md`. Déclarations non vérifiées indépendamment ; aucun résultat chiffré n'est fourni par Cyril sur ces sujets.

## 1. Expérience déclarée par Cyril (vécu)

- Reprise du Lunch Wagon : burgers à 9 €, ticket moyen 11–12 €, pain de boulanger proche de 1 € pièce ; marges jugées trop faibles face au travail du fait maison.
- Il juge un pain à 0,50 € incompatible avec la qualité recherchée (opinion personnelle, pas un minimum universel) et a gardé la qualité en changeant carte, nouveautés, formules.
- Tenders de poulet : aiguillettes fraîches panées à l'anglaise aux cornflakes, déclinées en version enfant, tapas/snack et burger ; il évoque 15 à 20 kg lors de certains soirs d'événement (poids non précisé, pas de ventes ni de bénéfice). Formules avec dessert ou boisson.
- La Verrerie : menu midi à 15 € en deux éléments (entrée + plat OU plat + dessert) ; cabillaud, gambas pour renouveler les produits ; suggestions du jour, bascule quand le plat est épuisé ; portions, pertes et personnel surveillés. « Zéro perte » est un objectif, pas un résultat mesuré.
- Achats : colis de 3 kg (tomates, tomates cerises) vs besoin de 500 g ; options marché, Metro, Promocash, proximité pour les faibles rotations ; prix bloqués ; RFA évoquées avec 30–40 000 € d'achats annuels par fournisseur comme **son ordre de grandeur, pas un seuil**.
- Pilotage : prévisionnel Excel et repère de CA par employé ; ratio de matière = total des achats / ventes ; recherche de rapprochement théorique/réel ; lutte contre la perte ; bar à tapas et hôtel-restaurant, belle cave et bouteilles de Bourgogne qui font monter le stock vite ; conseil d'ajuster les commandes à la trésorerie.

## 2. Méthode proposée par ce skill (non attribuée à Cyril)

Les 7 arbitrages de `arbitrages.md` : contribution et volume d'équilibre, goulot, brut/net, comparaison colis/cash, suggestion limitée, cannibalisation, écart théorique/réel. **Ils s'inspirent** de ces situations mais sont des propositions testables pour des indépendants, pas la méthode personnelle historique de Cyril et pas une méthode éprouvée.

Points précis où la proposition **va plus loin** que ce que Cyril a dit : le calcul par contribution et par volume d'équilibre ; la comparaison par capacité de poste ; la distinction stock immobilisé / coût consommé ; l'inventaire pour rapprocher théorique et réel. Cyril décrit son ratio achats/ventes ; la proposition ajoute la variation de stock.

## 3. Mécanisme d'un auteur cité

Voir `sources.md` (BCcampus, Kimes/eCornell, Lean Enterprise Institute, ADEME) avec URL et portée de lecture. Les supports ne sont pas redistribués.

## Ce qui manque pour refléter tout son jugement

Cartes, coûts et ventes datés du Lunch Wagon et de La Verrerie ; la fiche de coût réelle des tenders ; capacité mesurée de son poste de friture ; sa règle personnelle de prix quand elle existe (non fournie) ; un exemple de colis réellement refusé ou accepté ; ses seuils d'arrêt d'un essai. Tant qu'ils manquent, le skill demande ces données au pro au lieu de les inventer.
