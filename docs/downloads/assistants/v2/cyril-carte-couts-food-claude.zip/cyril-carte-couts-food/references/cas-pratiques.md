# Trois cas fictifs complets

Tous les noms, prix et volumes sont inventés pour tester le skill. Ils ne décrivent ni Cyril, ni un client réel, ni un marché. Chaque cas : entrée donnée, réponse attendue, raison des choix. Les chiffres sont reproductibles avec `scripts/carte_calc.py`.

---

## Cas 1 — « Le Braisé Test » (food truck fictif) : poulet maison en trois usages

**Entrée de la personne.** « Je fais des tenders maison : burger à 9 €, tapas, menu enfant. Mon burger me coûte 3,60 € (pain, poulet, sauce, emballage). J'en vends 400 par mois. Je pense passer à 10 €, mais je crains de perdre des clients. Les soirs d'événement, ça sature. Pour un créneau : 10 burgers, 5 tapas à 1,5 portion, 4 enfants, mon poste en sort 20 mesurées. J'achète 6 kg nets d'aiguillettes par soirée, rendement 85 % mesuré, brut à 11 €/kg. »

**Arbitrages croisés :** 1 (prix/volume), 2 (goulot), 3 (brut/net).

**Calculs.**
- Brut/net : 6 / 0,85 = **7,059 kg bruts → 77,65 €** (12,94 €/kg net).
- Goulot : 10 + 5×1,5 + 4 = **21,5 portions** pour 20 → **1,5 portion en attente**, saturation 1,08.
- Prix burger : 9 → 10, coût 3,60 : contribution unitaire 5,40 → 6,40. Contribution 2 160 → **2 368** (+208) à 370 ventes ; volume d'équilibre **338** (recul tolérable 62 ventes, 15,5 %).

**Réponse attendue.**
- *Diagnostic :* le prix est un vrai levier, mais le problème des soirs d'événement n'est pas la marge : la préparation commune dépasse le poste de 1,5 portion. Monter le prix ne règle pas l'attente ; le volume retenu non plus.
- *Choix A — passer le burger à 10 € :* contribution supérieure tant que les ventes restent au-dessus de 338 ; effet sur la capacité : légèrement favorable si le volume baisse. Suppose que le coût de 3,60 € est complet.
- *Choix B — garder 9 €, limiter les tapas en soirée saturée (par ex. portion 1 ou précuisson) :* règle l'attente de 1,5 portion ; contribution inchangée si les ventes tiennent ; suppose que la qualité tient.
- *Inconnues qui inversent :* le coût réel du pain (si 1 € et non 0,60, le coût du burger monte et l'effet change) ; la part des clients qui prennent aussi boisson/dessert ; la capacité du poste, mesurée sur un seul soir ?
- *Essai :* 4 semaines à 10 € sur un seul point de vente ou jour ; relever ventes de burgers, ventes associées, attente en rush. Seuil défini avant : contribution ≥ celle d'avant, et attente ≤ X portions (décidé par le pro). Pour l'attente : un essai séparé, pas simultané, pour ne pas mélanger les causes.
- *Piège refusé :* conclure que « 10 € est mieux » sans connaître les ventes associées ; ou compter 77,65 € comme coût d'une portion sans rapporter à 7 kg bruts.

---

## Cas 2 — « Le Comptoir Test » (bistrot fictif) : suggestion du jour et écart

**Entrée.** « Midi à 15 € en deux éléments. Je veux annoncer 14 portions de dorade en suggestion. J'ai 1,8 kg utilisable validé, 150 g par portion. La dorade vient en colis de 2 kg à 24 €/kg. Ce mois : 60 plats vendus, coût théorique 3,50 € par plat ; stock début 300, achats 420, stock fin 470. Je suis sûr qu'on gaspille. »

**Arbitrages croisés :** 5 (suggestion), 4 (colis), 7 (théorique/réel).

**Calculs.**
- Suggestion : 1,8 / 0,15 = **12 portions possibles** pour 14 annoncées : **2 manquantes → 0,3 kg**. Achat arrondi : **1 colis de 2 kg = 48 €**, **1,7 kg de reste (40,80 € immobilisés)**.
- Écart : théorique 60 × 3,50 = **210** ; réel 300 + 420 − 470 = **250** ; **écart 40 (19,0 %)**.

**Réponse attendue.**
- *Diagnostic :* annoncer 14 force un achat de 48 € pour 2 portions et laisse 40,80 € de stock à écouler. L'écart de 40 est une question, pas une preuve de gaspillage.
- *Choix A — annoncer 12, basculer sur autre chose ensuite :* aucun achat induit ; suppose une alternative prête et un plat de remplacement au coût connu.
- *Choix B — acheter le colis et annoncer 14, avec un réemploi planifié du reste (autre plat de la semaine) :* seulement valable si le reste a un usage daté ; sinon le reste devient perte.
- *Inconnues qui inversent :* la durée de vie du reste ; la demande réelle (14 ou 9 ?) ; offerts et repas du personnel ; qualité de l'inventaire ; portions servies réellement vs 150 g.
- *Essai :* 2 semaines, choix A ; relever restes en fin de service, portions pesées sur 10 assiettes, offerts et repas du personnel notés. Réévaluer l'écart avec ces relevés avant de parler de gaspillage.
- *Piège refusé :* « on gaspille 40 ». Les 40 peuvent venir d'un inventaire valorisé autrement ou de portions 20 % plus généreuses.

---

## Cas 3 — « La Cave Test » : colis, cash et formule boisson

**Entrée.** « Mon fournisseur me propose 12 bouteilles à 28 € ou 6 à 30 €. J'en vends environ 5 avant la prochaine commande possible. Par ailleurs, ma formule boisson : avant 20 boissons à 2,20 € ; depuis la formule, 30 packs à 1,80 €. Coût variable 0,60 € par boisson. La formule me rapporte 54, non ? »

**Arbitrages croisés :** 4 (colis/cash), 6 (cannibalisation), 1 (prix/volume).

**Calculs.**
- Colis : 12×28 = **336** contre 6×30 = **180** ; **156 de cash en moins** sur 6 ; surcoût de 12 sur 6 bouteilles. Avec un besoin de 5 : surplus **7 bouteilles = 196 immobilisés** (grand colis) contre **1 = 30**.
- Formule : CA 44 → 54 ; **supplément 10**, pas 54. Contribution 32 → 36, **+4**.

**Réponse attendue.**
- *Diagnostic :* le grand colis est moins cher à l'unité mais mobilise 196 € pour un besoin de 5 ; la formule ne rapporte pas 54, elle déplace des ventes existantes.
- *Choix A — 6 bouteilles à 30 :* paie 12 de plus sur 6 pour garder 156 de cash ; surplus de 30 seulement.
- *Choix B — 12 à 28 :* gagne 12 sur le prix mais immobilise 196 pour un besoin de 5 ; valable si rotation > 12 avant la date limite (à vérifier) ou si le cash est abondant.
- *Inconnues qui inversent :* la rotation réelle et la durée de vie ; l'autre décaissement du mois ; la part des 20 anciens clients passés à la formule (si 100 %, la formule déplace tout et ne gagne que 4) ; ce que les packs font aux ventes de plats.
- *Essai :* colis A deux cycles de commande ; relever bouteilles vendues par semaine. Formule : comparer sur 4 semaines le total (plats + boissons), pas les boissons seules.
- *Piège refusé :* « surplus = perte » ; « formule = +54 ».

---

## Test de comparaison avec une réponse générique

Une réponse générique à « calcule mon food cost du burger » donne : coût / prix. Elle ne signale pas : que les 3,60 € dépendent du pain et de l'emballage ; que la saturation vient de la préparation commune ; que la hausse de prix s'évalue par contribution et volume d'équilibre (338) ; que 77,65 € correspond à 7,059 kg bruts. Le skill se juge sur ces décisions modifiées, pas sur la longueur.
