import unittest, carte_calc as c

def run(cmd, data):
    return c.COMMANDES[cmd](data)

class T(unittest.TestCase):
    def test_brut_net_exemple(self):
        r = run("brut_net", {"quantite": 1.6, "type": "net", "rendement": 0.8, "prix_kg_brut": 9})["resultat"]
        self.assertEqual((r["brut_kg"], r["cout_achat_eur"]), ("2.000", "18.00"))
    def test_brut_deja_saisi_pas_de_double_rendement(self):
        o = run("brut_net", {"quantite": 2, "type": "brut", "rendement": 0.8, "prix_kg_brut": 9})
        self.assertEqual(o["resultat"]["brut_kg"], "2.000"); self.assertEqual(o["resultat"]["cout_achat_eur"], "18.00")
        self.assertEqual(o["resultat"]["net_kg"], "1.600")
    def test_net_sans_rendement_refuse(self):
        with self.assertRaises(c.Erreur): run("brut_net", {"quantite": 1.6, "type": "net", "prix_kg_brut": 9})
    def test_prix_inconnu_pas_zero(self):
        o = run("brut_net", {"quantite": 1.6, "type": "net", "rendement": 0.8})
        self.assertIsNone(o["resultat"]["cout_achat_eur"]); self.assertTrue(o["inconnues"])
    def test_rendement_invalide(self):
        with self.assertRaises(c.Erreur): run("brut_net", {"quantite": 1, "type": "net", "rendement": 80})
    def test_goulot(self):
        r = run("goulot", {"capacite_mesuree": 12, "lignes": [
            {"nom": "burger", "quantite": 8, "portions_par_unite": 1},
            {"nom": "tapas", "quantite": 4, "portions_par_unite": 1.5},
            {"nom": "enfant", "quantite": 3, "portions_par_unite": 1}]})["resultat"]
        self.assertEqual((r["total_portions"], r["attente_portions"]), ("17.00", "5.00"))
    def test_goulot_capacite_inconnue(self):
        o = run("goulot", {"lignes": [{"nom": "a", "quantite": 2, "portions_par_unite": 1}]})
        self.assertTrue(any("capacite" in i for i in o["inconnues"]))
    def test_goulot_poids_inconnu_exclu_et_signale(self):
        o = run("goulot", {"capacite_mesuree": 5, "lignes": [{"nom": "a", "quantite": 2, "portions_par_unite": 1}, {"nom": "b", "quantite": 9}]})
        self.assertEqual(o["resultat"]["total_portions"], "2.00"); self.assertTrue(o["inconnues"])
    def test_delta_volume(self):
        r = run("delta_volume", {"prix_avant": 12, "cout_variable_avant": 5, "volume_avant": 100, "prix_apres": 13, "volume_apres": 80})["resultat"]
        self.assertEqual((r["contribution_totale_avant"], r["contribution_totale_apres"], r["delta_contribution"]), ("700.00", "640.00", "-60.00"))
        self.assertEqual((r["volume_equilibre_theorique"], r["volume_minimum_pour_depasser"]), ("87.50", 88))
    def test_delta_volume_entier_exact_depasser_strict(self):
        r = run("delta_volume", {"prix_avant": 12, "cout_variable_avant": 5, "volume_avant": 100, "prix_apres": 12, "volume_apres": 100})["resultat"]
        self.assertEqual((r["volume_equilibre_contribution"], r["volume_minimum_pour_depasser"]), (100, 101))
    def test_delta_volume_nouvelle_marge_nulle_ancienne_positive(self):
        o = run("delta_volume", {"prix_avant": 12, "cout_variable_avant": 5, "volume_avant": 10, "prix_apres": 5})
        r = o["resultat"]
        self.assertEqual(r["statut"], "nouvelle_marge_non_positive")
        self.assertIsNone(r["volume_minimum_pour_depasser"]); self.assertIsNone(r["baisse_tolerable_pct"])
        self.assertTrue(any("revoir" in a for a in o["avertissements"]))
    def test_delta_volume_nouvelle_marge_negative_ancienne_positive(self):
        r = run("delta_volume", {"prix_avant": 12, "cout_variable_avant": 5, "volume_avant": 10, "prix_apres": 4, "volume_apres": 10})["resultat"]
        self.assertEqual(r["statut"], "nouvelle_marge_non_positive")
        self.assertIsNone(r["volume_equilibre_theorique"]); self.assertEqual(r["delta_contribution"], "-80.00")
    def test_delta_volume_ancien_resultat_negatif(self):
        o = run("delta_volume", {"prix_avant": 6, "cout_variable_avant": 8, "volume_avant": 25, "prix_apres": 10, "cout_variable_apres": 8})
        r = o["resultat"]
        self.assertEqual(r["contribution_totale_avant"], "-50.00"); self.assertEqual(r["statut"], "reference_non_positive")
        for k in ("volume_equilibre_theorique", "volume_equilibre_contribution", "volume_minimum_pour_depasser", "baisse_de_volume_tolerable", "baisse_tolerable_pct"):
            self.assertIsNone(r[k], k)
        self.assertTrue(any("revoir l'offre" in a for a in o["avertissements"]))
    def test_delta_volume_ancien_negatif_avec_volume_apres(self):
        r = run("delta_volume", {"prix_avant": 6, "cout_variable_avant": 8, "volume_avant": 25, "prix_apres": 10, "cout_variable_apres": 8, "volume_apres": 10})["resultat"]
        self.assertEqual((r["contribution_totale_apres"], r["delta_contribution"]), ("20.00", "70.00"))
    def test_delta_volume_deux_marges_non_positives(self):
        r = run("delta_volume", {"prix_avant": 6, "cout_variable_avant": 8, "volume_avant": 25, "prix_apres": 7, "cout_variable_apres": 8})["resultat"]
        self.assertEqual(r["statut"], "nouvelle_marge_non_positive"); self.assertIsNone(r["volume_minimum_pour_depasser"])
    def test_suggestion_reliquat_fractionnaire(self):
        r = run("suggestion", {"quantite_utilisable_validee": 0.95, "grammage_portion": 0.18, "portions_annoncees": 6, "taille_colis": 0.15, "prix_unitaire_achat": 10})["resultat"]
        self.assertEqual(r["quantite_a_acheter_en_plus"], "0.130")
        self.assertEqual((r["colis_a_acheter"], r["cash_achat_induit"], r["reste_apres_service"]), (1, "1.50", "0.020"))
    def test_suggestion_sans_colis_masse_exacte(self):
        r = run("suggestion", {"quantite_utilisable_validee": 0.95, "grammage_portion": 0.18, "portions_annoncees": 6, "prix_unitaire_achat": 10})["resultat"]
        self.assertEqual((r["quantite_a_acheter_en_plus"], r["cash_achat_induit_minimum"]), ("0.130", "1.30"))
    def test_suggestion_stock_suffisant(self):
        r = run("suggestion", {"quantite_utilisable_validee": 1.2, "grammage_portion": 0.15, "portions_annoncees": 8, "taille_colis": 2})["resultat"]
        self.assertEqual(r["quantite_a_acheter_en_plus"], "0.000"); self.assertNotIn("colis_a_acheter", r)
    def test_colis(self):
        r = run("colis", {"besoin_unites_jusqu_au_prochain_achat": 6, "options": [
            {"nom": "12x28", "unites": 12, "prix_unitaire": 28}, {"nom": "6x30", "unites": 6, "prix_unitaire": 30}]})["resultat"]
        self.assertEqual(r["difference_cash_a_moins_b"], "156.00")
        self.assertEqual(r["options"][0]["cash_immobilise_au_dela_du_besoin"], "168.00")
        self.assertEqual(r["options"][1]["cash_immobilise_au_dela_du_besoin"], "0.00")
    def test_colis_besoin_inconnu(self):
        o = run("colis", {"options": [{"unites": 12, "prix_unitaire": 28}, {"unites": 6, "prix_unitaire": 30}]})
        self.assertNotIn("difference_cash_a_moins_b", o["resultat"]); self.assertTrue(o["inconnues"])
    def test_suggestion(self):
        r = run("suggestion", {"quantite_utilisable_validee": 1.2, "grammage_portion": 0.15, "portions_annoncees": 12})["resultat"]
        self.assertEqual((r["portions_possibles_avec_le_stock"], r["portions_manquantes"], r["quantite_a_acheter_en_plus"]), (8, 4, "0.600"))
    def test_cannibalisation(self):
        r = run("cannibalisation", {"unites_avant": 20, "prix_avant": 2.2, "unites_apres": 30, "prix_apres": 1.8})["resultat"]
        self.assertEqual((r["ca_avant"], r["ca_apres"], r["supplement_reel_de_ca"]), ("44.00", "54.00", "10.00"))
    def test_ecart(self):
        r = run("ecart", {"unites_vendues": 100, "cout_theorique_unitaire": 2, "stock_initial": 400, "achats": 300, "stock_final": 450})["resultat"]
        self.assertEqual((r["consomme_theorique"], r["consomme_reel"], r["ecart"]), ("200.00", "250.00", "50.00"))
    def test_ecart_stock_incoherent(self):
        with self.assertRaises(c.Erreur): run("ecart", {"unites_vendues": 1, "cout_theorique_unitaire": 1, "stock_initial": 1, "achats": 1, "stock_final": 5})
    def test_refus_negatif_booleen(self):
        with self.assertRaises(c.Erreur): run("goulot", {"capacite_mesuree": -1, "lignes": [{"quantite": 1, "portions_par_unite": 1}]})
        with self.assertRaises(c.Erreur): run("ecart", {"unites_vendues": True, "cout_theorique_unitaire": 1, "stock_initial": 1, "achats": 1, "stock_final": 1})
    def test_cas_pratiques(self):
        self.assertEqual(run("brut_net", {"quantite": 6, "type": "net", "rendement": 0.85, "prix_kg_brut": 11})["resultat"]["cout_achat_eur"], "77.65")
        g = run("goulot", {"capacite_mesuree": 20, "lignes": [{"nom": "b", "quantite": 10, "portions_par_unite": 1}, {"nom": "t", "quantite": 5, "portions_par_unite": 1.5}, {"nom": "e", "quantite": 4, "portions_par_unite": 1}]})["resultat"]
        self.assertEqual(g["attente_portions"], "1.50")
        v = run("delta_volume", {"prix_avant": 9, "cout_variable_avant": 3.6, "volume_avant": 400, "prix_apres": 10, "volume_apres": 370})["resultat"]
        self.assertEqual((v["volume_equilibre_contribution"], v["delta_contribution"]), (338, "208.00"))
        s = run("suggestion", {"quantite_utilisable_validee": 1.8, "grammage_portion": 0.15, "portions_annoncees": 14, "prix_unitaire_achat": 24, "taille_colis": 2})["resultat"]
        self.assertEqual((s["cash_achat_induit"], s["valeur_du_reste_immobilisee"]), ("48.00", "40.80"))
        e = run("ecart", {"unites_vendues": 60, "cout_theorique_unitaire": 3.5, "stock_initial": 300, "achats": 420, "stock_final": 470})["resultat"]
        self.assertEqual((e["ecart"], e["ecart_en_pct_du_theorique"]), ("40.00", "19.0"))
        k = run("cannibalisation", {"unites_avant": 20, "prix_avant": 2.2, "unites_apres": 30, "prix_apres": 1.8, "cout_variable_avant": 0.6, "cout_variable_apres": 0.6})["resultat"]
        self.assertEqual(k["delta_contribution"], "4.00")
    def test_cli_json_invalide(self):
        self.assertEqual(c.main(["x", "goulot", "{pas json"]), 1)

if __name__ == "__main__":
    unittest.main()
