#!/usr/bin/env python3
"""Calculs déterministes du skill cyril-carte-couts-food (stdlib, Decimal, hors réseau).

Usage : python3 carte_calc.py <commande> '<json>'   (ou --fichier f.json, ou '-' pour stdin)
Commandes : brut_net, goulot, delta_volume, colis, suggestion, cannibalisation, ecart

Règles : une donnée absente ou null est INCONNUE (jamais zéro) ; le résultat qui en dépend vaut null
et la clé "inconnues" la nomme. Aucune valeur par défaut de rendement, de prix ou de seuil.
Sortie : JSON {"ok":..., "resultat":{...}, "inconnues":[...], "avertissements":[...]}.
"""
import json
import sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, ROUND_CEILING, ROUND_FLOOR

Q2 = Decimal("0.01")


class Erreur(Exception):
    pass


def d(v, nom, positif=False, strict=False):
    """Convertit en Decimal ; None -> None (inconnue). Refuse négatif, NaN, booléen."""
    if v is None:
        return None
    if isinstance(v, bool):
        raise Erreur(f"{nom} : booléen non accepté")
    try:
        x = Decimal(str(v))
    except InvalidOperation:
        raise Erreur(f"{nom} : nombre invalide ({v!r})")
    if not x.is_finite():
        raise Erreur(f"{nom} : valeur non finie")
    if x < 0:
        raise Erreur(f"{nom} : valeur négative interdite ({x})")
    if (positif or strict) and x == 0:
        raise Erreur(f"{nom} : doit être > 0")
    return x


def req(data, nom, **kw):
    v = d(data.get(nom), nom, **kw)
    if v is None:
        raise Erreur(f"{nom} : donnée obligatoire manquante (une inconnue n'est pas zéro)")
    return v


def r2(x):
    return None if x is None else str(x.quantize(Q2, rounding=ROUND_HALF_UP))


def rn(x, places="0.001"):
    return None if x is None else str(x.quantize(Decimal(places), rounding=ROUND_HALF_UP))


def ceil_int(x):
    return int(x.to_integral_value(rounding=ROUND_CEILING))


def sortie(res, inconnues=None, avert=None):
    return {"ok": True, "resultat": res, "inconnues": inconnues or [], "avertissements": avert or []}


# 1 — brut / net / rendement -------------------------------------------------
def brut_net(data):
    qte = req(data, "quantite", positif=True)
    typ = data.get("type")
    if typ not in ("net", "brut"):
        raise Erreur('type : "net" (besoin utilisable) ou "brut" (déjà acheté/saisi en brut) obligatoire')
    rend = d(data.get("rendement"), "rendement")
    prix = d(data.get("prix_kg_brut"), "prix_kg_brut")
    if rend is not None and not (Decimal(0) < rend <= 1):
        raise Erreur("rendement : fraction entre 0 (exclu) et 1 (ex. 0.8 pour 80 %)")
    inc, av = [], []
    if typ == "net":
        if rend is None:
            raise Erreur("rendement obligatoire pour passer du net au brut (pas de 100 % par défaut)")
        brut, net = qte / rend, qte
    else:
        brut, net = qte, (qte * rend if rend is not None else None)
        av.append("Quantité déjà en brut : le rendement n'est PAS appliqué une seconde fois.")
        if net is None:
            inc.append("rendement (net utilisable non calculable)")
    cout = brut * prix if prix is not None else None
    if prix is None:
        inc.append("prix_kg_brut (coût d'achat non calculable)")
    return sortie({"brut_kg": rn(brut), "net_kg": rn(net), "cout_achat_eur": r2(cout),
                   "cout_par_kg_net_eur": r2(cout / net) if (cout is not None and net) else None}, inc, av)


# 2 — goulot -----------------------------------------------------------------
def goulot(data):
    cap = d(data.get("capacite_mesuree"), "capacite_mesuree", positif=True)
    lignes = data.get("lignes")
    if not isinstance(lignes, list) or not lignes:
        raise Erreur("lignes : liste non vide obligatoire")
    total, detail, inc, av = Decimal(0), [], [], []
    for i, l in enumerate(lignes):
        nom = l.get("nom", f"ligne{i+1}")
        q = req(l, "quantite")
        p = d(l.get("portions_par_unite"), f"{nom}.portions_par_unite", positif=True)
        if p is None:
            inc.append(f"{nom}.portions_par_unite (ligne exclue du total : le total est un MINIMUM)")
            continue
        total += q * p
        detail.append({"nom": nom, "portions": rn(q * p, "0.01")})
    res = {"total_portions": rn(total, "0.01"), "detail": detail}
    if cap is None:
        inc.append("capacite_mesuree (à mesurer sur un vrai service, pas à déduire d'une fiche)")
        res.update(attente=None, taux_saturation=None)
    else:
        res["attente_portions"] = rn(max(Decimal(0), total - cap), "0.01")
        res["taux_saturation"] = rn(total / cap, "0.01")
        if total > cap:
            av.append("Le goulot est une capacité de poste : une marge unitaire plus haute ne la libère pas. "
                      "Pistes à chiffrer : étaler, limiter une déclinaison, préparer en amont, ajouter un poste.")
    return sortie(res, inc, av)


# 3 — effet d'un changement de prix sur le volume ----------------------------
def delta_volume(data):
    pa, ca, va = req(data, "prix_avant"), req(data, "cout_variable_avant"), req(data, "volume_avant", positif=True)
    pn = req(data, "prix_apres")
    cn = d(data.get("cout_variable_apres"), "cout_variable_apres")
    vn = d(data.get("volume_apres"), "volume_apres")
    inc, av = [], []
    if cn is None:
        cn = ca
        av.append("cout_variable_apres absent : le coût d'avant est reconduit (à confirmer : portion, emballage, perte).")
    mba, mbn = pa - ca, pn - cn
    contrib_av = mba * va
    res = {"contribution_unitaire_avant": r2(mba), "contribution_unitaire_apres": r2(mbn),
           "contribution_totale_avant": r2(contrib_av), "ca_avant": r2(pa * va),
           "statut": "normal", "volume_equilibre_theorique": None, "volume_equilibre_contribution": None,
           "volume_minimum_pour_depasser": None, "baisse_de_volume_tolerable": None, "baisse_tolerable_pct": None}
    if mbn <= 0:
        res["statut"] = "nouvelle_marge_non_positive"
        av.append("Nouvelle contribution unitaire <= 0 : aucun volume ne rattrape l'ancien résultat. "
                  "Il faut revoir l'offre (prix ou coût variable), pas chercher un volume.")
    elif contrib_av <= 0:
        res["statut"] = "reference_non_positive"
        av.append("Ancien résultat <= 0 : pas de volume d'équilibre ni de baisse tolérable à calculer (0 vente "
                  "dépasse mathématiquement un résultat négatif, mais ce n'est pas une recommandation commerciale). "
                  "Il faut revoir l'offre ; comparer plutôt les contributions unitaires et le volume réellement observé.")
    else:
        veq = contrib_av / mbn
        vmin = ceil_int(veq)
        res["volume_equilibre_theorique"] = rn(veq, "0.01")
        res["volume_equilibre_contribution"] = vmin
        res["volume_minimum_pour_depasser"] = int(veq.to_integral_value(rounding=ROUND_FLOOR)) + 1
        tol = max(Decimal(0), va - Decimal(vmin))
        res["baisse_de_volume_tolerable"] = int(tol)
        res["baisse_tolerable_pct"] = rn(tol / va * 100, "0.1")
    if vn is None:
        inc.append("volume_apres (à observer par un essai ; seul le volume d'équilibre est calculé)")
    else:
        res.update(contribution_totale_apres=r2(mbn * vn), ca_apres=r2(pn * vn),
                   delta_contribution=r2(mbn * vn - contrib_av), delta_ca=r2(pn * vn - pa * va))
    av.append("Contribution = prix - coûts variables renseignés ; ce n'est ni un bénéfice net ni la preuve que le "
              "volume reviendra. Les clients perdus peuvent aussi emporter des ventes associées (boisson, dessert).")
    return sortie(res, inc, av)


# 4 — colis / cash / rotation --------------------------------------------------
def colis(data):
    opts = data.get("options")
    if not isinstance(opts, list) or len(opts) < 2:
        raise Erreur("options : au moins 2 options à comparer")
    besoin = d(data.get("besoin_unites_jusqu_au_prochain_achat"), "besoin_unites_jusqu_au_prochain_achat")
    inc, av, out = [], [], []
    if besoin is None:
        inc.append("besoin_unites_jusqu_au_prochain_achat (sans lui, le surplus et le cash immobilisé restent inconnus)")
    for i, o in enumerate(opts):
        nom = o.get("nom", f"option{i+1}")
        n, pu = req(o, "unites", positif=True), req(o, "prix_unitaire")
        cash = n * pu
        e = {"nom": nom, "unites": rn(n, "0.01"), "prix_unitaire": r2(pu), "cash_decaisse": r2(cash)}
        if besoin is not None:
            surplus = max(Decimal(0), n - besoin)
            e["unites_au_dela_du_besoin"] = rn(surplus, "0.01")
            e["cash_immobilise_au_dela_du_besoin"] = r2(surplus * pu)
            e["unites_manquantes"] = rn(max(Decimal(0), besoin - n), "0.01")
        out.append(e)
    res = {"options": out}
    if len(out) == 2 and besoin is not None:
        a, b = out
        res["difference_cash_a_moins_b"] = r2(Decimal(a["cash_decaisse"]) - Decimal(b["cash_decaisse"]))
    av.append("Le surplus est un STOCK (argent immobilisé), pas une perte certaine : il devient perte s'il est jeté, "
              "dépasse la durée de vie ou n'est pas vendu. Le prix unitaire plus bas ne prouve rien sans le besoin réel.")
    return sortie(res, inc, av)


# 5 — suggestion limitée vs achats induits ---------------------------------------
def suggestion(data):
    util = req(data, "quantite_utilisable_validee", positif=True)
    por = req(data, "grammage_portion", positif=True)
    ann = req(data, "portions_annoncees", positif=True)
    prix = d(data.get("prix_unitaire_achat"), "prix_unitaire_achat")
    colis_q = d(data.get("taille_colis"), "taille_colis", positif=True)
    inc, av = [], []
    possibles = (util / por).to_integral_value(rounding=ROUND_FLOOR)
    manque_portions = max(Decimal(0), ann - possibles)
    manque_q = max(Decimal(0), ann * por - util)  # en masse, avant arrondi au colis
    res = {"portions_completes_possibles_avec_le_stock": int(possibles), "portions_possibles_avec_le_stock": int(possibles),
           "portions_annoncees": int(ann), "portions_manquantes": int(manque_portions),
           "quantite_a_acheter_en_plus": rn(manque_q)}
    if colis_q is not None and manque_q > 0:
        nb = ceil_int(manque_q / colis_q)
        achete = Decimal(nb) * colis_q
        res.update(colis_a_acheter=nb, quantite_achetee=rn(achete), reste_apres_service=rn(achete - manque_q))
        if prix is not None:
            res["cash_achat_induit"] = r2(achete * prix)
            res["valeur_du_reste_immobilisee"] = r2((achete - manque_q) * prix)
    elif colis_q is None and manque_q > 0:
        inc.append("taille_colis (l'achat induit réel est arrondi au colis)")
        if prix is not None:
            res["cash_achat_induit_minimum"] = r2(manque_q * prix)
    if prix is None:
        inc.append("prix_unitaire_achat (coût de l'achat induit non calculable)")
    if manque_portions > 0:
        av.append("Annoncer plus que le stock validé force un achat ; l'ingrédient déjà acheté garde son coût "
                  "même si on ne le vend pas (il reste un stock à utiliser ou à perdre).")
    av.append("Quantité 'utilisable' = validée par le pro (parage, DLC, qualité), pas estimée par l'assistant.")
    return sortie(res, inc, av)


# 6 — formule additionnelle / cannibalisation ---------------------------------------
def cannibalisation(data):
    ua, pa = req(data, "unites_avant"), req(data, "prix_avant")
    un, pn = req(data, "unites_apres"), req(data, "prix_apres")
    ca_av, ca_ap = ua * pa, un * pn
    res = {"ca_avant": r2(ca_av), "ca_apres": r2(ca_ap),
           "supplement_reel_de_ca": r2(ca_ap - ca_av)}
    inc, av = [], []
    ca_c, cn_c = d(data.get("cout_variable_avant"), "cout_variable_avant"), d(data.get("cout_variable_apres"), "cout_variable_apres")
    if ca_c is None or cn_c is None:
        inc.append("cout_variable_avant/apres (contribution non calculable ; le CA seul ne dit rien de la marge)")
    else:
        res["contribution_avant"] = r2((pa - ca_c) * ua)
        res["contribution_apres"] = r2((pn - cn_c) * un)
        res["delta_contribution"] = r2((pn - cn_c) * un - (pa - ca_c) * ua)
    rem = d(data.get("ventes_remplacees"), "ventes_remplacees")
    if rem is None:
        inc.append("ventes_remplacees (part des ventes d'avant qui migrent vers la formule : à observer)")
    av.append("Le chiffre d'affaires 'de la formule' n'est pas un supplément : ce qui remplace une vente existante "
              "n'est pas nouveau. Comparer l'ensemble de la période, avant/après.")
    return sortie(res, inc, av)


# 7 — théorique / réel -------------------------------------------------------------
def ecart(data):
    ventes = req(data, "unites_vendues")
    cu = req(data, "cout_theorique_unitaire")
    si, ach, sf = req(data, "stock_initial"), req(data, "achats"), req(data, "stock_final")
    theo = ventes * cu
    reel = si + ach - sf
    inc, av = [], []
    if sf > si + ach:
        raise Erreur("stock_final > stock_initial + achats : saisie incohérente (valorisation ou inventaire à revoir)")
    res = {"consomme_theorique": r2(theo), "consomme_reel": r2(reel), "ecart": r2(reel - theo),
           "ecart_en_pct_du_theorique": rn((reel - theo) / theo * 100, "0.1") if theo else None}
    for k in ("offerts_et_repas_personnel", "pertes_declarees"):
        v = d(data.get(k), k)
        if v is None:
            inc.append(f"{k} (peut expliquer une partie de l'écart)")
        else:
            res[k] = r2(v)
    pdecl = sum((d(data.get(k), k) or Decimal(0)) for k in ("offerts_et_repas_personnel", "pertes_declarees"))
    if all(data.get(k) is not None for k in ("offerts_et_repas_personnel", "pertes_declarees")):
        res["ecart_restant_apres_declarations"] = r2(reel - theo - pdecl)
    av.append("L'écart est une question, pas un verdict de gaspillage : portions, recettes à jour, inventaire "
              "(périmètre, valorisation), livraisons non saisies, offerts/repas personnel, ventes non enregistrées.")
    return sortie(res, inc, av)


COMMANDES = {"brut_net": brut_net, "goulot": goulot, "delta_volume": delta_volume, "colis": colis,
             "suggestion": suggestion, "cannibalisation": cannibalisation, "ecart": ecart}


def main(argv):
    if len(argv) < 3 or argv[1] not in COMMANDES:
        print(__doc__)
        return 2
    try:
        brut = sys.stdin.read() if argv[2] == "-" else (open(argv[3]).read() if argv[2] == "--fichier" else argv[2])
        data = json.loads(brut)
        if not isinstance(data, dict):
            raise Erreur("l'entrée doit être un objet JSON")
        out = COMMANDES[argv[1]](data)
        code = 0
    except (Erreur, json.JSONDecodeError, OSError) as e:
        out, code = {"ok": False, "erreur": str(e)}, 1
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv))
