# Sources et portée réelle de lecture

Trois natures séparées : (A) expérience déclarée de Cyril → `experience-cyril.md` ; (B) méthodes proposées par ce skill ; (C) mécanismes d'auteurs ci-dessous. Lecture déclarée dans `SOURCES-CLIENTS-SYSTEMES.md` et `SOURCES-OFFRES.md` (consultées le 10/11/2026). Aucun support externe n'est redistribué ; liens seulement.

| Source | Lu | Mécanisme retenu | Utilisé pour | Limite |
|---|---|---|---|---|
| Kathryn Whitenton, NN/g, « Website Forms Usability: Top 10 Recommendations » (2016) — https://www.nngroup.com/articles/web-form-design/ | article HTML | peu de champs, groupés, libellés clairs, correction d'erreur sans perdre la saisie | ne demander que les champs qui changent le devis ; accepter une demande incomplète | ergonomie générale ; pas de chiffre de conversion traiteur |
| n8n, « n8n Form » — https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.formtrigger | doc éditeur | URL de test vs production, champs obligatoires | tester une demande complète et une incomplète avant de se fier à un circuit | n'établit rien sur l'instance du client ni Pennylane/Gmail |
| n8n, « Human-in-the-loop for tools » — https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md | doc éditeur | approbation/refus avant une action ; gérer le refus | validation du pro avant envoi ; tester le refus | pas la fonction historique de Cyril ; l'approbation ne garantit pas des prix exacts |
| Acquisition.com, Offer Creation Checklist — https://www.acquisition.com/files/offer-creation-checklist.pdf | 3 pages | partir du résultat visé et des obstacles du client ; composantes à coût de réalisation réaliste | composer une offre adaptée avec des éléments chiffrables | méthode d'auteur, aucune preuve en restauration ; PDF protégé, non redistribué |
| Strategyzer (K. Bostelaar, 2015), Value Proposition Canvas pour les ventes — https://www.strategyzer.com/library/how-sales-teams-can-create-focused-value-for-prospects-with-the-value-proposition-canvas | article | comparer les attentes par segment | une offre par occasion (hypothèses à vérifier) | outil de conception, pas un prix de marché |
| CNIL, prospection par courrier électronique, SMS, automate d'appel — https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique-sms-mms-et-automate-dappel | page officielle | information, consentement/opposition, identification | séparer réponse à une demande de devis et relance promotionnelle ; vérifier le canal | pas une validation juridique ; ne tranche pas chaque canal |

Ce que ces sources **ne prouvent pas** : un effet sur les ventes, un gain de temps, l'exactitude des prix ou disponibilités, la conformité d'un message précis.
Non sourcé volontairement : les formules de `devis_outils.py` (arithmétique simple) ; les 6 arbitrages (propositions de ce skill).
