# Ce que Cyril a déclaré (et ce qui reste inconnu)

Source : `strategie-3-mois/references/faits-editoriaux-vocaux-2026-11-10.md` §1 et §15, `reponses-integrales-cyril-2026-11-10.md` (vocaux 1 et 15). Déclarations non vérifiées indépendamment.

## Expérience déclarée (Lunch Wagon)
- Formulaires de contact **différents par cible** : anniversaires, événements d'entreprise, mariages ; offres et packs déjà formulés par occasion.
- **Catalogue complet en ligne** ; on y voit les offres puis on indique notamment le **nombre de convives** et le **menu enfant**.
- Automatisation : formulaire → **n8n** → **devis Pennylane** → **brouillon Gmail** → **validation de Cyril** → envoi. Un email automatisé accompagnait le brouillon.
- **Relances prévues** ; un **bouton de rendez-vous** vers un agenda pour parler du devis.
- Son constat : les clients n'ont pas le temps et veulent un devis rapide, précis.
- Environ **trois mois** passés sur les scénarios n8n/Pennylane (aide de personnes au début) ; API Pennylane récente à l'époque selon son souvenir. Il juge aujourd'hui l'automatisation plus simple avec Claude/ChatGPT et conseille de ne pas s'y enliser.
- Il cite des jours à 4-5 demandes de devis (captures à retrouver dans un projet). Chiffre déclaré, non vérifié ici.

## Ce que ce skill NE déclare PAS
- Que les 6 arbitrages soient sa méthode : ce sont **nos propositions**, issues du besoin de la mission, à tester.
- Ses règles d'acompte, d'annulation, de cession de prix, ses capacités, ses délais : **inconnus**. Le skill demande au pro les siens.
- Taux de transformation, temps gagné, ROI : **aucun établi**.
- L'agenda de rendez-vous du circuit n'est **pas** son appel stratégique payant ; ne pas les confondre, et ne présenter aucun tarif ni CTA d'achat.

## Ce qui manquerait pour refléter tout son jugement
Ses formulaires et catalogue réels ; un devis et un brouillon réels (anonymisés) ; ses règles de sous-/sur-capacité ; comment il traitait un changement de convives ; ses conditions de paiement/annulation ; ses critères pour décider relance ou RDV. Chaque point répondu par lui se range ici comme « déclaré », jamais mélangé aux propositions.
