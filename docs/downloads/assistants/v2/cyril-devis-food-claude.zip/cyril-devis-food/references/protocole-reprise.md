# Protocole de reprise (rien n'est activé : c'est une procédure à suivre à la main ou avec le script)

## Fiche minimale par demande (le « registre »)
`ref_demande` · `contact_id` · `date_evenement` · `lieu` · `occasion` · `offre_version` · `devis_ref` (réf. Pennylane ou outil du pro) · `brouillon_ref` (id/lien du brouillon Gmail) · `statut` · `derniere_action` · `date_derniere_verification`.
Écrire la référence **dès la création** de chaque objet, avant l'étape suivante.

## Retrouver avant de recréer
Une panne peut survenir **entre** la création du devis et l'écriture de sa référence. Ordre :
1. chercher la `ref_demande` dans le registre (unique ; absente ou en double → À CONFIRMER, pas de nouvelle fiche) ; comparer la `version_devis` ;
2. sans référence : contact + date + occasion, **les trois doivent être présents** ; s'il en manque → À CONFIRMER, demander la référence ;
3. si la fiche n'a pas de `devis_ref` : **chercher dans l'outil de devis (contact + date) avant de recréer** (le pro vérifie) ;
4. devis trouvé, brouillon non référencé → **chercher le brouillon ou le message existant** (destinataire, objet, référence) : une erreur de réponse de Gmail ne prouve pas qu'il n'a pas été créé. Ne créer un brouillon que si la recherche ne trouve rien ;
5. devis et brouillon trouvés → vérifier s'ils sont déjà partis avant d'agir ;
6. rien trouvé nulle part → recréation permise, après avoir noté la raison.

## Doublon ou non ?
Contact, date et occasion présents et identiques = doublon probable (le pro confirme). Identifiants absents = on ne conclut pas. Même contact + autre événement = nouvelle fiche liée. Même événement avec infos corrigées = **nouvelle version**, pas nouvelle demande.

## Après la reprise
Mettre à jour statut, date de vérification, prochaine action. Ne jamais écrire « envoyé » sans confirmation du pro. Noter l'incident (étape, cause connue) pour décider d'un contrôle supplémentaire.

## Test à faire avant de se fier à un vrai circuit (par le pro)
Demande complète · demande sans lieu ou sans convives · refus de validation · panne simulée après création du devis · deux événements du même contact. Résultat attendu pour chacun : voir `cas/`.
