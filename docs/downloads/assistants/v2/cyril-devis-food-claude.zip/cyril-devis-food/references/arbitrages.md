# Les 6 arbitrages du devis

Méthode **proposée**, testable, adaptée à un indépendant. Ce n'est ni un standard du métier ni, sauf mention dans `experience-cyril.md`, la pratique déclarée de Cyril. Les seuils et valeurs sont ceux du pro.

## 1. Offre du catalogue ou adaptation
**Piège** : même nombre de convives, mais « cocktail debout 2 h » au lieu de « repas assis ». Renommer l'offre assise ne suffit pas.

**Ce qui change réellement quand le format change** : unité de production (pièces par personne plutôt qu'assiettes), service (circulation ou postes, pas service à table), personnel et heures, matériel et mobilier, emballages/piques, durée de présence, allergènes (plus de contacts croisés sur un buffet), vaisselle et retour.

**Décision** :
- les composantes du catalogue (produits, règles de portion) servent de matière première ;
- si ≥ 2 de ces postes changent, c'est une **offre adaptée** : la nommer comme telle, lister l'écart avec le catalogue ;
- si le catalogue ne couvre pas le format, dire « à construire » plutôt que forcer un titre existant.
**Question à poser seulement si manquante** : format exact (assis / debout / buffet / à emporter), durée, enfants.

## 2. Chiffrage ou faisabilité
Le même « 100 personnes » n'est pas le même problème en **20 min** ou en **2 h**. Le coût peut être identique ; la faisabilité non.

**Données qui décident** : portions par convive, nombre de postes et de personnes réellement disponibles, **cadence réelle d'un poste avec cette préparation** (finition minute ou préparée), fenêtre de service. Rien d'autre n'est nécessaire pour trancher.
**Outil** : `faisabilite` = convives × portions ÷ (postes × cadence). Hypothèse : file continue. Si la cadence manque, la réponse est « indéterminé » ; aucune cadence par défaut.
**Décision** : avant de chiffrer, vérifier si ça tient ; si ça ne tient pas, proposer une variante (service étalé, plus de postes, préparation d'avance, format différent) plutôt qu'un prix sur un service irréalisable. Marge de sécurité = choix du pro.

## 3. Prix apparent ou soutenabilité
**Le prix de vente vient du catalogue validé par le pro** (ou de son prix validé pour l'offre adaptée). Le calcul de coûts sert à vérifier que ce prix est soutenable, pas à l'inventer.

Les coûts à couvrir : **préparation, matières, portions, emballages, personnel, trajet, installation, nettoyage, achats spécifiques**.
- **Bases HT/TTC** : les coûts et le prix doivent être déclarés sur la **même base** (`facturation.base_couts`, `prix_catalogue.base`). Base absente ou différente → aucune contribution calculée, on convertit d'abord (la TVA est un champ du pro).
- **Contribution** = prix validé − coûts listés, seulement si le calcul est complet, le prix validé et les bases identiques. Elle ne dit rien des coûts fixes ni de la trésorerie.
- **Calcul complet ?** Non si : une ligne inconnue, des convives inconnus, une catégorie essentielle absente sans raison (`categories_non_applicables`), un zéro sans raison. Et même « complet à valider » reste une estimation.
- **Coût supporté ≠ ligne facturée au client.** Un coût non refacturé ou offert (ex. personnel inclus dans le menu) reste un coût : il compte dans la contribution. Ce que le client voit (lignes du `prix_catalogue`) est séparé de ce que le pro supporte (`lignes` de coûts). Le champ ancien `facture` est **ignoré** pour le coût et lève une confirmation. Seule exclusion admise : le client paie directement la ligne, déclaré explicitement (`paye_par: client` + `raison_exclusion` écrite) ; elle est alors listée dans `exclus_documentes`. Sans raison, le coût est conservé et le point est bloquant.
- **Vaisselle incluse** : ne pas la facturer deux fois (forfait « tout compris » + ligne vaisselle) ; le script signale deux lignes qui `couvre` le même poste.
- **Client fournit la vaisselle** : la location disparaît (zéro avec raison écrite) ; **ne disparaissent pas** transport, manutention, lavage éventuel, retour, installation. Chaque suppression se justifie ligne par ligne.
- Achats ou location ponctuels : ligne spécifique, pas diluée.
- Achats et ventes ne prouvent pas le coût consommé ; coûts fixes, trésorerie et contribution sont des sujets distincts.
- **Scénario facultatif** : si le pro le demande, `scenario_objectif` (objectif strictement entre 0 et 100 %, `choisi_par_pro: true`) donne coût ÷ (1 − objectif) sur la base des coûts. C'est un point de comparaison, **jamais** un prix validé ni la seule façon de chiffrer.

## 4. Sous-total ou version
60 adultes deviennent 75 après validation d'un brouillon.
- Créer une **nouvelle version** (v2), ne pas écraser la v1. Une validation **ne passe jamais d'un dossier à un autre** : référence de demande différente, absente ou non résolue → validation non transférable et identité à confirmer (pas un simple avertissement).
- Montrer : écarts par ligne, production (kg, pièces), personnel, et **les lignes fixes qui n'ont pas bougé** (trajet, installation, nettoyage : oubli ou raison ?).
- **Invalider l'ancienne validation** si un champ engageant change : convives, date, lieu, horaires, menu, offre, prix du catalogue, conditions, TVA/bases, service ; ou une ligne (quantité, prix unitaire, mode), **même si le total reste identique** (2 × 20 ≠ 4 × 10 pour la production). On ne parle de « validation applicable » que si la v1 était réellement validée dans les données.
- Un sous-total (somme des lignes connues) n'est pas un devis ferme. Le devis ferme est émis par le pro.
- Changement à la baisse : mêmes règles ; ne pas conserver un forfait dimensionné pour l'ancien effectif sans le dire.
**Outil** : `diff v1 v2`.

## 5. Nouvelle demande ou reprise
Chaque dossier porte : **référence de demande + version d'offre + devis + brouillon + statut + date de dernière vérification**.
- **Référence unique et version d'abord** : même référence trouvée une seule fois → reprise (version reçue plus récente = nouvelle version ; plus ancienne = périmée). Référence inconnue ou en double → **À CONFIRMER**.
- Doublon probable seulement si contact, date et occasion sont **tous présents** et identiques ; s'il en manque, la réponse est **À CONFIRMER** (ni doublon, ni nouveau contact).
- **Même contact + deux événements différents ≠ doublon** : nouvelle fiche liée, nouvelle référence.
- Panne après création du devis : **retrouver le devis, ne pas le recréer**. Erreur de réponse Gmail : le brouillon a peut-être été créé, **chercher l'existant avant d'en créer un**. Détail : `protocole-reprise.md`.

## 6. Relancer, clarifier ou proposer un RDV
Choisir selon la dernière action et le dernier message du client :
| Situation | Choix |
|---|---|
| Devis accepté | pas de relance → préparation |
| Rendez-vous déjà pris | pas de relance → préparer le RDV |
| Le client a posé une question précise | **clarifier** d'abord, une réponse nette |
| Objection de prix ou plusieurs variables (périmètre, portions, services) | **proposer un RDV** court, avec variantes chiffrées validées par le pro |
| Silence | **relancer** une fois le délai fixé par le pro dépassé ; délai absent → le demander, ne pas l'inventer |
Une « relance vague » (« avez-vous eu le temps de regarder ? ») après acceptation ou rendez-vous est une erreur de circuit. Canal et consentement des messages commerciaux : voir CNIL dans `sources.md`.
