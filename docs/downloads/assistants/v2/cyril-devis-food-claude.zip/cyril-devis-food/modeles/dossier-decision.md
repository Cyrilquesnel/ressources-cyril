# Dossier de décision — {ref_demande} · offre v{n} · devis v{n}

> Document INTERNE pour le professionnel (contient des coûts : ne pas transmettre au client). Rien n'est envoyé. Les montants ne deviennent un prix qu'après sa validation.

## 1. Statut et prochaine action
- Statut : {demande_recue | info_manquante | brouillon_pret | devis_envoye | rdv_pris | accepte | refuse | perdu}
- Dernière action (date) : …
- **Prochaine action** : … · par qui : … · validation requise du pro : oui/non

## 2. Offre recommandée et écarts
- Offre du catalogue la plus proche : …
- Offre recommandée : catalogue tel quel / adaptée / à construire
- Ce qui change par rapport au catalogue (service, format, personnel, matériel) : …
- Pourquoi ce n'est pas un simple changement de titre : …

## 3. Ce qui change le devis (et seulement cela)
| Question | Pourquoi elle change le chiffre | Réponse reçue / à demander |
|---|---|---|

## 4. Calcul traçable (version {n})
Sortie de `devis_outils.py calc` : total chiffré, lignes inconnues, avertissements.
- Statut du calcul : complet / partiel (minimum connu)
- Lignes inconnues et qui les confirme : …
- Hypothèses (fictives ou à valider) : …
- Ce que le client fournit (ex. vaisselle) et ce qui reste à notre charge (nettoyage, transport, retour) : …
- Bases : coûts HT/TTC = … ; prix HT/TTC = … (identiques, sinon aucune contribution)
- Prix : issu du **catalogue validé du pro** (validé : oui/non) ; contribution = prix − coûts listés (si complet) ; scénario objectif de marge : facultatif, choisi par le pro, jamais un prix validé
- Champs fiscaux (TVA…) : à confirmer par le pro

## 5. Versions
| De → vers | Champs engageants modifiés | Impact production | L'ancienne validation existait-elle vraiment ? Applicable ? |
|---|---|---|---|

## 6. Faisabilité (si la fenêtre de service est serrée)
Cadence réelle fournie par le pro : … · résultat de `faisabilite` : …

## 7. Brouillon de réponse
(texte prêt à relire ; aucune promesse de prix, de date ou de capacité non validée)

## 8. Proposition client (séparée de ce dossier)
Générée avec `html` : prix de vente validé seulement, aucun coût, aucune marge. Montant « à confirmer » tant que le prix n'est pas validé.

## 9. Références du circuit
Demande : … · offre : … · devis (Pennylane) : … · brouillon (Gmail) : … · date de la dernière vérification : …
