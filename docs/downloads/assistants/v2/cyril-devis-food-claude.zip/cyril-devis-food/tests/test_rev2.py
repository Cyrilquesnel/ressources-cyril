"""Tests REV2 : deux P1 métier relevés par un relecteur indépendant.
Lancer : python3 -I tests/test_rev2.py"""
import os, sys, unittest
sys.path.insert(0, os.environ.get("DEVIS_SCRIPTS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts")))
import devis_outils as d  # noqa: E402


def L(i, cat, v, **kw):
    return {"id": i, "libelle": i, "categorie": cat, "mode": "forfait", "valeur": v, **kw}


def lignes(**over):
    base = {"m": L("m", "matieres", 120), "p": L("p", "personnel", 180), "t": L("t", "trajet", 40),
            "i": L("i", "installation", 30), "n": L("n", "nettoyage", 20)}
    for k, v in over.items():
        base[k] = {**base[k], **v}
    return list(base.values())


def dev(ls, ref="QA-INDEP-101", version=1, **kw):
    return {"ref_demande": ref, "version": version, "convives": {"adultes": 10, "enfants": 0}, "lignes": ls,
            "facturation": {"base_couts": "HT"}, "prix_catalogue": {"base": "HT", "lignes": [
                {"id": "pv", "libelle": "Menu", "mode": "forfait", "valeur": 600, "valide_par_pro": True}]},
            "offre": "O", "validation": {"statut": "validee_par_pro"}, **kw}


class A_validation_non_transferable(unittest.TestCase):
    def test_refs_differentes_validation_non_transferable(self):
        r = d.diff(dev(lignes(), ref="QA-INDEP-101"), dev(lignes(), ref="QA-INDEP-102", version=2))
        self.assertIn("NON TRANSFÉRABLE", r["validation"])
        self.assertNotIn("est applicable", r["validation"])
        self.assertTrue(r["identite_a_confirmer"])

    def test_ref_absente_ou_non_resolue(self):
        for ra, rb in ((None, "R"), ("R", None), (None, None), ("", "R"), ("R", " ")):
            a, b = dev(lignes(), ref=ra), dev(lignes(), ref=rb, version=2)
            r = d.diff(a, b)
            self.assertIn("NON TRANSFÉRABLE", r["validation"], (ra, rb))

    def test_meme_ref_et_rien_ne_change_reste_applicable(self):
        r = d.diff(dev(lignes()), dev(lignes(), version=2))
        self.assertIn("est applicable", r["validation"])
        self.assertFalse(r.get("identite_a_confirmer"))

    def test_refs_differentes_et_changement(self):
        r = d.diff(dev(lignes(), ref="A"), dev(lignes(p={"valeur": 200}), ref="B", version=2))
        self.assertIn("NON TRANSFÉRABLE", r["validation"])


class B_cout_supporte(unittest.TestCase):
    def test_reference_390_et_contribution_210(self):
        r = d.calc(dev(lignes()))
        self.assertEqual(r["cout_connu_total"], 390.0)
        self.assertEqual(r["contribution"]["valeur"], 210.0)

    def test_facture_false_ne_fait_pas_disparaitre_le_cout(self):
        r = d.calc(dev(lignes(p={"facture": False})))
        self.assertEqual(r["cout_connu_total"], 390.0)
        self.assertEqual(r["contribution"]["valeur"], 210.0)
        self.assertNotEqual(r["contribution"]["valeur"], 390.0)

    def test_facture_false_leve_une_confirmation(self):
        r = d.calc(dev(lignes(p={"facture": False})))
        self.assertTrue(any("facture" in c for c in r["confirmations"]))

    def test_paiement_direct_client_documente_est_exclu_explicitement(self):
        r = d.calc(dev(lignes(p={"paye_par": "client", "raison_exclusion": "le client règle directement le serveur extérieur (fictif)"})))
        self.assertEqual(r["cout_connu_total"], 210.0)
        self.assertEqual(r["contribution"]["valeur"], 390.0)
        self.assertEqual([x["id"] for x in r["exclus_documentes"]], ["p"])
        self.assertIn("le client règle", r["exclus_documentes"][0]["raison"])

    def test_paiement_direct_client_sans_raison_garde_le_cout(self):
        r = d.calc(dev(lignes(p={"paye_par": "client"})))
        self.assertEqual(r["cout_connu_total"], 390.0)
        self.assertEqual(r["statut_calcul"], "partiel")
        self.assertTrue(any("paiement direct" in b for b in r["bloquants"]))

    def test_facture_false_avec_paiement_direct_documente_seul_paiement_compte(self):
        r = d.calc(dev(lignes(p={"facture": False, "paye_par": "client", "raison_exclusion": "x documenté"})))
        self.assertEqual(r["cout_connu_total"], 210.0)

    def test_diff_detecte_changement_de_paiement_direct(self):
        a = dev(lignes())
        b = dev(lignes(p={"paye_par": "client", "raison_exclusion": "documenté"}), version=2)
        self.assertIn("INVALIDE", d.diff(a, b)["validation"])

    def test_scenario_marge_garde_le_cout_avec_facture_false(self):
        r = d.calc(dev(lignes(p={"facture": False}), scenario_objectif={"marge_pct": 35, "choisi_par_pro": True}))
        self.assertEqual(r["scenario_marge"]["valeur"], round(390 / 0.65, 2))


if __name__ == "__main__":
    unittest.main(verbosity=1)
