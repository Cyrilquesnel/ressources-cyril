"""Tests légers (stdlib). Lancer : python3 -I tests/test_devis_outils.py"""
import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
import devis_outils as d  # noqa: E402

C = {"adultes": 10, "enfants": 2}


def dev(lignes, conv=C, **kw):
    return {"convives": conv, "lignes": lignes, **kw}


class T(unittest.TestCase):
    def test_inconnue_n_est_pas_zero(self):
        r = d.calc(dev([{"id": "a", "libelle": "x", "categorie": "matieres", "mode": "par_adulte", "valeur": 2},
                        {"id": "b", "libelle": "y", "categorie": "personnel", "mode": "forfait", "valeur": None}]))
        self.assertEqual(r["cout_connu_total"], 20.0)
        self.assertEqual(r["statut_calcul"], "partiel")
        self.assertIsNone(r["contribution"]["valeur"])
        self.assertEqual([i["id"] for i in r["inconnues"]], ["b"])

    def test_zero_sans_raison_signale(self):
        r = d.calc(dev([{"id": "v", "libelle": "vaisselle", "categorie": "vaisselle", "mode": "forfait", "valeur": 0}]))
        self.assertTrue(any("zéro sans raison" in w for w in r["bloquants"]))

    def test_double_facturation(self):
        l = [{"id": "f", "libelle": "forfait complet", "categorie": "autre", "mode": "forfait", "valeur": 50, "couvre": ["vaisselle"]},
             {"id": "v", "libelle": "vaisselle", "categorie": "vaisselle", "mode": "forfait", "valeur": 20, "couvre": ["vaisselle"]}]
        self.assertTrue(any("double facturation" in w for w in d.calc(dev(l))["avertissements"]))

    def test_modes_enfants_et_convives(self):
        l = [{"id": "e", "libelle": "e", "categorie": "matieres", "mode": "par_enfant", "valeur": 3},
             {"id": "c", "libelle": "c", "categorie": "matieres", "mode": "par_convive", "valeur": 1}]
        self.assertEqual(d.calc(dev(l))["cout_connu_total"], 6 + 12)

    def test_aucun_prix_derive_de_la_marge(self):
        l = [{"id": "a", "libelle": "x", "categorie": "matieres", "mode": "forfait", "valeur": 65}]
        r = d.calc(dev(l, facturation={"base_couts": "HT"}, scenario_objectif={"marge_pct": 35, "choisi_par_pro": True}))
        self.assertNotIn("prix_indicatif_ht", r)
        self.assertEqual(r["prix"]["statut"], "non_renseigne")

    def test_diff_invalide_validation_et_signale_forfaits(self):
        l = [{"id": "a", "libelle": "x", "categorie": "matieres", "mode": "par_adulte", "valeur": 2},
             {"id": "t", "libelle": "trajet", "categorie": "trajet", "mode": "forfait", "valeur": 10}]
        a = dev(l, conv={"adultes": 60, "enfants": 0}, version=1, validation={"statut": "validee_par_pro"}, ref_demande="R1")
        b = dev(l, conv={"adultes": 75, "enfants": 0}, version=2, ref_demande="R1")
        r = d.diff(a, b)
        self.assertIn("INVALIDE", r["validation"])
        self.assertEqual(r["cout_connu"]["ecart"], 30.0)
        self.assertIn("t", r["a_reexaminer"])

    def test_diff_identique_garde_validation(self):
        a = dev([{"id": "a", "libelle": "x", "categorie": "matieres", "mode": "forfait", "valeur": 1}], version=1, ref_demande="R1")
        a["validation"] = {"statut": "validee_par_pro"}
        b = dict(a, version=2)
        self.assertIn("applicable", d.diff(a, b)["validation"])

    def test_faisabilite_indeterminee_sans_cadence(self):
        r = d.faisabilite(dev([], service={"fenetre_min": 20, "portions_par_convive": 1, "postes": 2, "cadence_par_poste_min": None}))
        self.assertIn("indéterminé", r["verdict"])

    def test_faisabilite_calcul(self):
        r = d.faisabilite(dev([], conv={"adultes": 100, "enfants": 0},
                              service={"fenetre_min": 120, "portions_par_convive": 3, "postes": 2, "cadence_par_poste_min": 2.5}))
        self.assertEqual(r["temps_necessaire_min"], 60.0)

    def test_reprise_trois_cas(self):
        f = {"ref_demande": "R1", "contact_id": "c", "date_evenement": "2027-01-01", "occasion": "mariage",
             "statut": "devis_pennylane_cree", "devis_ref": "D1", "brouillon_ref": None}
        reg = [f]
        self.assertIn("REPRISE", d.reprise({"registre": reg, "entrant": {"ref_demande": "R1"}})["decision"])
        self.assertIn("DOUBLON", d.reprise({"registre": reg, "entrant": {"contact_id": "c", "date_evenement": "2027-01-01", "occasion": "mariage"}})["decision"])
        r = d.reprise({"registre": reg, "entrant": {"contact_id": "c", "date_evenement": "2027-05-01", "occasion": "anniversaire"}})
        self.assertIn("autre événement", r["decision"])
        self.assertIn("ne PAS le recréer", d.action_statut(f))

    def test_suite_pas_de_relance_si_accepte_ou_rdv(self):
        self.assertEqual(d.suite({"statut": "accepte"})["choix"], "ne_pas_relancer")
        self.assertEqual(d.suite({"statut": "rdv_pris", "dernier_message": "silence"})["choix"], "ne_pas_relancer")

    def test_suite_delai_non_invente(self):
        self.assertEqual(d.suite({"statut": "devis_envoye", "dernier_message": "silence", "jours_depuis_derniere_action": 30})["choix"], "delai_a_definir")


if __name__ == "__main__":
    unittest.main(verbosity=1)
