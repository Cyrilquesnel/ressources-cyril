"""Tests REV1 : reproduisent les comportements faux relevés à la relecture V2-C.
Lancer : python3 -I tests/test_rev1.py   (stdlib uniquement)"""
import math, os, sys, unittest
sys.path.insert(0, os.environ.get("DEVIS_SCRIPTS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts")))
import devis_outils as d  # noqa: E402


def L(i, mode, valeur, cat="matieres", **kw):
    return {"id": i, "libelle": i, "categorie": cat, "mode": mode, "valeur": valeur, **kw}


def dev(lignes, conv=None, **kw):
    return {"convives": conv if conv is not None else {"adultes": 10, "enfants": 0}, "lignes": lignes, **kw}


COMPLET = [L("m", "par_adulte", 2), L("p", "forfait", 10, "personnel"), L("t", "forfait", 5, "trajet"),
           L("i", "forfait", 5, "installation"), L("n", "forfait", 5, "nettoyage")]
BASES = {"base_couts": "HT"}


def modele():
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "modeles", "proposition-commerciale.html"), encoding="utf-8") as f:
        return f.read()


class Convives(unittest.TestCase):
    def test_convives_inconnus_ne_valent_pas_zero(self):
        r = d.calc(dev([L("m", "par_adulte", 2)], conv={"adultes": None, "enfants": 0}))
        self.assertEqual(r["statut_calcul"], "partiel")
        self.assertEqual(r["cout_connu_total"], 0)
        self.assertIn("m", [i["id"] for i in r["inconnues"]])

    def test_enfants_inconnus_rendent_partiel_meme_sans_ligne_enfant(self):
        r = d.calc(dev(COMPLET, conv={"adultes": 10, "enfants": None}, facturation=BASES))
        self.assertEqual(r["statut_calcul"], "partiel")

    def test_faisabilite_convives_inconnus_indetermine(self):
        s = {"fenetre_min": 20, "portions_par_convive": 1, "postes": 2, "cadence_par_poste_min": 2.5}
        r = d.faisabilite(dev([], conv={"adultes": None, "enfants": 0}, service=s))
        self.assertIn("indéterminé", r["verdict"])
        self.assertNotIn("temps_necessaire_min", r)

    def test_validations_bloquantes(self):
        bad = [dev([L("m", "par_adulte", -1)]),
               dev([L("m", "par_adulte", float("nan"))]),
               dev([L("m", "par_adulte", float("inf"))]),
               dev([L("m", "par_adulte", True)]),
               dev([L("m", "unitaire", 2, quantite=-3)]),
               dev([], conv={"adultes": 10.5, "enfants": 0}),
               dev([], conv={"adultes": -2, "enfants": 0}),
               dev([L("a", "forfait", 1), L("a", "forfait", 1)])]
        for b in bad:
            r = d.calc(b)
            self.assertEqual(r["statut_calcul"], "invalide", b)
            self.assertTrue(r["erreurs"])

    def test_faisabilite_valeurs_invalides_sans_exception(self):
        for k, v in (("postes", 0), ("cadence_par_poste_min", 0), ("fenetre_min", 0),
                     ("cadence_par_poste_min", float("nan")), ("postes", -1), ("portions_par_convive", 0), ("postes", 1.5)):
            s = {"fenetre_min": 20, "portions_par_convive": 1, "postes": 2, "cadence_par_poste_min": 2.5, k: v}
            r = d.faisabilite(dev([], service=s))
            self.assertIn("invalide", r["verdict"], (k, v))

    def test_marge_strictement_entre_0_et_100(self):
        for m in (0, 100, -5, 120, float("nan")):
            r = d.calc(dev(COMPLET, facturation=BASES, scenario_objectif={"marge_pct": m, "choisi_par_pro": True}))
            self.assertEqual(r["statut_calcul"], "invalide", m)


class Prix(unittest.TestCase):
    def test_pas_de_prix_sans_catalogue_valide(self):
        r = d.calc(dev(COMPLET, facturation=BASES))
        self.assertNotIn("prix_indicatif_ht", r)
        self.assertEqual(r["prix"]["statut"], "non_renseigne")
        self.assertIsNone(r["contribution"]["valeur"])

    def test_bases_incoherentes_refusent_contribution(self):
        pc = {"base": "TTC", "lignes": [L("pv", "par_adulte", 30, valide_par_pro=True)]}
        r = d.calc(dev(COMPLET, facturation=BASES, prix_catalogue=pc))
        self.assertIsNone(r["contribution"]["valeur"])
        self.assertIn("base", r["contribution"]["raison"])

    def test_base_absente_refuse_contribution(self):
        pc = {"lignes": [L("pv", "par_adulte", 30, valide_par_pro=True)]}
        r = d.calc(dev(COMPLET, prix_catalogue=pc))
        self.assertIsNone(r["contribution"]["valeur"])

    def test_contribution_quand_tout_coherent(self):
        pc = {"base": "HT", "lignes": [L("pv", "par_adulte", 30, valide_par_pro=True)]}
        r = d.calc(dev(COMPLET, facturation=BASES, prix_catalogue=pc))
        self.assertEqual(r["prix"]["total"], 300.0)
        self.assertEqual(r["contribution"]["valeur"], 300.0 - 45.0)

    def test_prix_non_valide_pas_de_contribution(self):
        pc = {"base": "HT", "lignes": [L("pv", "par_adulte", 30, valide_par_pro=False)]}
        r = d.calc(dev(COMPLET, facturation=BASES, prix_catalogue=pc))
        self.assertEqual(r["prix"]["statut"], "non_valide")
        self.assertIsNone(r["contribution"]["valeur"])

    def test_categories_essentielles_absentes_pas_complet(self):
        r = d.calc(dev([L("m", "par_adulte", 2)], facturation=BASES))
        self.assertEqual(r["statut_calcul"], "partiel")
        self.assertTrue(r["bloquants"])

    def test_categorie_non_applicable_avec_raison_accepte(self):
        l = [x for x in COMPLET if x["categorie"] != "trajet"]
        r = d.calc(dev(l, facturation=BASES, categories_non_applicables={"trajet": "prestation dans nos locaux"}))
        self.assertEqual(r["statut_calcul"], "complet_a_valider")

    def test_zero_sans_raison_pas_complet(self):
        l = [dict(x) for x in COMPLET]
        l[2]["valeur"] = 0
        r = d.calc(dev(l, facturation=BASES))
        self.assertEqual(r["statut_calcul"], "partiel")

    def test_scenario_marge_facultatif_et_etiquete(self):
        sc = {"marge_pct": 35, "choisi_par_pro": True}
        r = d.calc(dev(COMPLET, facturation=BASES, scenario_objectif=sc))
        self.assertEqual(r["scenario_marge"]["valeur"], round(45 / 0.65, 2))
        self.assertIn("pas un prix validé", r["scenario_marge"]["nature"])
        self.assertIsNone(r["prix"].get("total"))
        r2 = d.calc(dev(COMPLET, facturation=BASES, scenario_objectif={"marge_pct": 35}))
        self.assertNotIn("scenario_marge", r2)

    def test_scenario_refuse_si_partiel_ou_base_absente(self):
        sc = {"marge_pct": 35, "choisi_par_pro": True}
        self.assertNotIn("scenario_marge", d.calc(dev([L("m", "par_adulte", 2)], facturation=BASES, scenario_objectif=sc)))
        self.assertNotIn("scenario_marge", d.calc(dev(COMPLET, scenario_objectif=sc)))


class Diff(unittest.TestCase):
    base = dict(ref_demande="R-FICT-1", offre="Brasero", engagement={"date_evenement": "2027-04-17", "lieu": "Salle A", "horaires": "12h-15h", "menu": "M1"},
                conditions="C1", facturation=BASES, validation={"statut": "validee_par_pro"})

    def mk(self, v, **kw):
        x = dev(COMPLET, version=v, **{**self.base, **kw})
        return x

    def test_changement_date_lieu_menu_conditions_invalide(self):
        a = self.mk(1)
        for champ, val in (("date_evenement", "2027-04-18"), ("lieu", "Salle B"), ("menu", "M2"), ("horaires", "19h")):
            b = self.mk(2, engagement={**self.base["engagement"], champ: val})
            self.assertIn("INVALIDE", d.diff(a, b)["validation"], champ)
        self.assertIn("INVALIDE", d.diff(a, self.mk(2, conditions="C2"))["validation"])
        self.assertIn("INVALIDE", d.diff(a, self.mk(2, offre="Autre"))["validation"])

    def test_quantite_x_prix_change_a_total_constant(self):
        a = dev([L("x", "unitaire", 10, "personnel", quantite=4)], version=1, **self.base)
        b = dev([L("x", "unitaire", 20, "personnel", quantite=2)], version=2, **self.base)
        r = d.diff(a, b)
        self.assertIn("INVALIDE", r["validation"])
        self.assertTrue(any("total identique" in e for e in r["ecarts"]))

    def test_prix_catalogue_change_invalide(self):
        pa = {"base": "HT", "lignes": [L("pv", "par_adulte", 30, valide_par_pro=True)]}
        pb = {"base": "HT", "lignes": [L("pv", "par_adulte", 32, valide_par_pro=True)]}
        self.assertIn("INVALIDE", d.diff(self.mk(1, prix_catalogue=pa), self.mk(2, prix_catalogue=pb))["validation"])

    def test_validation_applicable_seulement_si_reelle(self):
        a = self.mk(1)
        self.assertIn("applicable", d.diff(a, self.mk(2))["validation"])
        a2 = self.mk(1, validation={"statut": "brouillon"})
        r = d.diff(a2, self.mk(2))
        self.assertNotIn("reste applicable", r["validation"])
        self.assertIn("aucune validation", r["validation"])
        a3 = dict(self.mk(1)); a3.pop("validation")
        self.assertIn("aucune validation", d.diff(a3, self.mk(2))["validation"])

    def test_diff_convives_inconnus_sans_exception(self):
        a = self.mk(1, convives={"adultes": None, "enfants": 0})
        b = self.mk(2, convives={"adultes": 75, "enfants": 0})
        self.assertIn("INVALIDE", d.diff(a, b)["validation"])


class Html(unittest.TestCase):
    def test_proposition_client_sans_interne(self):
        pc = {"base": "HT", "lignes": [L("pv", "par_adulte", 30, valide_par_pro=True, libelle="Menu brasero")]}
        x = dev(COMPLET, facturation=BASES, prix_catalogue=pc, offre="Brasero", ref_demande="R", version=1,
                scenario_objectif={"marge_pct": 35, "choisi_par_pro": True})
        for l in x["lignes"]:
            l["libelle"] = "SECRET-" + l["id"]
        out = d.rendre_html(x, modele())
        low = out.lower()
        for mot in ("secret-", "matieres", "personnel", "marge", "coût", "cout", "emballage", "contribution", "scénario"):
            self.assertNotIn(mot, low, mot)
        self.assertIn("Menu brasero", out)
        self.assertIn("300,00", out)

    def test_prix_non_valide_pas_de_montant(self):
        pc = {"base": "HT", "lignes": [L("pv", "par_adulte", 30, valide_par_pro=False, libelle="Menu")]}
        x = dev(COMPLET, facturation=BASES, prix_catalogue=pc, offre="B", ref_demande="R", version=1)
        out = d.rendre_html(x, modele())
        self.assertNotIn("300,00", out)
        self.assertIn("à confirmer", out)


class Reprise(unittest.TestCase):
    f = {"ref_demande": "R1", "contact_id": "c", "date_evenement": "2027-01-01", "occasion": "mariage",
         "statut": "devis_pennylane_cree", "devis_ref": "D1", "brouillon_ref": None, "version_devis": 1}

    def test_identifiants_absents_pas_de_doublon_ni_nouveau(self):
        for ent in ({}, {"occasion": "mariage"}, {"contact_id": "c"}, {"contact_id": "c", "occasion": "mariage"},
                    {"date_evenement": "2027-01-01", "occasion": "mariage"}):
            r = d.reprise({"registre": [self.f], "entrant": ent})
            self.assertIn("À CONFIRMER", r["decision"], ent)
            self.assertNotIn("DOUBLON", r["decision"])
            self.assertNotIn("NOUVELLE", r["decision"])

    def test_reference_inconnue_a_confirmer(self):
        r = d.reprise({"registre": [self.f], "entrant": {"ref_demande": "ZZ"}})
        self.assertIn("À CONFIRMER", r["decision"])

    def test_reference_en_double_dans_registre(self):
        r = d.reprise({"registre": [self.f, dict(self.f)], "entrant": {"ref_demande": "R1"}})
        self.assertIn("À CONFIRMER", r["decision"])

    def test_reference_prime_sur_le_reste(self):
        r = d.reprise({"registre": [self.f], "entrant": {"ref_demande": "R1", "contact_id": "autre", "date_evenement": "2030-01-01", "occasion": "x"}})
        self.assertIn("REPRISE", r["decision"])

    def test_version(self):
        r = d.reprise({"registre": [self.f], "entrant": {"ref_demande": "R1", "version_devis": 2}})
        self.assertIn("nouvelle version", r["decision"].lower())
        r = d.reprise({"registre": [self.f], "entrant": {"ref_demande": "R1", "version_devis": 0}})
        self.assertIn("périmée", r["decision"])

    def test_nouveau_contact_seulement_avec_identifiant(self):
        r = d.reprise({"registre": [self.f], "entrant": {"contact_id": "zz", "date_evenement": "2027-02-02", "occasion": "x"}})
        self.assertIn("NOUVELLE", r["decision"])

    def test_gmail_ne_justifie_pas_de_recreer_le_brouillon(self):
        a = d.action_statut(self.f).lower()
        self.assertIn("chercher", a)
        self.assertIn("avant", a)
        self.assertNotIn("refaire seulement le brouillon", a)

    def test_suite_message_inconnu_n_est_pas_silence(self):
        r = d.suite({"statut": "devis_envoye", "jours_depuis_derniere_action": 30, "delai_relance_jours": 7})
        self.assertNotEqual(r["choix"], "relancer")


if __name__ == "__main__":
    unittest.main(verbosity=1)
