#!/usr/bin/env python3
"""Outils de calcul pour le skill cyril-devis-food. Python stdlib, hors réseau.
Aucun envoi, aucune API : lit des JSON locaux, écrit sur la sortie standard.

Sous-commandes :
  calc <devis.json>               SORTIE INTERNE : coûts, inconnues, bloquants, prix du catalogue, contribution
  diff <v1.json> <v2.json>        écarts entre versions ; invalide la validation si un champ engageant change
  faisabilite <devis.json>        temps de service vs fenêtre (cadence fournie par le pro)
  reprise <reprise.json>          reprise / doublon / nouvelle demande, sinon « À CONFIRMER »
  suite <fiche.json>              relancer / clarifier / proposer un RDV / ne rien relancer
  html <devis.json> <modele.html> PROPOSITION CLIENT : prix de vente validé seulement, aucun coût interne

Règles : une valeur absente (null) est une INCONNUE, jamais zéro. Un zéro porte une "raison".
Le prix vient du catalogue validé par le pro (prix_catalogue). coût/(1-marge) n'est qu'un
scénario facultatif ("scenario_objectif", choisi_par_pro=true), jamais un prix validé.
Coûts et prix doivent être sur la même base (HT ou TTC), déclarée ; sinon rien n'est comparé.
Les chiffres des cas fournis sont FICTIFS.
"""
import html as htmllib
import json
import math
import sys

MODES = ("par_adulte", "par_enfant", "par_convive", "forfait", "unitaire")
ESSENTIELLES = ("matieres", "personnel", "trajet", "installation", "nettoyage")
BASES = ("HT", "TTC")
ENGAGEANTS = ("offre", "description_client", "convives", "engagement", "conditions",
              "prix_catalogue", "facturation", "service", "categories_non_applicables")


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def fin(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def entier(x):
    return isinstance(x, int) and not isinstance(x, bool)


def valider_lignes(lignes, nom, err):
    ids = set()
    for l in lignes or []:
        i = l.get("id")
        if i in ids:
            err.append(f"{nom}: id en double « {i} »")
        ids.add(i)
        if l.get("mode") not in MODES:
            err.append(f"{nom}.{i}: mode inconnu « {l.get('mode')} »")
        for k in ("valeur", "quantite"):
            v = l.get(k)
            if v is not None and (not fin(v) or v < 0):
                err.append(f"{nom}.{i}.{k}: nombre fini ≥ 0 attendu (reçu {v!r})")
        for k, v in (l.get("production") or {}).items():
            if k != "unite" and (not fin(v) or v < 0):
                err.append(f"{nom}.{i}.production.{k}: nombre fini ≥ 0 attendu")


def valider_convives(c, err):
    for k in ("adultes", "enfants"):
        v = (c or {}).get(k)
        if v is not None and (not entier(v) or v < 0):
            err.append(f"convives.{k}: entier ≥ 0 ou null (inconnu) attendu (reçu {v!r})")


def valider_service(s, err):
    for k in ("fenetre_min", "cadence_par_poste_min", "portions_par_convive"):
        v = (s or {}).get(k)
        if v is not None and (not fin(v) or v <= 0):
            err.append(f"service.{k}: nombre fini > 0 attendu (reçu {v!r})")
    v = (s or {}).get("postes")
    if v is not None and (not entier(v) or v <= 0):
        err.append(f"service.postes: entier > 0 attendu (reçu {v!r})")
    v = (s or {}).get("marge_securite_pct")
    if v is not None and (not fin(v) or v < 0):
        err.append("service.marge_securite_pct: nombre fini ≥ 0 attendu")


def valider(d):
    err = []
    valider_convives(d.get("convives"), err)
    valider_lignes(d.get("lignes"), "lignes", err)
    valider_lignes((d.get("prix_catalogue") or {}).get("lignes"), "prix_catalogue", err)
    valider_service(d.get("service"), err)
    sc = d.get("scenario_objectif")
    if sc is not None:
        m = sc.get("marge_pct")
        if not fin(m) or not 0 < m < 100:
            err.append(f"scenario_objectif.marge_pct: nombre strictement entre 0 et 100 attendu (reçu {m!r})")
    for k in ("base_couts",):
        b = (d.get("facturation") or {}).get(k)
        if b is not None and b not in BASES:
            err.append(f"facturation.{k}: HT ou TTC attendu")
    b = (d.get("prix_catalogue") or {}).get("base")
    if b is not None and b not in BASES:
        err.append("prix_catalogue.base: HT ou TTC attendu")
    return err


def nb(conv, mode):
    """Nombre de convives concerné par le mode, ou None si inconnu."""
    a, e = conv.get("adultes"), conv.get("enfants")
    if mode == "par_adulte":
        return a
    if mode == "par_enfant":
        return e
    if mode == "par_convive":
        return None if a is None or e is None else a + e
    return 0


def total_convives(conv):
    return nb(conv, "par_convive")


def eval_ligne(l, conv):
    """(cout|None, motif_inconnu|None)."""
    mode, val = l.get("mode"), l.get("valeur")
    if val is None:
        return None, "valeur inconnue"
    if mode in ("par_adulte", "par_enfant", "par_convive"):
        n = nb(conv, mode)
        if n is None:
            return None, "nombre de convives inconnu"
        return round(val * n, 2), None
    if mode == "forfait":
        return round(val, 2), None
    q = l.get("quantite")
    if q is None:
        return None, "quantité inconnue"
    return round(q * val, 2), None


def production(l, conv):
    p = l.get("production")
    if not p:
        return None
    a, e = conv.get("adultes"), conv.get("enfants")
    if (p.get("par_adulte") and a is None) or (p.get("par_enfant") and e is None):
        return p.get("unite", "?"), None
    n = (a or 0) * p.get("par_adulte", 0) + (e or 0) * p.get("par_enfant", 0)
    return p.get("unite", "?"), round(n, 2)


def prix_catalogue(d):
    pc = d.get("prix_catalogue")
    if not pc or not pc.get("lignes"):
        return {"statut": "non_renseigne",
                "raison": "le prix vient du catalogue validé du pro : à fournir par le professionnel"}
    conv, tot, lignes = d["convives"], 0.0, []
    inconnu = False
    for l in pc["lignes"]:
        c, motif = eval_ligne(l, conv)
        lignes.append({"libelle": l["libelle"], "montant": c, "valide_par_pro": l.get("valide_par_pro") is True})
        if c is None:
            inconnu = True
        else:
            tot += c
    valide = all(x["valide_par_pro"] for x in lignes)
    r = {"base": pc.get("base"), "lignes": lignes}
    if inconnu:
        r.update(statut="incomplet", total=None, raison="une ligne de prix a une valeur ou des convives inconnus")
    elif not valide:
        r.update(statut="non_valide", total=round(tot, 2), raison="lignes de prix non validées par le pro : montant indicatif seulement")
    else:
        r.update(statut="valide", total=round(tot, 2))
    return r


def calc(d):
    err = valider(d)
    if err:
        return {"statut_calcul": "invalide", "erreurs": err}
    conv = d["convives"]
    res = {"lignes": [], "par_categorie": {}, "inconnues": [], "avertissements": [], "bloquants": [],
           "production": {}, "production_partielle": False}
    res["confirmations"], res["exclus_documentes"] = [], []
    couvert = {}
    for l in d["lignes"]:
        cout, motif = eval_ligne(l, conv)
        if cout == 0 and not l.get("raison"):
            res["bloquants"].append(f"{l['id']}: zéro sans raison écrite (inconnue déguisée ?) : ajouter \"raison\" ou mettre null")
        # Un coût supporté reste un coût, qu'il soit refacturé, offert ou non au client.
        # Seule exclusion admise : paiement direct par le client, explicite ET documenté.
        exclu = False
        if l.get("paye_par") == "client":
            raison = l.get("raison_exclusion")
            if isinstance(raison, str) and raison.strip():
                exclu = True
                res["exclus_documentes"].append({"id": l["id"], "libelle": l["libelle"], "raison": raison.strip(),
                                                 "cout_non_supporte": cout})
            else:
                res["bloquants"].append(f"{l['id']}: paiement direct par le client déclaré sans raison_exclusion documentée : "
                                        "coût conservé tant que ce n'est pas documenté")
        if "facture" in l:
            res["confirmations"].append(
                f"{l['id']}: champ ancien « facture » ignoré pour le coût (un coût supporté reste un coût, même non refacturé ou offert) ; "
                "si le client paie cette ligne directement : paye_par=client + raison_exclusion ; sinon retirer le champ")
        if motif:
            res["inconnues"].append({"id": l["id"], "libelle": l["libelle"], "motif": motif})
        elif not exclu:
            cat = l.get("categorie", "autre")
            res["par_categorie"][cat] = round(res["par_categorie"].get(cat, 0) + cout, 2)
            for c in l.get("couvre", []):
                couvert.setdefault(c, []).append(l["id"])
        pr = production(l, conv)
        if pr:
            if pr[1] is None:
                res["production_partielle"] = True
            else:
                res["production"][pr[0]] = round(res["production"].get(pr[0], 0) + pr[1], 2)
        res["lignes"].append({"id": l["id"], "categorie": l.get("categorie"), "cout": cout,
                              "libelle": l["libelle"],
                              "statut": "inconnu" if motif else ("exclu_documente" if exclu else "chiffre")})
    for c, ids in couvert.items():
        if len(ids) > 1:
            res["avertissements"].append(f"double facturation possible de « {c} » : lignes {', '.join(ids)}")
    na = d.get("categories_non_applicables") or {}
    presentes = {l.get("categorie") for l in d["lignes"]}
    for c in ESSENTIELLES:
        if c not in presentes and not na.get(c):
            res["bloquants"].append(f"catégorie essentielle « {c} » absente : ajouter la ligne ou écrire la raison dans categories_non_applicables")
    for k in ("adultes", "enfants"):
        if conv.get(k) is None:
            lib = "d'adultes" if k == "adultes" else "d'enfants"
            res["bloquants"].append("nombre " + lib + " inconnu : à confirmer (une inconnue n'est pas 0)")
    res["cout_connu_total"] = round(sum(res["par_categorie"].values()), 2)
    n = total_convives(conv)
    res["convives"] = {"adultes": conv.get("adultes"), "enfants": conv.get("enfants"), "total": n}
    res["cout_connu_par_convive"] = round(res["cout_connu_total"] / n, 2) if n else None
    partiel = bool(res["inconnues"] or res["bloquants"])
    res["statut_calcul"] = "partiel" if partiel else "complet_a_valider"
    res["lecture"] = (f"PARTIEL : le total est un minimum de coût connu, jamais un prix. "
                      f"{len(res['inconnues'])} ligne(s) inconnue(s), {len(res['bloquants'])} point(s) bloquant(s)."
                      if partiel else
                      "Toutes les lignes sont chiffrées et expliquées ; cela reste une estimation que le pro valide.")
    fa = d.get("facturation") or {}
    bc = fa.get("base_couts")
    res["tva"] = "à confirmer par le pro" if fa.get("tva_taux") is None else f"{fa['tva_taux']} % (donnée du pro)"
    pc = prix_catalogue(d)
    res["prix"] = pc
    bp = pc.get("base")
    res["bases"] = {"couts": bc, "prix": bp, "coherentes": bc in BASES and bp in BASES and bc == bp}
    ctr = {"valeur": None, "taux_sur_prix_pct": None}
    if pc["statut"] != "valide":
        ctr["raison"] = "prix du catalogue " + {"non_renseigne": "non renseigné", "non_valide": "non validé par le pro", "incomplet": "incomplet"}[pc["statut"]] + " : pas de contribution"
    elif partiel:
        ctr["raison"] = "coûts partiels : pas de contribution (elle serait surévaluée)"
    elif not res["bases"]["coherentes"]:
        ctr["raison"] = (f"base coûts « {bc} » et base prix « {bp} » absentes ou différentes : "
                         "ne pas comparer ; convertir d'abord (la TVA est un champ du pro)")
    else:
        ctr["valeur"] = round(pc["total"] - res["cout_connu_total"], 2)
        ctr["taux_sur_prix_pct"] = round(100 * ctr["valeur"] / pc["total"], 1) if pc["total"] else None
        ctr["definition"] = ("prix validé − coûts supportés listés (même non refacturés) ; avant coûts fixes, trésorerie et charges non listées"
                             + ("; lignes exclues car payées directement par le client : voir exclus_documentes" if res["exclus_documentes"] else ""))
    res["contribution"] = ctr
    sc = d.get("scenario_objectif")
    if sc:
        if sc.get("choisi_par_pro") is not True:
            res["avertissements"].append("scenario_objectif ignoré : doit être choisi par le pro (choisi_par_pro=true)")
        elif partiel:
            res["avertissements"].append("scenario_objectif non calculé : coûts partiels")
        elif bc not in BASES:
            res["avertissements"].append("scenario_objectif non calculé : base des coûts (HT/TTC) non déclarée")
        else:
            res["scenario_marge"] = {
                "valeur": round(res["cout_connu_total"] / (1 - sc["marge_pct"] / 100), 2), "base": bc,
                "nature": "scénario facultatif choisi par le pro : coût / (1 − objectif). Ce n'est pas un prix validé."}
    return res


def cle_ligne(l):
    return {k: l.get(k) for k in ("mode", "valeur", "quantite", "libelle", "paye_par", "raison_exclusion", "facture")}


def lignes_diff(la_, lb_, conv_a, conv_b, nom, out):
    A = {l["id"]: l for l in la_ or []}
    B = {l["id"]: l for l in lb_ or []}
    for i in sorted(set(A) | set(B)):
        if i not in B:
            out["ecarts"].append(f"{nom} retirée: {i} ({A[i]['libelle']})")
        elif i not in A:
            out["ecarts"].append(f"{nom} ajoutée: {i} ({B[i]['libelle']})")
        elif cle_ligne(A[i]) != cle_ligne(B[i]):
            x, y = eval_ligne(A[i], conv_a)[0], eval_ligne(B[i], conv_b)[0]
            if x is not None and y is not None and x == y and conv_a == conv_b:
                out["ecarts"].append(f"{nom} {i}: quantité/prix/mode modifiés à total identique ({x:.2f}) : "
                                     f"{cle_ligne(A[i])} -> {cle_ligne(B[i])}")
            elif x is None or y is None:
                out["ecarts"].append(f"{nom} {i}: {x} -> {y} (inconnue)")
            else:
                out["ecarts"].append(f"{nom} {i} ({B[i]['libelle']}): {x:.2f} -> {y:.2f} ({y - x:+.2f})")
        else:
            x, y = eval_ligne(A[i], conv_a)[0], eval_ligne(B[i], conv_b)[0]
            if x != y:
                out["ecarts"].append(f"{nom} {i} ({B[i]['libelle']}): {x} -> {y}"
                                     + (f" ({y - x:+.2f})" if x is not None and y is not None else " (inconnue)"))


def diff(a, b):
    out = {"de": a.get("version"), "vers": b.get("version"), "ecarts": [], "champs_engageants_modifies": [],
           "production": {}, "avertissements": []}
    ea, eb = valider(a), valider(b)
    if ea or eb:
        out["erreurs"] = ea + eb
        out["validation"] = "comparaison impossible : données invalides"
        return out
    if (b.get("version") or 0) <= (a.get("version") or 0):
        out["avertissements"].append("la version suivante doit avoir un numéro supérieur")
    if a.get("ref_demande") != b.get("ref_demande"):
        out["avertissements"].append("références de demande différentes : sont-ce bien le même dossier ?")
    ra, rb = a.get("ref_demande"), b.get("ref_demande")
    ok_ref = all(isinstance(x, str) and x.strip() for x in (ra, rb)) and ra == rb
    out["identite_a_confirmer"] = not ok_ref
    if not ok_ref:
        out["avertissements"].append(f"identité du dossier non établie (références {ra!r} / {rb!r}) : confirmer qu'il s'agit du même dossier")
    for k in ENGAGEANTS:
        if a.get(k) != b.get(k):
            out["champs_engageants_modifies"].append(k)
    ca, cb = a["convives"], b["convives"]
    for k in ("adultes", "enfants"):
        if ca.get(k) != cb.get(k):
            out["ecarts"].append(f"convives {k}: {ca.get(k)} -> {cb.get(k)}")
    ga, gb = a.get("engagement") or {}, b.get("engagement") or {}
    for k in sorted(set(ga) | set(gb)):
        if ga.get(k) != gb.get(k):
            out["ecarts"].append(f"engagement.{k}: {ga.get(k)!r} -> {gb.get(k)!r}")
    for k in ("offre", "conditions", "description_client"):
        if a.get(k) != b.get(k):
            out["ecarts"].append(f"{k} modifié")
    lignes_diff(a.get("lignes"), b.get("lignes"), ca, cb, "ligne de coût", out)
    lignes_diff((a.get("prix_catalogue") or {}).get("lignes"), (b.get("prix_catalogue") or {}).get("lignes"),
                ca, cb, "ligne de prix", out)
    for k in ("facturation", "service", "categories_non_applicables"):
        if a.get(k) != b.get(k):
            out["ecarts"].append(f"{k} modifié")
    r1, r2 = calc(a), calc(b)
    out["cout_connu"] = {"avant": r1["cout_connu_total"], "apres": r2["cout_connu_total"],
                         "ecart": round(r2["cout_connu_total"] - r1["cout_connu_total"], 2),
                         "statut_avant": r1["statut_calcul"], "statut_apres": r2["statut_calcul"]}
    if r1["inconnues"] != r2["inconnues"]:
        out["avertissements"].append("le périmètre des inconnues a changé : ne pas comparer les totaux comme s'ils étaient équivalents")
    out["prix_catalogue_total"] = {"avant": r1["prix"].get("total"), "apres": r2["prix"].get("total")}
    for u in set(r1["production"]) | set(r2["production"]):
        x, y = r1["production"].get(u, 0), r2["production"].get(u, 0)
        out["production"][u] = {"avant": x, "apres": y, "ecart": round(y - x, 2)}
    if ca != cb:
        fixes = [i["id"] for i in b["lignes"] if i.get("mode") in ("forfait", "unitaire")
                 and cle_ligne(i) == cle_ligne(next((x for x in a["lignes"] if x["id"] == i["id"]), {}))]
        if fixes:
            out["a_reexaminer"] = ("convives modifiés mais ces lignes fixes n'ont pas bougé : " + ", ".join(fixes)
                                   + " (oubli ou raison à écrire ?)")
        if any(v["ecart"] > 0 for v in out["production"].values()):
            out["a_reexaminer_production"] = ("production en hausse : capacité de cuisson, stockage, froid et délai de "
                                              "préparation à revalider par le pro")
    changed = bool(out["champs_engageants_modifies"] or out["ecarts"])
    vstat = (a.get("validation") or {}).get("statut")
    validee = isinstance(vstat, str) and vstat.startswith("validee")
    if not ok_ref:
        out["validation"] = ("validation NON TRANSFÉRABLE : référence de demande différente, absente ou non résolue. Une validation ne passe "
                             "jamais d'un dossier à un autre ; confirmer l'identité du dossier, puis faire valider par le pro")
    elif changed and validee:
        out["validation"] = (f"la validation de la v{a.get('version')} est INVALIDE pour la v{b.get('version')} "
                             f"(champs engageants modifiés : {', '.join(out['champs_engageants_modifies']) or 'lignes'}) : "
                             "revalider avant tout envoi")
    elif changed:
        out["validation"] = (f"aucune validation de la v{a.get('version')} constatée dans les données : rien à conserver ; "
                             f"la v{b.get('version')} est à valider par le pro")
    elif validee:
        out["validation"] = ("même référence, aucun champ engageant ni ligne modifiés : la validation de la v"
                             f"{a.get('version')} est applicable à la v{b.get('version')} (dans la limite des champs comparés ; le pro confirme)")
    else:
        out["validation"] = "aucun écart et aucune validation constatée : à valider par le pro"
    out["nature"] = "estimation / sous-total, pas un devis ferme tant que le pro n'a pas validé et émis le devis"
    return out


def faisabilite(d):
    err = []
    valider_convives(d.get("convives"), err)
    valider_service(d.get("service"), err)
    if err:
        return {"verdict": "invalide : corriger les données", "erreurs": err}
    s = d.get("service")
    if not s:
        return {"verdict": "indéterminé", "a_demander": ["fenêtre de service", "portions par convive", "postes", "cadence"]}
    n = total_convives(d["convives"])
    manque = [k for k in ("fenetre_min", "portions_par_convive", "postes", "cadence_par_poste_min") if s.get(k) is None]
    if n is None:
        manque.insert(0, "convives (adultes et enfants)")
    if manque:
        return {"verdict": "indéterminé : ne pas conclure", "a_demander_au_pro": manque,
                "pourquoi": "ces données décident ; aucune valeur par défaut n'est supposée (inconnu ≠ 0)"}
    besoin = round(n * s["portions_par_convive"] / (s["postes"] * s["cadence_par_poste_min"]), 1)
    reste = round(s["fenetre_min"] - besoin, 1)
    r = {"convives": n, "temps_necessaire_min": besoin, "fenetre_min": s["fenetre_min"],
         "reste_min": reste, "ratio": round(besoin / s["fenetre_min"], 2)}
    marge = s.get("marge_securite_pct")
    if marge is None:
        r["verdict"] = "calcul fait ; marge de sécurité non fixée : le pro décide ce qui est acceptable"
    else:
        ok = besoin * (1 + marge / 100) <= s["fenetre_min"]
        r["verdict"] = "tient avec la marge fixée par le pro" if ok else "ne tient pas avec la marge fixée par le pro"
    r["hypothese"] = "file continue, cadence constante, sans pause ni incident"
    return r


def action_statut(f):
    st, dev, bro = f.get("statut"), f.get("devis_ref"), f.get("brouillon_ref")
    if st == "accepte":
        return "NE PAS relancer. Passer en préparation ; vérifier acompte/conditions du pro."
    if st == "rdv_pris":
        return "NE PAS relancer. Préparer le rendez-vous (dossier de décision à jour)."
    if st in ("refuse", "perdu"):
        return "Clore ; noter la raison si connue. Pas de relance."
    if dev and not bro:
        return (f"Devis {dev} déjà créé : le retrouver dans l'outil de devis par sa référence, ne PAS le recréer. "
                "Brouillon : une erreur de réponse Gmail ne prouve pas qu'il n'existe pas. CHERCHER d'abord un "
                "brouillon ou un message existant (destinataire, objet, référence) AVANT d'en créer un ; "
                "ne créer un brouillon que si la recherche ne trouve rien. Validation du pro avant envoi.")
    if dev and bro:
        return f"Devis {dev} et brouillon {bro} référencés : vérifier leur état (envoyé ou non) avant toute action."
    if bro:
        return "Brouillon référencé sans devis : chercher le devis (contact + date) avant de recréer."
    return ("Aucune référence de devis dans la fiche : AVANT de recréer, chercher dans l'outil de devis (contact + date) "
            "et dans Gmail ; une panne peut avoir créé un objet sans écrire sa référence.")


def reprise(d):
    reg, ent = d["registre"], d["entrant"]
    ref = ent.get("ref_demande")
    if ref:
        trouvees = [f for f in reg if f.get("ref_demande") == ref]
        if len(trouvees) > 1:
            return {"decision": "À CONFIRMER : référence présente plusieurs fois dans le registre",
                    "action": "corriger le registre (une référence = une demande) avant toute action"}
        if not trouvees:
            return {"decision": "À CONFIRMER : référence inconnue du registre",
                    "action": "vérifier la référence (faute de frappe ? autre registre ?) ; ne pas créer de fiche tant que non confirmé"}
        f = trouvees[0]
        v_e, v_f = ent.get("version_devis"), f.get("version_devis")
        if v_e is not None and v_f is not None:
            if v_e > v_f:
                return {"decision": "Même demande : nouvelle version à enregistrer (version reçue > version du registre)",
                        "fiche": ref, "action": "enregistrer la version, invalider l'ancienne validation (voir diff)"}
            if v_e < v_f:
                return {"decision": "Même demande : version reçue périmée (le registre est plus récent)",
                        "fiche": ref, "action": f"ne pas utiliser la version {v_e} ; version courante {v_f}. " + action_statut(f)}
        return {"decision": "REPRISE de la même demande (référence trouvée, unique)", "fiche": ref, "action": action_statut(f)}
    c, dt, oc = ent.get("contact_id"), ent.get("date_evenement"), ent.get("occasion")
    manque = [k for k, v in (("contact_id", c), ("date_evenement", dt), ("occasion", oc)) if not v]
    memes = [f for f in reg if c and f.get("contact_id") == c]
    if manque:
        return {"decision": "À CONFIRMER : identifiants insuffisants pour décider (" + ", ".join(manque) + " absent)",
                "candidats": [f["ref_demande"] for f in memes],
                "action": "demander la référence ou compléter les identifiants ; ni doublon ni nouvelle fiche affirmés"}
    for f in memes:
        if (f.get("contact_id"), f.get("date_evenement"), f.get("occasion")) == (c, dt, oc):
            return {"decision": "DOUBLON PROBABLE (même contact, même date, même occasion) : à confirmer par le pro",
                    "fiche": f["ref_demande"],
                    "action": "ne pas créer de fiche avant confirmation ; puis : " + action_statut(f)}
    if memes:
        return {"decision": "NOUVELLE demande, même contact (autre événement ≠ doublon)",
                "liee_a": [f["ref_demande"] for f in memes],
                "action": "créer une nouvelle fiche et une nouvelle référence ; ne pas reprendre le devis de l'autre événement."}
    return {"decision": "NOUVELLE demande, contact absent du registre",
            "action": "créer la fiche et la ref_demande (chercher d'abord le contact sous une autre adresse)"}


def suite(f):
    st, last, jours = f.get("statut"), f.get("dernier_message"), f.get("jours_depuis_derniere_action")
    if st == "accepte":
        return {"choix": "ne_pas_relancer", "pourquoi": "devis accepté", "action": "préparer la prestation"}
    if st == "rdv_pris":
        return {"choix": "ne_pas_relancer", "pourquoi": "rendez-vous déjà pris",
                "action": "préparer le rendez-vous ; rappel du créneau seulement si le pro le souhaite"}
    if st in ("refuse", "perdu"):
        return {"choix": "ne_pas_relancer", "pourquoi": "demande close", "action": "clore"}
    if last == "question":
        return {"choix": "clarifier", "pourquoi": "le client a posé une question précise",
                "action": "répondre à la question (une, nette), avant tout rappel du devis"}
    if last in ("objection_prix", "objection_complexe", "plusieurs_variables"):
        return {"choix": "proposer_rdv", "pourquoi": "l'objection se traite à plusieurs variables (périmètre, portions, services)",
                "action": "proposer un échange court + variantes chiffrées si le pro valide"}
    if last == "silence":
        dl = f.get("delai_relance_jours")
        if dl is None:
            return {"choix": "delai_a_definir", "pourquoi": "délai de relance non fourni",
                    "action": "demander au pro quel délai il retient ; ne pas inventer"}
        if jours is not None and jours >= dl:
            return {"choix": "relancer", "pourquoi": f"silence depuis {jours} j (délai du pro : {dl} j)",
                    "action": "relance courte référant au devis et à la date de l'événement"}
        return {"choix": "attendre", "pourquoi": f"délai du pro ({dl} j) non atteint ou durée inconnue", "action": "rien"}
    return {"choix": "a_confirmer", "pourquoi": "dernier message du client inconnu ou non prévu : ce n'est pas un silence",
            "action": "relire l'échange avant de choisir"}


def e(x):
    return htmllib.escape(str(x))


def euro(x):
    return f"{x:,.2f} €".replace(",", " ").replace(".", ",")


def rendre_html(d, modele):
    """Proposition CLIENT : offre, convives, prix de vente VALIDÉ par le pro, conditions. Aucun coût interne."""
    err = valider(d)
    if err:
        raise ValueError("données invalides : " + "; ".join(err))
    pc = prix_catalogue(d)
    base = pc.get("base") or "base à confirmer"
    if pc["statut"] == "valide":
        lignes = "".join("<tr><td>%s</td><td class='r'>%s</td></tr>" % (e(l["libelle"]), euro(l["montant"]))
                         for l in pc["lignes"])
        lignes += "<tr class='total'><td>Total (%s)</td><td class='r'>%s</td></tr>" % (e(base), euro(pc["total"]))
        prix = "<table><tbody>%s</tbody></table>" % lignes
    else:
        prix = "<p><strong>Montant : à confirmer par le professionnel.</strong> Aucun prix n'est affiché tant qu'il n'est pas validé.</p>"
    conv, eng = d["convives"], d.get("engagement") or {}

    def nombre(x):
        return "à confirmer" if x is None else x
    detail = "".join("<li>%s : %s</li>" % (e(k), e(v)) for k, v in
                     (("Date", eng.get("date_evenement")), ("Lieu", eng.get("lieu")),
                      ("Horaires", eng.get("horaires")), ("Menu", eng.get("menu"))) if v)
    rep = {"REF": e(d.get("ref_demande", "")), "VERSION": e(d.get("version", "")), "OFFRE": e(d.get("offre", "")),
           "DESCRIPTION": e(d.get("description_client", "")),
           "ADULTES": nombre(conv.get("adultes")), "ENFANTS": nombre(conv.get("enfants")),
           "DETAIL": detail, "PRIX": prix,
           "TVA": e("à confirmer par le professionnel" if (d.get("facturation") or {}).get("tva_taux") is None
                    else f"{d['facturation']['tva_taux']} %"),
           "A_CONFIRMER": "".join("<li>%s</li>" % e(x) for x in d.get("a_confirmer_client", [])) or "<li>Rien de plus à ce stade.</li>",
           "CONDITIONS": e(d.get("conditions", "à fournir par le professionnel"))}
    for k, v in rep.items():
        modele = modele.replace("{{" + k + "}}", str(v))
    return modele


def main(a):
    if len(a) < 3:
        print(__doc__)
        return 2
    cmd = a[1]
    try:
        if cmd == "calc":
            r = calc(load(a[2]))
        elif cmd == "diff":
            r = diff(load(a[2]), load(a[3]))
        elif cmd == "faisabilite":
            r = faisabilite(load(a[2]))
        elif cmd == "reprise":
            r = reprise(load(a[2]))
        elif cmd == "suite":
            r = suite(load(a[2]))
        elif cmd == "html":
            with open(a[3], encoding="utf-8") as f:
                print(rendre_html(load(a[2]), f.read()))
            return 0
        else:
            print(__doc__)
            return 2
    except (ValueError, IndexError, KeyError) as ex:
        print(json.dumps({"erreur": f"{type(ex).__name__}: {ex}"}, ensure_ascii=False))
        return 1
    print(json.dumps(r, ensure_ascii=False, indent=2))
    return 1 if r.get("statut_calcul") == "invalide" else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
