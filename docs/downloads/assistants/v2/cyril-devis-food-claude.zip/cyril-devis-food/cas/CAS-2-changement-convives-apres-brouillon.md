# Cas 2 (fictif) — 60 adultes deviennent 75 après un brouillon

Fictif ; hypothèses de coûts à remplacer. Fichiers : `cas2-devis-v1.json`, `cas2-devis-v2.json`, `cas2-apercu-proposition-v2.html`.

## Entrée
Brouillon v1 prêt (repas assis brasero, 60 adultes). Message du client : « Finalement nous serons 75. Vous pouvez mettre à jour ? »

## Réponse attendue
**1. Nouvelle version, pas une correction silencieuse** — v2 créée, v1 conservée (v1 « validée par le pro » dans les données fictives). `diff` :
- coûts : viandes +93,00 ; accompagnements +31,50 ; pain +6,75 ; emballages +4,50 ; vaisselle +18,00 ; personnel +184,00 (3 personnes × 8 h au lieu de 2, à faire valider). **Coûts 1 113,00 € → 1 450,75 € (+337,75 €).** Production 25,2 → 31,5 kg.
- **Prix du catalogue validé** (fictif : 32,00 € HT par adulte, `valide_par_pro`) : 1 920,00 € → 2 400,00 € HT. Contribution (prix − coûts, mêmes bases HT) : 807,00 € (42,0 %) → 949,25 € (39,6 %). Le coût par adulte monte (18,55 → 19,34 €) parce que l'équipe passe à 3 : le prix par adulte fixe ne suit pas ; décision du pro, pas du script.
- Scénario facultatif choisi par le pro (objectif 35 % sur coûts) : 1 712,31 € puis 2 231,92 € HT. **Ce n'est pas un prix validé** ; il sert seulement de comparaison avec le catalogue (ici le catalogue est au-dessus).

**2. Ce que le script dit en plus** : `a_reexaminer` : trajet, installation et nettoyage n'ont **pas bougé** alors que +25 % de convives : oubli ou raison ? Et production en hausse : capacité de cuisson/brasero, froid, délai de préparation **à revalider par le pro**.

**3. Faisabilité** — fenêtre 20 min, 1 portion, cadence 2,5 portions/min/poste (hypothèse fictive du pro) : 60 convives, 2 postes = 12 min ; 75 convives avec 3 postes = 10 min. Cela dépend entièrement de la cadence ; si elle reste 2 postes, 75 = 15 min (reste 5 min). La marge de sécurité est fixée par le pro.

**4. Ancienne validation invalide** : « la validation de la v1 est INVALIDE pour la v2 (champs engageants modifiés : convives, service) ». Le script invalide aussi si date, lieu, menu, conditions ou prix changent, ou si quantité × prix change à total identique. Rien n'est envoyé avant que le pro valide la v2. Le sous-total n'est pas un devis ferme.

**5. Brouillon de réponse**
> Merci de la précision. Passer de 60 à 75 convives change les quantités et l'équipe prévue ; je mets à jour votre proposition et je reviens vers vous avec la nouvelle version (v2) après vérification de notre capacité. L'ancienne version ne s'applique plus. [signature]

**6. Statut** — `brouillon_pret` (v2). Prochaine action : le pro valide quantités, équipe, capacité, prix, TVA, conditions ; puis émission du devis ferme dans son outil.

## Pourquoi ces choix
- Versionner évite qu'un client accepte l'ancien chiffre sur le nouvel effectif.
- Montrer les lignes fixes inchangées attrape l'erreur classique : ne recalculer que ce qui est « par personne ».
- Réponse générique à écarter : « 75 × prix par personne » — oublie personnel, nettoyage, capacité, et laisse l'ancien devis valable.
