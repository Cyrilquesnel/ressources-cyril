# Cas 3 (fictif) — Panne Gmail après création du devis ; même contact, deux événements ; relance ou pas

Fictif. Fichiers : `cas3-reprise*.json`, `suite-*.json`. Aucun envoi, aucun accès à Pennylane/Gmail : le script lit un registre simulé.

## Situation
Le registre contient : DEM-FICT-0201 (Camille Exemple, mariage 12/06/2027, `devis_ref FICT-DEV-0042`, **brouillon_ref vide**, statut `devis_pennylane_cree`, « panne Gmail avant le brouillon »), DEM-FICT-0202 (devis accepté), DEM-FICT-0203 (rendez-vous pris).

## A. Le client réécrit sur la même demande (`cas3-reprise-meme-demande.json`)
Réponse : **REPRISE** (référence trouvée, unique). Ne pas recréer le devis : le retrouver par sa référence. Pour le brouillon : l'erreur de réponse de Gmail ne prouve pas qu'il n'existe pas ; **chercher d'abord** un brouillon ou un message existant (destinataire, objet, référence), n'en créer un que si la recherche ne trouve rien ; validation du pro.

## B. Formulaire renvoyé : même contact, même date, même occasion (`cas3-reprise-doublon.json`)
Réponse : **doublon probable**, ne pas créer de fiche ; le pro confirme ; puis même action qu'en A.

## C. Même contact, anniversaire le 04/09/2027 (`cas3-reprise.json`)
Réponse : **nouvelle demande liée** (DEM-FICT-0201 en lien). Nouvelle référence, nouvelle offre, nouveau devis. **Ne pas** reprendre le devis du mariage. Deux événements ≠ doublon.

## C bis. Identifiants absents, référence inconnue, nouvelle version (`cas3-reprise-identifiants-absents.json`, `-reference-inconnue.json`, `-version-nouvelle.json`)
- Message sans contact ni date (« mariage, domaine des Tilleuls ») : **À CONFIRMER**. Ni doublon, ni nouveau contact : on demande la référence ou les identifiants.
- Référence `DEM-FICT-0299` absente du registre : **À CONFIRMER** (faute de frappe ? autre registre ?), pas de nouvelle fiche.
- Référence trouvée avec version 2 alors que le registre est en version 1 : **nouvelle version** à enregistrer, l'ancienne validation est invalidée (voir `diff`). La référence unique et la version priment sur le reste.

## D. Et si la fiche n'avait pas de `devis_ref` ?
Le script répond : « AVANT de recréer, chercher dans l'outil de devis (contact + date) ». La panne peut avoir créé le devis sans écrire la référence ; recréer sans chercher produirait deux devis pour un même événement.

## E. Relancer, clarifier ou RDV ? (`suite-*.json`)
| Fiche | Résultat | Raison |
|---|---|---|
| DEM-FICT-0202 accepté | ne pas relancer | acceptation : passer à la préparation, pas de relance vague |
| DEM-FICT-0203 rdv pris | ne pas relancer | préparer le rendez-vous |
| client pose une question | clarifier | répondre précisément avant tout rappel |
| objection de prix | proposer un RDV | plusieurs variables ; variantes validées par le pro |
| dernier message inconnu | à confirmer | un message inconnu n'est pas un silence |
| silence 9 j, délai du pro non fourni | délai à définir | on ne l'invente pas |
| silence 9 j, délai du pro 7 j | relancer | délai dépassé, relance courte |

## Brouillon (cas A, à relire par le pro)
> Bonjour Camille, désolé pour le délai : j'ai bien votre demande pour le mariage du 12 juin 2027. Je vous renvoie votre proposition dans la journée après une dernière vérification. [signature]
(« dans la journée » = engagement du pro : à retirer ou confirmer par lui.)

## Statut et prochaine action
DEM-FICT-0201 : `devis_pennylane_cree` → après brouillon recréé : `brouillon_pret`, validation du pro avant envoi.

## Pourquoi ces choix
Retrouver avant de recréer évite doublons de devis et numérotation incohérente ; la clé contact+date+occasion évite à la fois le double traitement et la fusion abusive de deux événements ; ne pas relancer un accepté ou un RDV évite l'erreur de circuit la plus visible pour le client.
