# Cas 1 (fictif) — Cocktail debout demandé, offre du catalogue = repas assis, demande incomplète

Tous les noms et chiffres sont **fictifs**. Les coûts unitaires sont des hypothèses de démonstration, à remplacer par ceux du pro. Fichier de calcul : `cas1-devis-v1.json`.

## Entrée (message reçu)
« Bonjour, l'association *Les Amis du Vélo d'Antan* (fictive) fête ses 10 ans à la salle des fêtes de Saint-Exemple (fictive). On sera environ 80, un cocktail debout, 2 heures en soirée. On a nos assiettes et nos verres. Pouvez-vous nous faire un devis ? »
Catalogue du pro (fictif) : « Repas assis 3 temps ».

## Réponse attendue de l'assistant

**1. Offre** — Le catalogue ne convient pas tel quel : repas assis servi à table ≠ cocktail debout 2 h. Ce qui change : unité de production (pièces), service en circulation, personnel, installation, durée, allergènes sur buffet. → **offre adaptée**, nommée « cocktail dînatoire debout », avec l'écart écrit. Ne pas renommer « Repas assis » en « Cocktail ».

**2. Calcul partiel possible** (`devis_outils.py calc cas1-devis-v1.json`) :
- matières 696,00 € (8 pièces salées + 2 sucrées × 80 adultes = 800 pièces), emballages 28,00 €, vaisselle 0 **avec raison** (le client fournit).
- **Total chiffré 724,00 € = minimum de coût connu, statut PARTIEL.** Pas de prix, pas de contribution.
- **Enfants non précisés = inconnu, pas 0** : le total de convives et le coût par convive restent non calculés (`null`), et le nombre d'enfants est listé comme point bloquant.
- 5 lignes inconnues : préparation (taux horaire), service (heures et taux), trajet, installation, nettoyage/retour vaisselle. Elles ne valent pas zéro.
- **Prix** : « non renseigné ». Le prix de cette offre adaptée est celui que le pro valide ; le calcul ne le devine pas. L'aperçu client (`cas1-apercu-proposition.html`) affiche donc « Montant : à confirmer par le professionnel », sans aucun coût interne.

**3. Faisabilité** — fenêtre 120 min, 10 pièces/convive, 2 postes : `faisabilite` répond « indéterminé : ne pas conclure » ; il manque le **total de convives** (enfants inconnus) et la **cadence réelle d'un poste**. (Un service en circulation s'organise autrement qu'en file : le pro dit comment il compte servir.)

**4. Points qui changent le devis** (seulement ceux-là) :
| Question | Pourquoi |
|---|---|
| Enfants présents ? Combien ? | total de convives, pièces et coût par enfant : sans lui rien n'est conclu |
| Froid, électricité, accès véhicule sur place ? | décide matériel, installation, faisabilité |
| Allergènes/régimes ? | change les pièces et le contact croisé sur buffet |
| Heure de remise des plats et de fin ? | personnel et heures |
Pas demandés : budget, goûts, boissons (client gère), tout ce qui ne bouge pas le chiffre. Ni « 8 questions de rituel ».

**5. Vaisselle** — le client la fournit : on retire la **location**, on garde nettoyage/retour et manutention (lignes `nettoyage`, `install`). Aucune réduction automatique « parce qu'il apporte ses assiettes ».

**6. Brouillon de réponse (à relire par le pro)**
> Bonjour, merci pour votre demande. Pour 80 personnes en cocktail debout de 2 h, nous partons sur une formule adaptée (pièces à partager, service en circulation) plutôt que sur notre repas assis. Pour vous donner un montant fiable, il me manque : l'accès et l'équipement de la salle (froid, électricité, accès véhicule), les allergènes à prévoir, la présence éventuelle d'enfants et l'heure de fin. Dès que j'ai ces points, je prépare votre proposition chiffrée. [signature]
Aucun prix ni délai annoncé.

**7. Statut et prochaine action** — `info_manquante`. Prochaine action : le pro valide et envoie la demande d'informations ; il fournit aussi ses taux et son prix pour l'offre adaptée ; ensuite nouveau calcul v2.

## Pourquoi ces choix
- Calcul partiel > refus de chiffrer : le client voit l'ordre de grandeur des matières, le pro voit ce qui manque.
- Inconnues listées > zéros : un total partiel présenté comme complet sous-facturerait personnel et trajet.
- Réponse générique à écarter : « voici notre repas assis à X €/pers, dites-nous le budget » — mauvais format, aucun écart, aucune question utile.
