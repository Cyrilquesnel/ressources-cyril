# Trois cas fictifs, trois décisions différentes

**Tout est fictif** : personnes, entreprises, prix, coûts, temps. Les chiffres servent à montrer le raisonnement et à tester le script ; ce ne sont ni des prix de marché, ni des résultats, ni des coûts de Cyril. Les temps de service sont des **hypothèses de départ, pas une capacité certifiée** : à chronométrer avant tout engagement. Les prix des exemples sont des prix **HT** fictifs ; un budget client TTC ne se compare pas directement. Fichiers d'entrée : `exemples/entree-*.json` ; exécutions réelles : `exemples/sortie-*.txt` (lancées avec `python3 -I scripts/chiffrer_prestation.py`).

Un assistant qui répond « proposez 3 formules (Essentiel / Confort / Premium) avec des bonus » rate ces trois cas : le problème n'est pas le nombre de niveaux.

---

## Cas 1 — Entreprise à horaire serré (Delmas Conseil, fictif)

**Entrée (ce que dit la personne).** « Un cabinet de 36 personnes veut un déjeuner d'équipe dans sa cour. Pause de 12 h 15 à 13 h 30. L'office manager veut que ça tienne l'horaire et que chacun puisse choisir. J'hésite à proposer 3 plats au choix sur place, ça fait vendre. »

**Décisionnaire et critère.** L'office manager. Hypothèse : le critère n°1 est de **ne pas déborder** (75 min). À vérifier d'une question : « 13 h 30, c'est dur ? ».

**Offre séduisante écartée : A, carte libre, 3 plats au choix sur place.**
Pourquoi elle séduit : choix, sensation de service sur mesure. Pourquoi on l'écarte :
- Débit. Hypothèse à chronométrer : 40 s par personne avec 2 plats fixes + 1 végétarien servis déjà prêts ; ~100 s par personne quand chacun compose sur place. Pour 36 personnes sur **un** point : 24 min contre 60 min. Avec 60 min de service pour 75 min de pause, la marge devient mince : la dernière personne serait servie vers 13 h 15 si l'hypothèse se confirme. C'est ce qu'il faut mesurer, pas une certitude.
- Chiffrage (script) : A a 6 références ouvertes (matière 4,90 €/pers) et 3 personnes ; sa contribution provisoire est de **182,40 €**. B (3 références, matière 4,20 €/pers, 2 personnes) donne **220,60 €**, avec un prix plus bas (13,50 contre 14,50 €/pers). Le prix client plus élevé de A ne compense pas son coût en matière et en équipe.
- Dans les deux cas, le trajet est **inconnu** : les deux contributions sont des plafonds.

**Réponse attendue (offre B).**
- Base : 2 plats + 1 végétarien, mêmes accompagnements, sans composition sur place.
- Choix fait **avant** : pré-commande par lien ou liste, avec date limite (ex. J−3, à fixer par le pro), régimes/allergies déclarés à ce moment (validés par le pro).
- Service : 2 points de service, remise à l'heure annoncée, fin de service annoncée dans la proposition **seulement après le test chronométré**.
- Minimum : 25 convives en dessous desquels on propose autre chose (fixé ici, fictif).
- Responsabilités : le client indique l'emplacement, l'accès électrique/eau s'il le faut, les tables ; nous : cuisine, service, déchets de notre production (à confirmer).

**Essai.** Chronométrer le service d'une portion test de B avec 2 personnes sur 12 convives réels (équipe, famille) ; critère de réussite : tout le monde servi en moins de la moitié du créneau. Sinon : réduire à 2 plats ou passer en paniers individuels.

**Ce que le skill ne fait pas ici.** Il n'invente pas le temps de service, ni le prix « normal d'un déjeuner d'équipe ».

---

## Cas 2 — Mariage : expérience, vaisselle, service (Léa et Karim, fictifs)

**Entrée.** « 90 invités, cuisson sur brasero devant les invités, les mariés hésitent sur la vaisselle. Je voudrais proposer tout compris, vaisselle comprise, lavée sur place. Je n'ai pas encore appelé de loueur. »

**Décisionnaire et critère.** Les mariés ; hypothèse : la **sérénité** (« on n'a pas à s'en occuper ») et le moment de cuisson visible comptent plus que le détail du menu. Une question à poser : « Qui s'occupe de la vaisselle et du rangement le soir ? Le lieu permet-il un lavage ? »

**Offre séduisante écartée : A, vaisselle lavée sur place par nous.**
- Chiffrage (script) : A à 60 €/pers : contribution provisoire **3 750 €** (plafond) avec 2 inconnues dont la location de vaisselle, disponibilité **non confirmée**. B à 55 €/pers, vaisselle à la charge du client via un loueur : **3 480 €** (plafond), 1 inconnue.
- Dans le JSON, la vaisselle de A est réalisée par un loueur **et payée par nous** (coût à compter, inconnu pour l'instant) ; celle de B est réalisée par le loueur du client **et payée directement par lui** (hors de notre prix, écrit comme tel). Sans cette distinction explicite, un prestataire ne devient jamais un coût nul.
- A paraît meilleure de 270 €. C'est une illusion : A facture 450 € de plus que B mais coûte déjà 180 € de plonge supplémentaire ; il reste **270 €** pour couvrir la location et la casse pour 90 convives, soit **3,00 €/convive**. Si un loueur réel dépasse ce seuil, A rapporte moins que B. Le seuil dépend des prix fictifs de l'exemple ; le principe vaut : **tant que l'inconnue n'est pas chiffrée, A n'est pas comparable.**
- Risque non chiffré par le script : une soirée où l'équipe de cuisson immobilisée à plonger ne peut pas remballer le brasero.

**Réponse attendue.**
- Offre retenue : **B**, « Brasero devant vos invités, vaisselle selon votre choix ».
- Vaisselle : option **sous réserve de disponibilité confirmée** (nom du loueur, dates, prix) tant que le pro n'a pas appelé. En attendant, la proposition dit « à la charge du client, avec notre liste de besoins ».
- Expérience limitée : **une pièce signature au brasero**, le reste d'accompagnements prêts. Pourquoi : 90 pièces à la minute créent un goulot que la capacité de cuisson n'a pas démontré tenir.
- Minimum : 60 convives (fictif) ; en dessous, autre format (sans brasero) proposé.

**Capacité (inconnue décisive).** La cuisson de 90 portions sur le brasero n'est **pas connue**. Essai : cuire le nombre de pièces prévu pour 30 convives sur le matériel réel, noter durée, nombre de personnes, combustible ; rapporter à 90 en gardant une marge ; si trop long, plusieurs braseros ou pré-cuisson partielle (à valider avec les règles de sécurité du lieu).

**Aussi à confirmer avant engagement ferme :** autorisation du lieu pour le feu, plan B météo, qui est présent côté mariage pour la coordination.

---

## Cas 3 — Anniversaire adultes/enfants, faible volume (Noémie, fictive)

**Entrée.** « 18 personnes : 12 adultes, 6 enfants. La maman veut un pack tout compris : repas, gâteau, déco, animation. Je me demande si je fais un menu enfants à part. »

**Décisionnaire et critère.** La maman : **une chose de moins à gérer**. Hypothèse à vérifier : les enfants mangent ce qu'on leur donne si c'est simple.

**Offre séduisante écartée : A, pack tout compris.**
- Dans A, « gâteau » et « déco + animation » n'ont ni responsable, ni coût, ni disponibilité : 3 inconnues (avec le trajet) pour un prix de 360 €. Contribution provisoire **134 €**, plafond.
- B : menu commun, portions adaptées pour enfants, minimum 350 €, 1 seule inconnue (trajet) : **167 €**. B laisse gâteau et déco **à la charge du client** (écrit) ou en option avec un prestataire nommé.
- Un menu enfants entièrement séparé peut ajouter de la préparation pour 6 enfants : à peser selon la capacité de l'équipe. Piste proposée ici : **même préparation, portion, assaisonnement et montage adaptés** (à valider par le pro, allergènes compris) ; une variante à préparation séparée n'est justifiée que si un besoin réel l'exige.

**Minimum de prestation, test avec B′ (8 convives, 190 €).** Contribution provisoire 62 € pour la même équipe et le même trajet : sous le minimum de 350 € de l'exemple, le script renvoie « NON respecté ». Décision proposée : le minimum est un choix commercial du pro, ici fixé à 350 € ; avec seulement 62 € de contribution provisoire, il choisit de **ne pas baisser le prix** et de proposer un autre format (par exemple plateaux à retirer, sans équipe sur place) ou on refuse poliment.

**Essai.** Faire goûter la base commune adaptée à 2-3 enfants (de l'entourage) pour vérifier qu'elle passe ; critère : l'assiette revient vide ou presque. Sinon, ajouter UNE variante précise.

**À ne pas conclure.** Le skill n'affirme pas que « les enfants aiment les tenders » comme fait de marché ; c'est le vécu déclaré de Cyril (voir `experience-cyril.md`) qui montre une préparation réutilisée dans plusieurs offres, pas un résultat de vente.

---

## Ce que ces trois cas montrent
| Cas | Le piège séduisant | Ce qui décide | Ce qui n'est pas connu |
|---|---|---|---|
| 1 Entreprise | Choix libre sur place | Débit dans 75 min | Temps de service réel, trajet |
| 2 Mariage | Tout compris avec vaisselle | Seuil de coût de la vaisselle, capacité de cuisson | Loueur, cuisson de 90, trajet/combustible |
| 3 Anniversaire | Pack avec gâteau/déco/animation | Responsables absents ; minimum de prestation | Trajet, goût des enfants |
