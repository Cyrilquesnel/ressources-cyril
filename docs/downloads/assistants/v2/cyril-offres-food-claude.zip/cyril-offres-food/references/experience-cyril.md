# Expérience déclarée de Cyril Quesnel (à utiliser avec ses limites)

Source : synthèse des vocaux du 10 novembre 2026 (`strategie-3-mois/references/faits-editoriaux-vocaux-2026-11-10.md`) et archive intégrale `reponses-integrales-cyril-2026-11-10.md`, plus `faits-editoriaux-entretien-2026-11-09.md`. Ce sont des **déclarations**, non vérifiées indépendamment. Elles ne deviennent ni un résultat chiffré ni une méthode universelle.

## Ce qu'il a déclaré, utile pour les offres
- **Offres par cible.** Au Lunch Wagon, il avait créé des formulaires et des offres/packs distincts pour **anniversaires, événements d'entreprise et mariages**, réunis dans un **catalogue en ligne**. On y demandait notamment le nombre de convives et les menus enfants.
- **Constat personnel.** Les clients veulent comprendre vite et recevoir une proposition claire rapidement. Ce n'est pas une enquête de clientèle.
- **Réutiliser une préparation.** Ses aiguillettes de poulet panées (cornflakes) servaient en formule enfant, tapas/snack et burger. À La Verrerie, il conseille de réutiliser un même produit dans plusieurs recettes pour limiter la perte. C'est son objectif de gestion, pas un résultat mesuré.
- **Événements.** Il juge l'événementiel plus facile pour anticiper les équipes et pour le spectacle ; il recommande d'avancer les gros événements, les prestations privées sur devis, les tickets plus élevés et le brasero (flammes, fumée, cuisson devant les clients). Opinion, pas supériorité universelle.
- **Mariages et événements volumineux.** Il évoque des devis, visites et menus dégustation pour des événements privés, un mariage d'environ 300 personnes, des événements de 400-600 personnes par service. Établissement, date, équipe et mesure sont à préciser : ne pas les utiliser comme cas chiffré.
- **Minimums et quantités.** Il insiste sur les minimums de commande et les colis des fournisseurs ; cela s'étend par analogie, pas par déclaration, au minimum de prestation (voir ci-dessous).
- **Prix.** Son jugement sur un pain à 0,50 € incompatible avec la qualité qu'il veut : opinion personnelle, non un minimum.

- **Circuit de devis déclaré.** Formulaire → n8n → devis Pennylane → brouillon Gmail → validation de Cyril avant envoi ; relances prévues et bouton de rendez-vous pour parler du devis.

## Ce qui n'est PAS dit par Cyril (donc interdit de lui attribuer)
- Les **8 arbitrages**, la distinction 3 occasions / 3 niveaux, la règle « inclusion = coût + responsable + disponibilité » et le **minimum de prestation** sous forme de seuil : **propositions de ce skill**, pas sa méthode personnelle historique.
- Les cas fictifs (Delmas Conseil, Léa et Karim, Noémie) et leurs chiffres.
- Un taux de conversion, un temps gagné, des demandes par jour (il cite des captures de boîte mail, pas une moyenne), un chiffre d'affaires d'événement, des prix de marché.
- La fourchette de prix 40–100 € évoquée : **ni relevé de marché, ni règle**.

## À retrouver pour refléter pleinement son jugement
- Catalogue en ligne, formulaires, packs, devis types et leurs prix réels.
- Un mariage ou un événement réel : durée, équipe, nombre de convives réellement servis, ce qui a été inclus/refusé, ce qui s'est mal passé.
- Minimums qu'il appliquait (prix, convives), conditions et acomptes.
- Pourquoi il a écarté certaines offres, concrètement (la leçon la plus précieuse).
- Réponse à : qui lavait la vaisselle, qui coordonnait, quelles responsabilités écrites dans ses devis ?
- Le domaine transcrit « lunchvagon.fr » est à vérifier avant tout lien.

## Comment l'utiliser dans une réponse
Dire : « Cyril a déclaré avoir … » pour le vécu. Dire : « Je propose … » pour les règles du skill. Dire : « Selon [auteur], … » pour un mécanisme cité.
