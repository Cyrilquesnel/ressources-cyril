# Les 8 arbitrages d'une offre food

Nature : **méthode proposée** par ce skill, adaptée aux indépendants. Elle est à tester dans votre contexte, elle n'a pas été éprouvée comme méthode exclusive. Les mécanismes d'auteurs (Hormozi/Acquisition.com, Strategyzer) servent à structurer le raisonnement (voir `sources.md`).

Pour chaque arbitrage : la question, ce qui fait pencher, le piège, et l'effet sur la sortie.

## 1. Occasion et décisionnaire
**Question.** Qui valide, sur quel critère, avec quelle contrainte non négociable ?
- *Entreprise* : l'office manager ou l'assistant(e) cherche surtout à **ne pas avoir de problème** (horaire tenu, pas de surprise, facture propre). Contrainte typique : une pause courte. Hypothèse à vérifier, pas une enquête.
- *Mariage* : un couple (parfois les familles) décide ; l'enjeu est la **confiance** et le souvenir. Contrainte : le déroulé de la journée, dont vous n'êtes qu'un maillon.
- *Anniversaire* : un parent ou un organisateur veut **une chose de moins à gérer**, avec des adultes et des enfants aux besoins différents. Volume faible, donc minimum de prestation souvent central.
**À examiner.** Une même offre peut couvrir plusieurs occasions si elle répond aux besoins réels de chacune (horaire, sérénité, adultes/enfants). Ce qui compte : la proposition nomme-t-elle le problème de **ce** décisionnaire, et la cuisine tient-elle les contraintes de chaque occasion couverte ? Séparer les offres quand les contraintes divergent (débit, minimum, responsabilités), pas par principe.
**Effet.** Nommer l'offre par le problème résolu (« Pause de 75 min tenue »), pas par un adjectif ; une offre par occasion ou une offre commune selon ce que les contraintes permettent.

## 2. Standard ou sur-mesure
- Standard si la demande se répète et que la cuisine prépare à l'avance.
- Sur-mesure si le client a une exigence que le standard ne couvre pas **et** accepte un prix/délai associé.
**Test.** Le sur-mesure a-t-il : un prix, un responsable, un délai de décision, un nombre de modifications possibles ? Sinon vous vendez un travail ouvert.
**Effet.** Dans la proposition : « Ce qui est modifiable » (liste fermée) vs « Sur demande, avec devis ».

## 3. Valeur de l'expérience vs complexité opérationnelle
Une expérience peut avoir une valeur **visible** (cuisson devant les invités, mise en scène) ou **discrète** (sérénité, coordination, fiabilité, horaire tenu). Elle vaut d'être vendue si elle répond à ce que le décisionnaire cherche, si l'équipe peut la **répéter** et si son risque est acceptable à l'heure la plus chargée. Une valeur discrète doit être rendue vérifiable (horaire, responsable, plan écrit).
Questions : combien de personnes et de temps ? que se passe-t-il si la pluie/le vent/le retard touche ? un incident bloque-t-il le service de tous ?
**Piège.** L'expérience qui impressionne en photo mais crée un goulot (cuisson à la minute pour 90 en 40 min) : l'écarter ou la **limiter** (une pièce signature, le reste prêt à servir).
**Effet.** Le choix explicite : « expérience gardée : … ; expérience écartée ou limitée : …, parce que… ».

## 4. Inclusions, options, responsabilités
Une chose n'entre dans l'offre que si : problème résolu + coût identifié + responsable + disponibilité.
Trois statuts seulement :
1. **Inclus** (nous, coût dans notre prix).
2. **Option payante** (nous ou un prestataire nommé, prix à part).
3. **À la charge du client** (écrit noir sur blanc, avec qui l'organise).
**Piège.** Un « bonus offert » sans coût compté est une charge cachée. Une option dont personne n'a confirmé la disponibilité est une promesse non tenable : l'écrire « sous réserve de disponibilité confirmée ».
**Effet.** Tableau Inclus / Option / Client dans la proposition ; coût de chaque ligne dans la feuille interne.

## 5. Menus communs vs diversité
Réutiliser une préparation dans plusieurs plats limite le travail et les restes (idée que Cyril a déclarée pratiquer, voir `experience-cyril.md`) ; ce n'est pas une garantie de marge.
**Décision selon charge, capacité et achats.** Plus la base est commune, plus on partage achats et préparation ; chaque variante ajoute de la charge selon ce qu'elle change : une variante peut partager la préparation et ne changer que le montage, l'assaisonnement ou la portion, ou exiger une préparation séparée (allergène, régime). Aucun nombre de variantes n'est imposé : se demander pour chacune ce qu'elle ajoute en achats, en temps de préparation, en risque de confusion au service et en allergènes, au regard de l'équipe et du créneau. Garder celles qui répondent à un besoin réel du client.
**Piège.** Laisser « choisir sur place » parmi N plats pour un groupe pressé : le temps par personne explose. À chronométrer avant de promettre (voir cas 1).
**Allergènes.** À valider par le pro ; ne jamais les déduire par l'IA.

## 6. Prix acceptable, contribution, capacité
Trois questions, dans cet ordre :
1. **Capacité** : combien peut-on servir/cuire avec l'équipe prévue, sur le créneau ? (mesuré, pas supposé)
2. **Coûts connus** : matières × quantités, emballages, main-d'œuvre, transport, location. Le reste est **inconnu**, pas nul.
3. **Prix** : ce que le client accepte, comparé à la contribution voulue (prix − coûts connus). Tant qu'il reste des inconnues la contribution est un **plafond**.
**Piège.** Se fier à une fourchette de prix évoquée à l'oral (ex. 40–100 € par personne) : c'est un ordre de grandeur personnel, **pas un relevé de marché** ; ne pas en faire une règle ni une ancre dans la proposition.
**Pas de bénéfice net.** La contribution ne tient pas compte des coûts fixes, de la TVA, du salaire du dirigeant ni de la trésorerie.
**HT / TTC.** Le script compare un prix **HT** à des coûts **HT** et n'invente aucune TVA. Le budget annoncé par un client est souvent TTC (particuliers) : ne pas le comparer tel quel au prix interne HT ; le pro convertit avec son propre taux et régime (le script ne le fait pas).
**Effet.** Script `chiffrer_prestation.py`.

## 7. Minimum de prestation
Un minimum protège un format qui ne tient que s'il y a assez de monde ou de chiffre : déplacement, installation, équipe minimale pèsent autant pour 8 que pour 18.
Deux formes : minimum **en prix** (facturation plancher) ou **en convives** ; ou **autre format** sous le seuil (formule plus simple, à emporter).
**Distinguer deux choses.** Le **minimum commercial** est une décision du pro (il décide du seuil en dessous duquel il ne s'engage pas à ce format). L'**économie réelle** se lit dans les coûts chiffrés (contribution provisoire) ; tant qu'ils ne le sont pas, on ne sait pas si une petite prestation est moins rentable. Baisser le prix sous le minimum est un choix à argumenter avec les coûts connus, pas une règle ou une évidence.
**Effet.** Conditions confirmées dans la proposition : « À partir de … convives / minimum de facturation … (à fixer par vous) ».

## 8. Preuve réelle et réduction d'incertitude
Promettre seulement ce qui est faisable ET vérifiable : ce que le client peut constater (heure de fin, nombre de choix, éléments inclus).
**Réduire l'incertitude** avant l'engagement ferme : chronométrer un service de test, cuire une portion à l'échelle, confirmer par écrit la disponibilité du loueur, faire visiter le lieu.
**Preuve.** N'utiliser qu'une preuve réellement possédée (photo datée, avis publié autorisé). Aucun témoignage ni résultat inventé.
**Effet.** Section « Essai avant engagement » dans la note d'arbitrage, avec : quoi, qui, quand, critère de réussite, décision si échec.

---

## Pourquoi une offre séduisante est écartée (grille rapide)
| Symptôme | Cause | Décision |
|---|---|---|
| « Tout compris » mais quelqu'un ne sait pas qui fait quoi | Inclusion sans responsable | Redescendre en option ou à la charge du client |
| Plusieurs choix pour un groupe pressé | Débit non testé | Réduire à 2 plats + 1 variante, pré-commande |
| Expérience spectaculaire sans plan B | Risque sur le moment critique | Limiter ou prévoir repli écrit |
| Prix plus haut mais 3 coûts inconnus | Contribution non vérifiée | Comparer à coût connu égal, chiffrer les inconnues d'abord |
| Prix bas qui « remplit » | Minimum fixé par le pro non respecté | Autre format, refus poli, ou dérogation argumentée avec les coûts chiffrés |
