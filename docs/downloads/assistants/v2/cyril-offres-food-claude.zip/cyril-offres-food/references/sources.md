# Sources et portée de lecture

Consultées le 10 novembre 2026 (fiche interne `bibliotheque-assistants-food/orchestration/SOURCES-OFFRES.md`). Les supports externes ne sont **pas redistribués** : liens et adaptations originales seulement.

## 1. Alex Hormozi / Acquisition.com — Offer Creation Checklist ($100M Offers Course)
URL : https://www.acquisition.com/files/offer-creation-checklist.pdf (page : https://www.acquisition.com/training/offers5)
**Lecture réelle :** texte des 3 pages PDF et page du cours ; ni le livre ni la vidéo entière.
**Mécanisme retenu :** partir du résultat voulu, identifier les obstacles du client, choisir des composantes utiles en tenant compte de leur **coût de réalisation** ; l'offre peut inclure anticipation et simplicité.
**Usage ici :** structurer l'arbitrage 4 (une inclusion résout un obstacle et coûte quelque chose). **Pas** : empiler des bonus, inventer une valeur monétaire, une urgence ou une garantie.
**Limite :** méthode commerciale d'auteur ; ni validation scientifique ni preuve de performance en restauration.

## 2. Acquisition.com — Bonus Creation Checklist
URL : https://www.acquisition.com/hubfs/Offer%20Checklists%20-%20PDF%20Downloads/Bonus-Creation-Checklist.pdf?hsLang=en
**Lecture réelle :** texte des 2 pages.
**Mécanisme retenu :** un complément utile répond à un obstacle ou un besoin suivant et réduit l'effort ; un partenaire peut faciliter l'accès à l'élément.
**Usage ici :** distinguer « inclus », « option payante » et « à la charge du client » (vaisselle/loueur, accueil, décoration) avec coûts, disponibilités, permissions, responsabilités réels. Ne pas inventer de commission, affiliation ni partenariat.
**Limite :** recommandations non universelles. Le PDF protège la redistribution : ne pas l'embarquer.

## 3. Kurt Bostelaar / Strategyzer — Value Proposition Canvas pour équipes commerciales
URL : https://www.strategyzer.com/library/how-sales-teams-can-create-focused-value-for-prospects-with-the-value-proposition-canvas (29 octobre 2015)
**Lecture réelle :** article HTML complet ; pas le livre *Value Proposition Design*.
**Mécanisme retenu :** observer les attentes pratiques, émotionnelles et sociales d'un segment ; relier chaque composante de l'offre à ce qui compte le plus ; comparer les segments plutôt que de supposer une proposition unique.
**Usage ici :** arbitrage 1 (occasion, décisionnaire). Les hypothèses « entreprise = horaire, mariage = sérénité, anniversaire = adultes/enfants » sont **des hypothèses à vérifier**, pas des observations de marché.
**Limite :** outil de conception ; pas un prix de marché ni une assurance de vente. Le canvas est protégé : nous n'en redistribuons pas.

## Distinctions
- Les 8 arbitrages, la grille d'écartement, le seuil de contribution et le script sont **originaux** (proposition testable).
- Le vécu de Cyril : `experience-cyril.md`, séparé des deux autres natures.
- Skool/Hormozi : identité éditoriale seulement, aucun framework.
