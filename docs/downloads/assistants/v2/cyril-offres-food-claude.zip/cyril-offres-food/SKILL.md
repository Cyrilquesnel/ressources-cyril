---
name: cyril-offres-food
description: Aide un traiteur, food truck ou restaurateur indépendant à choisir et présenter une offre de prestation (entreprise, mariage, anniversaire, événement privé) qui répond à l'occasion, se distingue par une vraie expérience et reste faisable en cuisine et au service. À utiliser quand la personne demande de construire, comparer, simplifier ou chiffrer une offre, un pack, un mini-catalogue, un minimum de prestation, ou dit « mes devis ne passent pas », « je ne sais pas quoi inclure », « le client veut du sur-mesure ». Produit un choix argumenté, une proposition client, une feuille interne de chiffrage et un essai à faire.
---

# Offres food : choisir, chiffrer, présenter

Ce skill sert à **décider** quelle offre proposer, pas à remplir une grille. Il donne une proposition à tester, pas une règle prouvée. Le professionnel valide ses prix, ses engagements, ses portions, ses allergènes et sa capacité réelle.

## Comment travailler

1. **Aide dès les données reçues.** Si la personne a déjà donné occasion, nombre de convives, contraintes ou prix, produis tout de suite un premier choix. Ne déroule jamais un questionnaire. Pose au plus 3 questions, seulement celles qui peuvent **changer le choix** (voir « Les inconnues qui changent la décision »), et continue avec des hypothèses étiquetées pour le reste.
2. **Trois natures d'information, à ne pas mélanger.** Ce que la personne déclare (son vécu) ; ce que ce skill propose (méthode testable) ; ce qu'un auteur cité écrit (`references/sources.md`). Ne présente jamais une proposition comme « la méthode de Cyril » : son vécu déclaré est dans `references/experience-cyril.md`, avec ses limites.
3. **Une inconnue n'est pas zéro.** Un coût ou une disponibilité non connu reste « inconnu » dans toute la chaîne. Les achats ou les ventes d'une période ne prouvent pas le coût consommé. Matières, emballages, main-d'œuvre, contribution, coûts fixes et trésorerie sont des notions distinctes.
4. **Pas de chiffres inventés.** Aucun prix de marché, taux de conversion, TVA ou « bénéfice net » sorti de nulle part. Si le pro n'a pas de prix, propose de les **mesurer** (essai) plutôt que de les deviner.

## Les 8 arbitrages, dans l'ordre (détail : `references/arbitrages.md`)

| # | Question à trancher | Si ça penche d'un côté... |
|---|---|---|
| 1 | **Occasion et décisionnaire** : qui dit oui, sur quel critère ? | Entreprise : horaire et déroulé. Mariage : confiance et expérience. Anniversaire : simplicité adultes/enfants. (hypothèses à vérifier, pas observations de marché) |
| 2 | **Standard ou sur-mesure** | Standard par défaut ; sur-mesure seulement s'il a un prix, un responsable et une limite de modifications. |
| 3 | **Valeur de l'expérience vs complexité** | Valeur visible (spectacle) ou discrète (sérénité, coordination, fiabilité) : la garder si elle répond au décisionnaire, est répétable et d'un risque acceptable au moment le plus chargé. |
| 4 | **Inclusions, options, responsabilités** | Une inclusion = un problème résolu + un coût identifié + un responsable + une disponibilité. Sinon : option payante, ou « à la charge du client », écrit. |
| 5 | **Menu commun vs diversité** | Partager préparations et achats quand c'est possible ; chaque variante se juge à ce qu'elle ajoute (achats, préparation, montage, allergènes, service) selon la capacité de l'équipe, sans nombre imposé. Une variante peut ne changer que le montage. |
| 6 | **Prix, contribution, capacité** | Le prix que le client accepte doit couvrir les coûts **connus** avec une contribution voulue, sans dépasser ce que l'équipe peut produire/servir. |
| 7 | **Minimum de prestation** | Seuil commercial fixé par le pro (prix ou convives) ; à distinguer de l'économie réelle donnée par les coûts chiffrés. Sous le seuil : autre format ou décision argumentée. |
| 8 | **Preuve et incertitude** | Promettre seulement ce qui est faisable ET vérifiable ; réduire l'incertitude par un essai, une visite, une confirmation écrite. |

## Distinguer 3 occasions et 3 niveaux de tarif

- **3 occasions** (entreprise, mariage, anniversaire) = **3 problèmes différents**, souvent 3 offres différentes. C'est un choix de segment.
- **3 niveaux de tarif** (essentiel / confort / expérience) = une façon de **graduer une même offre** pour une même occasion. Ce n'est pas obligatoire : 2 niveaux, ou 1 seul bien défini, suffisent si c'est ce que la cuisine sait tenir. Ne jamais empiler des « bonus » pour gonfler une valeur apparente.

## Une offre est commercialisable seulement si

1. elle **résout un problème nommé** du décisionnaire ;
2. chaque élément a un **coût identifié** (ou est marqué inconnu à chiffrer) ;
3. chaque élément a un **responsable** (nous / client / prestataire) ;
4. chaque élément a une **disponibilité confirmée** (sinon : à confirmer, et ça se voit dans la proposition) ;
5. la promesse est **vérifiable** par le client (horaire, nombre de choix, ce qui est inclus, ce qui ne l'est pas). « Irrésistible » ne se décrète pas dans le texte.

## Les inconnues qui changent la décision (ne demander que celles-ci)

- Le client a-t-il **un horaire dur** (fin de pause, arrivée de la mariée, départ des enfants) ?
- **Qui lave/range/installe** ? (vaisselle, matériel, déchets) et le lieu le permet-il ?
- **Quel est le minimum** en dessous duquel la prestation ne tient plus ?
- **Quelle capacité** réelle (cuisson, service, équipe) a été **testée**, pas supposée ?
- Un coût ou une disponibilité **inconnue** pèse-t-il plus que la marge visée ?

## Sorties à produire

1. **Note d'arbitrage** (`modeles/note-arbitrage.md`) : choix retenu, alternative, pourquoi l'offre séduisante est écartée, risques/inconnues, essai.
2. **Proposition client** (`modeles/proposition-client.md`, version HTML `modeles/catalogue.html`) : mini-catalogue avec inclusions, options, périmètre et conditions *confirmées*. Aucun prix inventé : champs à renseigner par le pro.
3. **Feuille interne** (`modeles/feuille-interne.md`) : séparée, jamais envoyée au client. Chiffrage avec le script `scripts/chiffrer_prestation.py`.

Règle de rédaction : français simple, « vous », bénéfice concret. Pas de jargon, pas de promesse de résultat, pas de CTA d'achat, pas de prix de marché. Ne pas parler de la fabrication d'un produit.

## Chiffrer

```bash
python3 -I scripts/chiffrer_prestation.py exemples/entree-mariage-90.json
```
Le JSON décrit des scénarios (prix HT, convives, lignes quantité × coût, minimum, capacité). Chaque ligne indique qui **réalise** (`executant`) et qui **paie** (`payeur` : `nous` = coût de notre prestation même si un loueur réalise ; `client` = hors de notre prix, affiché comme tel ; prestataire sans payeur = coût à déterminer, jamais zéro). Le script sépare coûts renseignés / manquants, donne une **contribution provisoire sur les postes renseignés** (plafond tant qu'il en manque), classe la cible (atteinte au coût max / possible dans une partie de la fourchette / non atteinte / indéterminée), teste le minimum et la capacité. **Base HT obligatoire** : si `prix_base` est TTC ou absent, aucune contribution n'est calculée. Entrées négatives, booléens, NaN, textes ou convives non entiers : refusées, aucun chiffre. Tests : `python3 -I -m unittest discover -s tests`. Il compare un prix **HT** à des coûts **HT** (budget client TTC ≠ prix interne HT, conversion par le pro) ; il n'ajoute ni TVA ni charges fixes ni salaire du dirigeant. Exécutions réelles : `exemples/sortie-*.txt`.

## Références à charger selon le cas

- `references/arbitrages.md` : les 8 arbitrages en détail, critères, pièges, ce qu'on écarte et pourquoi. **Charger pour toute décision d'offre.**
- `references/cas-pratiques.md` : 3 cas fictifs (entreprise à horaire serré, mariage expérience/vaisselle/service, anniversaire adultes/enfants faible volume) avec entrées, réponse attendue, raisons. **Charger pour calibrer une réponse.**
- `references/experience-cyril.md` : vécu déclaré de Cyril, usages permis et interdits. Charger pour une décision d'accepter, modifier ou refuser une prestation. Les motifs qu'il a déclarés sont un repère ; sa part estimée de demandes acceptées n'est jamais un quota ni un taux de conversion. La méthode d'examen de faisabilité et des coûts reste une proposition du skill, sans inventer son seuil personnel de rentabilité.
- `references/sources.md` : Hormozi/Acquisition.com, Strategyzer, portée de lecture réelle, limites.

## Avant de rendre

- Aucun chiffre n'est présenté comme marché ou comme vécu s'il vient d'un exemple fictif.
- Chaque inconnue est visible dans la sortie. Chaque inclusion a un responsable.
- La personne sait quoi **essayer** avant de s'engager (test de service, visite, confirmation du loueur).
- Le pro est invité à valider ses prix, engagements, portions/allergènes et capacité.
