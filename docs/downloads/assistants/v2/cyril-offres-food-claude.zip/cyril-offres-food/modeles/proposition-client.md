# Proposition — [Nom de la prestation]
*Modèle à adapter. Les parties [entre crochets] sont à remplir par le professionnel après validation de ses prix, engagements, portions, allergènes et capacité.*

Bonjour [Prénom],

Voici ce que nous vous proposons pour [occasion, date, lieu], pour [nombre] personnes.

**Ce que nous résolvons pour vous :** [le problème du client en une phrase, ex. « un déjeuner servi dans votre pause de 75 minutes, sans que personne n'ait à s'en occuper »].

## Ce qui est inclus (nous nous en occupons)
- [Élément 1 : ce que c'est, quand, quel résultat vérifiable]
- [Élément 2]

## Options (prix à part)
| Option | Prix | Qui s'en occupe | Disponibilité |
|---|---|---|---|
| [ex. Vaisselle] | [à renseigner] | [prestataire nommé] | [confirmée le … / à confirmer] |

## À votre charge
- [ex. accès au lieu, tables, électricité] — [avec qui nous le confirmons]

## Ce qui peut changer / ce qui ne change pas
- Modifiable jusqu'au [date] : [liste fermée].
- Sur demande, avec nouveau devis : [liste].

## Conditions confirmées
- Prix : [à renseigner], en précisant HT ou TTC (selon votre statut, à valider par vous).
- À partir de [nombre] personnes / minimum de facturation [montant], sinon nous vous proposons [autre format].
- Allergènes et régimes : à nous indiquer avant le [date] ; nous confirmons ce qui est possible.
- Annulation / acompte : [selon vos conditions].

Pour valider ou ajuster : [moyen de contact].
