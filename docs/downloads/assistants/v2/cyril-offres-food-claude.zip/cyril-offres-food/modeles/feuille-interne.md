# Feuille interne de chiffrage (ne jamais envoyer au client)

| Champ | Valeur |
|---|---|
| Occasion / client | |
| Convives | |
| Scénario | |
| Prix proposé HT (le script compare des prix HT à des coûts HT) | |
| Budget annoncé par le client (si connu) et sa base HT/TTC — à ne pas comparer tel quel | |
| Minimum de prestation (prix / convives) | |
| Capacité testée (oui/non, comment) | |

## Lignes
| Ligne | Catégorie (matière, emballage, main-d'œuvre, transport, location, autre) | Mode (par convive / fixe) | Quantité | Coût unitaire ou « inconnu » | Exécutant (nous / prestataire nommé) | Payeur (nous / client) | Disponibilité (confirmée / à confirmer) |
|---|---|---|---|---|---|---|---|

## Contrôles
- [ ] Un prestataire qui réalise une ligne a un **payeur** écrit : nous (coût compté) ou client (hors de notre prix).
- [ ] Chaque ligne « inconnu » a une personne et une date pour la chiffrer.
- [ ] Aucune catégorie oubliée (matière, main-d'œuvre, transport).
- [ ] La contribution est lue comme **plafond** tant qu'il reste des inconnues.
- [ ] Coûts fixes, TVA et rémunération du dirigeant : traités ailleurs, pas dans ce calcul.

Pour calculer : copier un fichier `exemples/entree-*.json`, remplacer par vos lignes, lancer `python3 -I scripts/chiffrer_prestation.py votre-fichier.json`.
