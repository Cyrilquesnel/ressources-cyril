# Note d'arbitrage — modèle rempli avec le cas fictif n°3 (anniversaire de Noémie)
*Exemple fictif. Interne.*

**Occasion / décisionnaire.** Anniversaire, 12 adultes + 6 enfants ; la maman décide. Critère supposé : une chose de moins à gérer (à confirmer par une question).

**Choix retenu : B.** Menu commun, portions adaptées pour les enfants, minimum de facturation 350 € (fictif, à fixer par le pro). Gâteau et déco à la charge du client ou en option avec un prestataire nommé.

**Alternative : A (pack tout compris).** Reprise possible seulement si gâteau, déco et animation ont chacun un responsable, un coût et une disponibilité confirmés.

**Pourquoi A est écartée.** Trois éléments sans responsable ni coût ; contribution provisoire 134 € (plafond) contre 167 € (plafond) pour B avec 3 inconnues contre 1.

**Chiffres (script, entrées fictives).** B : coût connu 183 €, contribution provisoire 167 € (plafond : trajet inconnu). B′ (8 convives, 190 €) : minimum non respecté.

**Risques / inconnues.** Trajet non chiffré ; goût des enfants non testé ; allergènes à valider par le pro ; capacité de l'équipe à tenir 18 personnes en 3 h non testée.

**Essai.** Faire goûter la base adaptée à 2-3 enfants ; critère : assiette presque vide. Qui : le pro. Quand : avant d'envoyer la proposition. Si échec : ajouter UNE variante.

**À valider par le pro avant envoi :** prix, engagements, portions, allergènes, capacité, disponibilités.
