#!/usr/bin/env python3
"""Chiffrage de prestation (stdlib, hors réseau). Usage :
    python3 -I chiffrer_prestation.py entree.json [--json]

Convention : prix_total et coûts sont HORS TAXES ("prix_base": "HT"). Si la base est TTC ou non
précisée, AUCUNE contribution n'est calculée (le script ne convertit rien, n'invente aucune TVA).
Un budget client TTC n'est pas un prix interne HT : le pro fait la conversion lui-même.

Par ligne : quantité x coût unitaire (nombre, ou {"min":,"max":}, ou null = INCONNU).
  "executant" : qui réalise (nous, loueur, ...). "payeur" : qui paie (nous | client).
  - payeur "nous"   -> coût compté dans notre prestation, quel que soit l'exécutant.
  - payeur "client" -> hors de notre prix, affiché comme tel.
  - exécutant autre que "nous" SANS payeur -> coût à déterminer (inconnu), jamais zéro.
La contribution est mesurée sur les postes renseignés seulement : ce n'est ni un bénéfice net,
ni un résultat « ferme » (hors coûts fixes, TVA, rémunération du dirigeant, trésorerie).
Entrées refusées (résultat « invalide », aucun chiffre) : négatifs, booléens, NaN/infini, textes,
convives non entiers ou nuls, fourchette min > max.
"""
import json, sys
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation

CATEGORIES_ATTENDUES = ["matiere", "main_oeuvre", "transport"]
MODES = ("par_convive", "fixe")
CENT = Decimal("0.01")


def _num(v, nom, erreurs, entier=False, positif_strict=False):
    """-> Decimal valide, ou None (erreur ajoutée)."""
    if isinstance(v, bool) or v is None or isinstance(v, (str, list, dict)):
        erreurs.append(f"{nom} : nombre attendu (reçu {v!r})")
        return None
    try:
        d = Decimal(str(v)) if not isinstance(v, Decimal) else v
    except InvalidOperation:
        erreurs.append(f"{nom} : nombre invalide ({v!r})")
        return None
    if not d.is_finite():
        erreurs.append(f"{nom} : valeur non finie")
        return None
    if d < 0 or (positif_strict and d == 0):
        erreurs.append(f"{nom} : doit être {'> 0' if positif_strict else '>= 0'} (reçu {d})")
        return None
    if entier and d != d.to_integral_value():
        erreurs.append(f"{nom} : entier attendu (reçu {d})")
        return None
    return d


def _r(d):
    return float(d.quantize(CENT, rounding=ROUND_HALF_UP))


def _invalide(sc, convives, base, erreurs):
    return {"scenario": sc.get("nom", "?"), "convives": convives, "prix_base": base or "non précisée",
            "invalide": erreurs, "prix_total": None, "prix_par_convive": None, "cout_connu": None,
            "inconnues": [], "a_confirmer": [], "contribution_provisoire": None,
            "contribution_par_convive_max": None, "statut_contribution": "invalide", "cible": None,
            "lignes": [], "avertissements": ["ENTRÉE INVALIDE, aucun chiffre produit : " + " ; ".join(erreurs)]}


def chiffrer(sc, defaut):
    erreurs = []
    base = str(sc.get("prix_base", defaut.get("prix_base", ""))).strip().upper()
    base_couts = str(sc.get("couts_base", defaut.get("couts_base", "HT"))).strip().upper()
    convives = _num(sc.get("convives", defaut.get("convives")), "convives", erreurs, entier=True, positif_strict=True)
    prix = _num(sc.get("prix_total"), "prix_total", erreurs)
    lignes_ok = []
    for i, l in enumerate(sc.get("lignes", [])):
        nom = l.get("nom", f"ligne {i + 1}")
        if l.get("mode") not in MODES:
            erreurs.append(f"{nom} : mode doit être par_convive ou fixe")
        q = _num(l.get("quantite"), f"{nom} / quantite", erreurs)
        c = l.get("cout_unitaire")
        cmin = cmax = None
        if c is not None:
            if isinstance(c, dict):
                cmin = _num(c.get("min"), f"{nom} / cout min", erreurs)
                cmax = _num(c.get("max"), f"{nom} / cout max", erreurs)
                if cmin is not None and cmax is not None and cmin > cmax:
                    erreurs.append(f"{nom} : cout min > max")
            else:
                cmin = cmax = _num(c, f"{nom} / cout_unitaire", erreurs)
        lignes_ok.append((l, nom, q, cmin, cmax))
    if not sc.get("lignes"):
        erreurs.append("aucune ligne de coût")
    cible = None
    if sc.get("contribution_cible", defaut.get("contribution_cible")) is not None:
        cible = _num(sc.get("contribution_cible", defaut.get("contribution_cible")), "contribution_cible", erreurs)
    mini = sc.get("minimum_prestation", defaut.get("minimum_prestation")) or {}
    mini_prix = _num(mini["prix"], "minimum_prestation.prix", erreurs) if "prix" in mini else None
    mini_cv = _num(mini["convives"], "minimum_prestation.convives", erreurs, entier=True) if "convives" in mini else None
    cap = sc.get("capacite_max_convives", defaut.get("capacite_max_convives"))
    cap = _num(cap, "capacite_max_convives", erreurs, entier=True) if cap is not None else None
    if erreurs:
        return _invalide(sc, None if convives is None else int(convives), base, erreurs)

    cmin_tot = cmax_tot = Decimal(0)
    inconnues, a_confirmer, detail, avert = [], [], [], []
    cats = set()
    for l, nom, q, cmin, cmax in lignes_ok:
        qt = q * convives if l["mode"] == "par_convive" else q
        executant = str(l.get("executant", l.get("responsable", "nous")))
        payeur = l.get("payeur")
        if payeur is None and executant == "nous":
            payeur = "nous"
        if l.get("disponibilite", "confirmee") != "confirmee":
            a_confirmer.append(nom)
        if payeur == "client":
            detail.append({"nom": nom, "executant": executant, "paye_par": "client", "compte": False,
                           "libelle": f"payé directement par le client, hors de notre prix (non compté) ; réalisé par {executant}"})
            continue
        cats.add(l.get("categorie", "autre"))
        if payeur not in ("nous", None):
            avert.append(f"« {nom} » : payeur « {payeur} » non reconnu (nous | client) : traité comme inconnu")
            payeur = None
        if payeur is None:
            inconnues.append(nom)
            avert.append(f"« {nom} » réalisé par {executant} sans payeur indiqué : qui paie ? (nous | client) ; traité comme inconnu, pas comme zéro")
            detail.append({"nom": nom, "executant": executant, "paye_par": None, "inconnu": True,
                           "libelle": "payeur à préciser : coût inconnu"})
        elif cmin is None:
            inconnues.append(nom)
            detail.append({"nom": nom, "executant": executant, "paye_par": "nous", "inconnu": True, "libelle": "coût inconnu"})
        else:
            lo, hi = cmin * qt, cmax * qt
            cmin_tot += lo
            cmax_tot += hi
            detail.append({"nom": nom, "executant": executant, "paye_par": "nous", "total": [_r(lo), _r(hi)],
                           "libelle": "coût compté"})
    for cat in CATEGORIES_ATTENDUES:
        if cat not in cats:
            avert.append(f"aucune ligne « {cat} » à notre charge : oubli ? ou payée par un autre : le dire explicitement")
    if inconnues:
        avert.append("postes sans coût (non comptés comme 0) : " + ", ".join(inconnues))

    res = {"scenario": sc["nom"], "convives": int(convives), "prix_base": base or "non précisée",
           "prix_total": _r(prix), "prix_par_convive": _r(prix / convives),
           "cout_connu": [_r(cmin_tot), _r(cmax_tot)], "inconnues": inconnues, "a_confirmer": a_confirmer,
           "lignes": detail, "cible": None}
    comparable = base == "HT" and base_couts == "HT"
    if not comparable:
        res.update(contribution_provisoire=None, contribution_par_convive_max=None, statut_contribution="non_calculable")
        avert.append(f"prix_base « {base or 'non précisée'} » / couts_base « {base_couts} » : contribution NON calculée "
                     "(le script ne mélange pas TTC et HT et n'invente aucune TVA). Fournir le prix HT, calculé par le pro")
    else:
        c_max, c_min = prix - cmin_tot, prix - cmax_tot
        res["contribution_provisoire"] = [_r(c_min), _r(c_max)]
        res["contribution_par_convive_max"] = _r(c_max / convives)
        res["statut_contribution"] = "plafond" if inconnues else "sur_postes_listes"
        if cible is not None:
            if c_max < cible:
                res["cible"] = "non_atteinte"            # vrai même sans les postes manquants
            elif inconnues:
                res["cible"] = "indeterminee"
            elif c_min >= cible:
                res["cible"] = "atteinte_cout_max"
            else:
                res["cible"] = "possible_partie_fourchette"
    if mini_prix is not None or mini_cv is not None:
        ecarts = []
        if mini_prix is not None and prix < mini_prix:
            ecarts.append(f"prix {_r(prix)} < minimum de prestation {_r(mini_prix)}")
        if mini_cv is not None and convives < mini_cv:
            ecarts.append(f"{int(convives)} convives < minimum {int(mini_cv)}")
        res["minimum"] = {"respecte": not ecarts, "ecarts": ecarts}
    if cap is not None:
        res["capacite"] = {"max": int(cap), "respectee": convives <= cap}
        if convives > cap:
            avert.append(f"{int(convives)} convives > capacité déclarée {int(cap)}")
    res["avertissements"] = avert
    return res


LIB_CIBLE = {"atteinte_cout_max": "atteinte même au coût maximal",
             "possible_partie_fourchette": "possible seulement dans une partie de la fourchette de coûts",
             "non_atteinte": "non atteinte (même sans les postes manquants)",
             "indeterminee": "indéterminée : des coûts manquent"}


def _fmt(lo, hi):
    return f"{lo:.2f}" + (f" à {hi:.2f}" if hi != lo else "")


def afficher(data, resultats):
    print(f"# {data.get('titre', 'Chiffrage')}  (valeurs fictives si l'entrée l'indique)")
    for r in resultats:
        if r.get("invalide"):
            print(f"\n## {r['scenario']} — ENTRÉE INVALIDE (aucun chiffre)")
            for e in r["invalide"]:
                print("  ! " + e)
            continue
        print(f"\n## {r['scenario']} — {r['convives']} convives, prix {r['prix_total']:.2f} {r['prix_base']} ({r['prix_par_convive']:.2f}/convive)")
        for d in r["lignes"]:
            if d.get("compte") is False:
                print(f"  - {d['nom']}: {d['libelle']}")
            elif d.get("inconnu"):
                print(f"  - {d['nom']}: INCONNU ({d['libelle']})")
            else:
                print(f"  - {d['nom']}: {_fmt(*d['total'])}" + (f" (réalisé par {d['executant']}, payé par nous)" if d["executant"] != "nous" else ""))
        print(f"  Coûts renseignés : {_fmt(*r['cout_connu'])}")
        if r["contribution_provisoire"] is None:
            print("  Contribution : NON CALCULÉE (base de prix non HT ou non précisée)")
        else:
            cmin, cmax = r["contribution_provisoire"]
            lab = "PLAFOND : il manque des coûts" if r["statut_contribution"] == "plafond" else "sur les postes listés seulement"
            print(f"  Contribution provisoire : {_fmt(cmin, cmax)} ({lab}; {r['contribution_par_convive_max']:.2f}/convive au plus)")
            print("    (ni bénéfice net, ni coûts fixes, ni TVA, ni rémunération du dirigeant)")
        if r["cible"]:
            print("  Cible de contribution : " + LIB_CIBLE[r["cible"]])
        if "minimum" in r:
            print("  Minimum de prestation : " + ("respecté" if r["minimum"]["respecte"] else "NON respecté — " + "; ".join(r["minimum"]["ecarts"])))
        if "capacite" in r:
            print("  Capacité déclarée : " + ("ok" if r["capacite"]["respectee"] else "DÉPASSÉE"))
        if r["a_confirmer"]:
            print("  Disponibilités à confirmer : " + ", ".join(r["a_confirmer"]))
        for a in r["avertissements"]:
            print("  ! " + a)
    comp = [r for r in resultats if r.get("contribution_provisoire") is not None]
    if len(resultats) > 1:
        print("\n## Comparaison (contribution = plafond tant qu'il manque des coûts)")
        print(f"{'scénario':36} {'prix/cv':>8} {'coûts':>9} {'contrib.':>9} {'inconnus':>8} {'à conf.':>7} {'minimum':>8}")
        for r in resultats:
            if r.get("invalide") or r["contribution_provisoire"] is None:
                print(f"{r['scenario'][:36]:36} {'non comparable (invalide ou base de prix non HT)'}")
                continue
            print(f"{r['scenario'][:36]:36} {r['prix_par_convive']:8.2f} {r['cout_connu'][1]:9.2f} {r['contribution_provisoire'][1]:9.2f} "
                  f"{len(r['inconnues']):8d} {len(r['a_confirmer']):7d} {str(r.get('minimum', {}).get('respecte', 'n/a')):>8}")
        if len(comp) > 1:
            print("Lecture : plus de contribution avec plus de coûts manquants n'est pas « meilleur » : c'est moins vérifié.")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    def refuse(c):
        raise ValueError(f"valeur JSON refusée : {c}")
    try:
        with open(argv[1], encoding="utf-8") as f:
            data = json.load(f, parse_float=Decimal, parse_constant=refuse)
    except ValueError as e:
        print(f"ENTRÉE INVALIDE, aucun chiffre produit : {e}")
        return 1
    defaut = data.get("defauts", {})
    res = [chiffrer(s, defaut) for s in data["scenarios"]]
    if "--json" in argv:
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        afficher(data, res)
    return 1 if any(r.get("invalide") for r in res) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
