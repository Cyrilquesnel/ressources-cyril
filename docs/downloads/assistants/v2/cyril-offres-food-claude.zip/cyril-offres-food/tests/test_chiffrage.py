"""Tests du calculateur (stdlib). Lancer : python3 -I -m unittest discover -s tests -v   (depuis le dossier du skill)."""
import math, os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
import chiffrer_prestation as cp

BASE = {"prix_base": "HT", "convives": 10}

def sc(lignes, prix=1000, **kw):
    d = {"nom": "t", "prix_total": prix, "lignes": lignes}
    d.update(kw)
    return d

MAT = {"nom": "matières", "categorie": "matiere", "mode": "par_convive", "quantite": 1, "cout_unitaire": 10}
MO = {"nom": "équipe", "categorie": "main_oeuvre", "mode": "fixe", "quantite": 10, "cout_unitaire": 15}
TR = {"nom": "trajet", "categorie": "transport", "mode": "fixe", "quantite": 1, "cout_unitaire": 20}
SOCLE = [MAT, MO, TR]  # coûts connus : 100 + 150 + 20 = 270


class Erreur1_Payeur(unittest.TestCase):
    def test_loueur_execute_nous_payons_cout_inclus(self):
        v = {"nom": "vaisselle", "categorie": "location", "mode": "par_convive", "quantite": 1,
             "cout_unitaire": 3, "executant": "loueur", "payeur": "nous"}
        r = cp.chiffrer(sc(SOCLE + [v]), BASE)
        self.assertEqual(r["cout_connu"], [300.0, 300.0])   # 270 + 30

    def test_client_paye_directement_exclu_avec_libelle(self):
        v = {"nom": "vaisselle", "categorie": "location", "mode": "par_convive", "quantite": 1,
             "cout_unitaire": 3, "executant": "loueur", "payeur": "client"}
        r = cp.chiffrer(sc(SOCLE + [v]), BASE)
        self.assertEqual(r["cout_connu"], [270.0, 270.0])
        ligne = [l for l in r["lignes"] if l["nom"] == "vaisselle"][0]
        self.assertIn("client", ligne["libelle"].lower())
        self.assertIn("hors", ligne["libelle"].lower())

    def test_sans_payeur_prestataire_nest_pas_zero(self):
        v = {"nom": "vaisselle", "categorie": "location", "mode": "par_convive", "quantite": 1,
             "cout_unitaire": 3, "executant": "loueur"}
        r = cp.chiffrer(sc(SOCLE + [v]), BASE)
        self.assertIn("vaisselle", r["inconnues"])
        self.assertEqual(r["cout_connu"], [270.0, 270.0])
        self.assertEqual(r["statut_contribution"], "plafond")
        self.assertTrue(any("payeur" in a for a in r["avertissements"]))


class Erreur2_Base(unittest.TestCase):
    def test_ttc_aucune_contribution(self):
        r = cp.chiffrer(sc(SOCLE), {"prix_base": "TTC", "convives": 10})
        self.assertIsNone(r["contribution_provisoire"])
        self.assertEqual(r["statut_contribution"], "non_calculable")

    def test_base_absente_aucune_contribution(self):
        r = cp.chiffrer(sc(SOCLE), {"convives": 10})
        self.assertIsNone(r["contribution_provisoire"])

    def test_base_couts_non_ht(self):
        r = cp.chiffrer(sc(SOCLE), {"prix_base": "HT", "couts_base": "TTC", "convives": 10})
        self.assertIsNone(r["contribution_provisoire"])

    def test_ht_calcule(self):
        r = cp.chiffrer(sc(SOCLE), BASE)
        self.assertEqual(r["contribution_provisoire"], [730.0, 730.0])


class Erreur3_Entrees(unittest.TestCase):
    def invalide(self, scenario, defaut=BASE):
        r = cp.chiffrer(scenario, defaut)
        self.assertTrue(r.get("invalide"), r)
        self.assertIsNone(r["contribution_provisoire"])
        self.assertIsNone(r["cout_connu"])

    def test_cout_negatif(self):
        self.invalide(sc([dict(MAT, cout_unitaire=-1)]))
    def test_quantite_negative(self):
        self.invalide(sc([dict(MAT, quantite=-2)]))
    def test_booleen(self):
        self.invalide(sc([dict(MAT, quantite=True)]))
    def test_nan(self):
        self.invalide(sc([dict(MAT, cout_unitaire=float("nan"))]))
    def test_infini(self):
        self.invalide(sc([MAT], prix=math.inf))
    def test_prix_negatif(self):
        self.invalide(sc([MAT], prix=-5))
    def test_convives_fractionnaires(self):
        self.invalide(sc([MAT]), {"prix_base": "HT", "convives": 2.5})
    def test_convives_zero(self):
        self.invalide(sc([MAT]), {"prix_base": "HT", "convives": 0})
    def test_chaine(self):
        self.invalide(sc([dict(MAT, cout_unitaire="3")]))
    def test_fourchette_inversee(self):
        self.invalide(sc([dict(MAT, cout_unitaire={"min": 5, "max": 2})]))
    def test_decimal_exact(self):
        r = cp.chiffrer(sc([dict(MAT, cout_unitaire=0.1, quantite=3)], prix=1), BASE)  # 0,1 x 3 x 10
        self.assertEqual(r["cout_connu"], [3.0, 3.0])


class Erreur4_Cible(unittest.TestCase):
    def run_cible(self, prix, cible, lignes=None):
        return cp.chiffrer(sc(lignes or [dict(MAT, cout_unitaire={"min": 8, "max": 12})], prix=prix, contribution_cible=cible), BASE)
    # coûts : 80 à 120
    def test_atteinte_au_cout_max(self):
        self.assertEqual(self.run_cible(300, 150)["cible"], "atteinte_cout_max")      # 300-120=180
    def test_partielle(self):
        self.assertEqual(self.run_cible(250, 150)["cible"], "possible_partie_fourchette")  # 130..170
    def test_non_atteinte(self):
        self.assertEqual(self.run_cible(200, 150)["cible"], "non_atteinte")            # 80..120
    def test_indeterminee_si_manquants(self):
        r = self.run_cible(300, 150, [dict(MAT, cout_unitaire=8), dict(TR, cout_unitaire=None)])
        self.assertEqual(r["cible"], "indeterminee")
    def test_non_atteinte_meme_sans_manquants(self):
        r = self.run_cible(150, 150, [dict(MAT, cout_unitaire=8), dict(TR, cout_unitaire=None)])  # plafond 70 < 150
        self.assertEqual(r["cible"], "non_atteinte")
    def test_jamais_ferme(self):
        r = cp.chiffrer(sc(SOCLE), BASE)
        self.assertNotIn("ferme", r["statut_contribution"].lower())


if __name__ == "__main__":
    unittest.main()
