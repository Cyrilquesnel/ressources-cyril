# Kit : comparer trois offres faites avec la même préparation

Vous partez d'une préparation que vous faites déjà (tenders, sauce, farce, fond…) et vous la servez de plusieurs façons. Ce kit vous donne un exemple rempli, un modèle à copier et l'essai à décider. Tout est en HT. Le chiffre « reste après matières » n'est pas votre bénéfice.

## 1. Démonstration (chiffres entièrement fictifs)
Données fournies (fictives) : lot de 3 kg de poulet à 9,00 €/kg = 27,00 € ; panure 3,50 € ; huile de friture 1,50 €. Lot = 32,00 € pour 30 portions. Une portion = 100 g de poulet **cru, avant panure et cuisson** (3 kg ÷ 30), pas le poids du produit fini.
**Coût d'une portion de préparation : 32,00 ÷ 30 = 1,07 €.**

| | Enfant | Tapas | Burger |
|---|---|---|---|
| Préparation | 1 portion = 1,07 | 1,5 portion = 1,60 | 1 portion = 1,07 |
| Pain | 0 | 0 | 1,00 |
| Accompagnement / garniture | 0,40 | 0 | 0,60 |
| Sauce | 0,10 | 0,30 | 0,15 |
| **Sous-total ingrédients** | **1,57** | **1,90** | **2,82** |
| Emballage | 0,15 | 0,15 | 0,20 |
| **Coûts variables retenus** (ingrédients + emballage) | **1,72** | **2,05** | **3,02** |
| Prix de vente HT (fictif) | 6,50 | 7,00 | 9,50 |
| **Contribution** (prix − coûts variables retenus) | **4,78** | **4,95** | **6,48** |
| % matière (ingrédients ÷ prix) | 24,1 % | 27,1 % | 29,6 % |
| Part des coûts variables retenus (÷ prix) | 26,4 % | 29,3 % | 31,8 % |

Ventes fictives d’une soirée : 20 enfants, 30 tapas, 50 burgers. Elles utilisent 20 + (30 × 1,5) + 50 = 115 portions de préparation. Le lot de 30 sert uniquement de base au coût unitaire ; les quantités et achats de production doivent être redimensionnés. Ventes : 130,00 + 210,00 + 475,00 = 815,00 €. Ingrédients : 31,33 + 57,00 + 140,83 = 229,17 €. Emballages : 3,00 + 4,50 + 10,00 = 17,50 €. Coûts variables retenus : 246,67 €. Contribution totale : **568,33 €** (815,00 − 246,67), avant personnel, charges, pertes et temps.
Les calculs gardent les valeurs non arrondies ; les montants affichés sont arrondis au centime et les pourcentages à une décimale.
Lecture : le burger a le pourcentage le plus élevé mais laisse le plus d'euros par vente. Ce que le calcul ne dit pas : le temps de montage, les pertes réelles, le personnel, les charges. Données manquantes à relever chez vous : portions pesées, ventes réelles, temps par offre.

## 2. Modèle à copier
```
PRÉPARATION COMMUNE   date du relevé : ____
Composant | quantité achetée | prix HT | source du prix (facture) | date
__________|__________________|_________|__________________________|_____
Coût du lot : ____ €   Nombre de portions : ____   Poids d'une portion (cru ou cuit ? précisez) : ____   Coût d'une portion : ____ €

OFFRE : ________   Prix de vente HT : ____ €
Composant | quantité par portion | coût | prix daté
Préparation commune | ____ portion(s) | ____ |
Pain / accompagnement | | |
Sous-total ingrédients : ____ €
Emballage | | |
Coûts variables retenus (ingrédients + emballage) : ____ €
Contribution : ____ €    % matière (ingrédients ÷ prix) : ____ %    Part des coûts variables retenus : ____ %
Ventes sur la période (dates : ____) : ____   Contribution totale : ____ €
Temps de travail par portion (si connu) : ____
Inconnues : ____
```
Pour calculer dans un classeur au lieu de la main, ouvrez un modèle existant :
- Fiche technique + mercuriale : https://ngneaotxxvwfbwwdqiqz.supabase.co/storage/v1/object/public/ressources/template-fiche-technique.xlsx
- Menu engineering : https://onrush.fr/downloads/menu-engineering-onrush.xlsx
- Page du guide « coût matière » : https://www.guide-foodtruck.com/ressources/menu/
Ces classeurs contiennent des formules ; contrôlez-les avec vos chiffres avant de décider.

## 3. Action finale
Choisissez **une** offre. Pesez cinq portions réellement servies, relevez le prix de chaque composant sur votre dernière facture et remplissez la fiche. Notez la date.

## 4. Trois arbitrages à examiner
1. Faut-il garder une offre qui laisse peu d'euros par vente mais attire les familles ?
2. Un pain ou un accompagnement plus cher se justifie-t-il par la qualité que vous voulez servir ?
3. Quel essai lancer pendant deux services : une description différente, un prix ou une taille de portion ? Un seul à la fois.

Si vous voulez en discuter avec un restaurateur, Cyril Quesnel peut examiner ces arbitrages avec vous. Le kit se suffit à lui-même.
