# Sources : carte et coûts

Date de consultation : 10 novembre 2026.

## 1. Beth Egan (Penn State), « 2.06 Menu Analysis (Engineering) »
- **Livre :** *Introduction to Food Production and Service*, Workforce LibreTexts, CC BY 4.0, remix du manuel BC Cook Articulation Committee.
- **URL :** https://workforce.libretexts.org/Bookshelves/Food_Production_Service_and_Culinary_Arts/Introduction_to_Food_Production_and_Service_(Egan)/02%3A_Menus_and_Recipes/2.06%3A_Menu_Analysis_(Engineering)
- **Lu :** la page de cette section, ouverte le 10 nov. 2026.
- **Retenu :** la contribution est le prix moins le coût standard ; on la croise avec la popularité de chaque plat.
- **Limite :** exemples en dollars, pédagogiques. L'auteure rappelle que les moyennes laissent toujours des plats en dessous et que le coût calculé suppose des portions idéales. Aucun résultat mesuré chez Cyril.

## 2. Sheryl Kimes / eCornell, « Menu Design and Engineering »
- **Auteure :** Sheryl Kimes, professeure émérite, Cornell Nolan School of Hotel Administration.
- **URL :** https://ecornell.cornell.edu/corporate-programs/courses/hospitality-and-foodservice-management/menu-design-and-engineering/
- **Lu :** la page de présentation (aperçu du cours, auteure). Le cours lui-même n'a pas été suivi ; la page n'affiche pas de prix.
- **Retenu :** rentabilité et volume se lisent ensemble, puis nom, description et mise en avant.
- **Limite :** présentation, pas méthode complète ni résultat. Aucun gain annoncé.

## 3. BC Cook Articulation Committee / BCcampus : The Principles of Menu Engineering
- URL : https://opentextbc.ca/basickitchenandfoodservicemanagement/chapter/describe-the-principles-of-menu-engineering/
- Lu : chapitre HTML, sections coût matière, contribution et choix de l’objectif, le 10 novembre 2026.
- Retenu : comparer le coût d’une portion, les euros laissés par vente et les ventes observées ; ne pas imposer un pourcentage matière identique à tous les établissements.
- Limite : exemples pédagogiques canadiens, pas des normes françaises.

## 4. BC Cook Articulation Committee / BCcampus : Monthly Food Costs
- URL : https://opentextbc.ca/basickitchenandfoodservicemanagement/chapter/monthly-food-costs/
- Lu : chapitre HTML le 10 novembre 2026.
- Retenu : distinguer les achats de la consommation corrigée des stocks ; signaler les ajustements nécessaires selon les usages et transferts.
- Limite : même période et même périmètre pour les coûts et les ventes comparés.

## Outils complémentaires de Cyril
- Guide Food Truck, carte et coût matière : https://www.guide-foodtruck.com/ressources/menu/
- Fiche technique et mercuriale Onrush : https://ngneaotxxvwfbwwdqiqz.supabase.co/storage/v1/object/public/ressources/template-fiche-technique.xlsx
- Les classeurs sont des supports à renseigner et vérifier avec vos chiffres. Une donnée manquante ne devient pas zéro ; le ratio global ne se calcule pas par une moyenne simple des pourcentages des plats.
