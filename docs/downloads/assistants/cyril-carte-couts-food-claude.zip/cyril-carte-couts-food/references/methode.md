# Méthode : chiffrer une carte à partir d'une préparation commune

## Le principe en une phrase
Une même préparation peut nourrir plusieurs offres. On chiffre chaque offre séparément, on regarde ce qu'elle laisse en euros par vente, puis on décide d'un essai plutôt que d'un grand changement.

## D'où vient la méthode
- Beth Egan (Penn State, remix d'un manuel libre) : le coût d'une portion est la somme de ses composants. Le pourcentage matière est le coût des ingrédients divisé par le prix de vente ; nous y ajoutons l'emballage dans une ligne distincte, « coûts variables retenus ». La **contribution** est le prix moins ce coût. Un plat est comparé sur sa contribution et sur sa popularité (part des ventes). Le manuel prévient : les moyennes laissent toujours des plats « en dessous », et le calcul en amont suppose des portions idéales et une vente complète.
- Sheryl Kimes (Cornell, page de présentation d'un cours) : rentabilité et volume se regardent ensemble, puis on travaille le nom, la description et la place des plats sur la carte. Cette page annonce un cadre ; elle ne démontre aucun gain.

Ces méthodes sont celles de tiers. Elles ne prouvent pas un résultat chez Cyril.

## Le cas vécu par Cyril (déclaré, non chiffré ici)
À la reprise du Lunch Wagon, Cyril jugeait les marges trop faibles pour le fait maison. Il a revu carte, formules et prix. Son exemple : des aiguillettes de poulet frais panées avec des cornflakes, servies en formule enfant, en tapas et en burger. Il cite 15 à 20 kg de tenders lors de certains événements du soir ; le contexte exact est inconnu, donc aucune conversion en portions ou en bénéfice n'est faite. À La Verrerie, il proposait un menu du midi à 15 € (entrée + plat ou plat + dessert) et réutilisait un produit dans plusieurs recettes pour éviter la perte. « Zéro perte » est son objectif, pas un résultat mesuré.

## Les choix et leurs compromis
- **Une fiche par offre, pas une fiche pour tout le lot.** Plus de saisie, mais on voit quelle offre pèse sur le pain, la sauce ou l'emballage.
- **Contribution plutôt que pourcentage seul.** Un burger à pourcentage matière plus élevé peut laisser plus d'euros par vente. Contrepartie : il demande plus de travail et de place sur la plancha ; le calcul ne le dit pas.
- **Prix du pain à part.** Cyril refuse un pain à 0,50 € qui dégraderait la qualité : c'est un choix de positionnement, pas un minimum universel. L'assistant montre l'effet d'un autre pain sur la contribution, la décision reste au pro.
- **Un essai à la fois.** Changer prix, nom et position le même jour empêche de savoir ce qui a joué.

## En situation
Avant un service ou un événement : pesez la portion réellement servie, relevez le prix facturé du jour, notez les restes. Après : comparez ventes et restes à la fiche. Si l'écart est net, corrigez la fiche avant de corriger le prix.

## Ce qu'on évite
- Annoncer un « bon » pourcentage matière : aucun seuil ne vaut pour tous.
- Confondre contribution et bénéfice : le personnel, les charges et les pertes n'y sont pas.
- Retirer un plat parce qu'il est sous la moyenne : voir ses ventes, son rôle dans la carte et le travail qu'il demande.
- Utiliser un prix sans date ou un grammage deviné.
