---
name: cyril-devis-food
description: "Prépare fiche de demande, réponse aux infos manquantes, relance et suivi pour devis traiteur ou food truck ; calcul déterministe, validation humaine avant envoi."
---

# Demandes client et devis food

## Objectif
Passer d'une demande de client à un devis exact, sans aller-retour inutile, avec une décision humaine avant tout envoi. Aucun workflow n'est activé par ce skill : il prépare des textes, une grille et un protocole d'essai.

## Ce qu'il faut avoir
Les offres déjà définies (menus, niveaux, options, prix). Si elles manquent, aide à préciser la prestation et prépare les questions utiles. Ne rends pas le kit dépendant d’un autre skill installé ; le kit offres est un complément facultatif. Demande aussi les conditions validées (acompte, délai de validité, annulation, zone de déplacement). Ne les invente jamais ; une condition absente reste « à confirmer ».

## Workflow
1. **Fiche de demande** (`assets/kit.md`) : occasion, date, lieu, nombre de convives, contraintes alimentaires, budget indicatif, contact. Commence par ces points ; ajoute les questions propres à l'occasion (menu enfants pour un anniversaire, horaires pour une entreprise).
2. **Tri de la demande reçue** : classe chaque champ en *complet*, *manquant* ou *à confirmer*. Un sous-total des seules lignes connues peut être calculé et nommé comme tel. Ne le présente pas comme un total final ni un devis ferme tant que les entrées, la disponibilité, la logistique et les conditions restent à confirmer.
3. **Accusé de réception et réponse aux infos manquantes** : deux modèles (demande complète, demande incomplète) ; ne promets pas d'envoi de devis avant d'avoir vérifié disponibilité et coûts. Message court, une seule liste de questions, ton humain, sans jargon.
4. **Calcul déterministe** : quantité × prix validé, ligne par ligne, avec options ; précise HT ou TTC. Écris les entrées utilisées ; si une entrée manque, écris « manquant » et n'extrapole pas. L'IA présente le calcul ; les prix viennent de ta liste.
5. **Brouillon de devis et de message** : montre convives, menu, options, montants et conditions tirés des données validées.
6. **Validation humaine** : le professionnel relit, corrige, puis envoie lui-même. Prévois aussi le cas du refus : on ne chiffre pas, on propose une alternative ou on demande une précision.
7. **Relance convenue** : à la date que le professionnel a fixée, après avoir vérifié le statut (réponse déjà reçue ? devis lu ?). Nombre et rythme de relances décidés par lui, sans imposer de règle unique. Respecte les règles de contact (ne transforme pas une demande de devis en accord pour des promotions).
8. **Suivi** : tableau de statuts (reçue, infos demandées, devis préparé, envoyé, accepté, refusé, relancé).

## Circuit vécu de Cyril (déclaré, non mesuré)
Formulaire → n8n → devis Pennylane → brouillon Gmail → validation de Cyril → envoi. Il dit y avoir passé environ trois mois. Aucun temps gagné ni taux de transformation n'est établi. Un client peut utiliser une autre chaîne (tableur, mail) : le skill ne dépend d'aucun outil.

## Essais avant d'activer quoi que ce soit
Teste trois cas : demande complète, demande sans lieu ou sans convives, et refus du brouillon. Vérifie ce que reçoit le professionnel.

## Contrôles
- Aucun prix, délai ou disponibilité inventé.
- Allergènes et quantités validés par le professionnel.
- Aucun envoi automatique sans accord explicite.

## Consultation humaine (seulement si utile)
Si les conditions (acompte, annulation, déplacement) ou la logique de prix restent à trancher, un échange avec Cyril est possible. Le skill reste utilisable sans.

## Fichiers liés
`references/methode.md` · `references/sources.md` · `assets/kit.md` (sortie publique en vouvoiement)
