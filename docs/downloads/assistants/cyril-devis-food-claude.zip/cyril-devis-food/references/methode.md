# Méthode : du formulaire au devis relu

## Les deux références
**Documentation n8n, Form Trigger.** Un formulaire peut démarrer un parcours automatique avec ses données. Le site distingue l'URL d'essai de l'URL de production : en essai, on voit les données dans l'éditeur ; en production, elles sont dans l'historique des exécutions. Chaque champ peut être rendu obligatoire. On peut aussi choisir de répondre tout de suite ou après la fin du parcours.

**Documentation n8n, validation humaine.** Avant une action sensible (envoyer un message, modifier une donnée), le parcours peut s'arrêter, montrer l'action, puis suivre la décision humaine. En cas de refus, l'action est annulée et le système doit savoir quoi faire ensuite.

Ce sont des documents d'éditeur : ils expliquent comment l'outil fonctionne, ils ne prouvent pas qu'une chaîne marche chez vous.

## Ce que Cyril raconte
Il avait des formulaires distincts pour anniversaires, entreprises et mariages, et son catalogue était en ligne. Il demandait notamment convives et menus enfants. La chaîne décrite : formulaire, n8n, devis Pennylane, brouillon Gmail, validation, envoi, avec des relances prévues et un bouton de rendez-vous. Il situe cet effort sur environ trois mois et dit que l'API Pennylane était alors récente.

Son constat : les clients veulent comprendre vite et recevoir une proposition claire. C'est son impression, pas une enquête.

## Choix et compromis
- **Offres d'abord, outil ensuite.** Un devis automatisé sur une offre floue produit des devis flous plus vite.
- **Peu de champs au départ.** Demandez l'essentiel pour décider si l'on peut répondre, puis complétez avec une réponse ciblée. Plus c'est long, plus on risque l'abandon : c'est une règle d'ergonomie, pas un chiffre.
- **Calcul déterministe.** Même entrée, même résultat : quantité × prix. L'IA ne devine pas un prix.
- **Humain avant l'envoi.** Un devis engage commercialement. La validation évite l'erreur de prix ou de disponibilité, sans la garantir.
- **Un outil adapté.** Pour Cyril, n8n ou Make sont des moyens : choisissez celui où vous êtes à l'aise et limitez le temps de formation.

## En situation
Demande reçue sans lieu : on ne présente pas de total final ; les lignes connues peuvent être présentées comme sous-total partiel et l'on envoie la réponse type. Demande avec convives mais sans menu enfants alors que c'est un anniversaire : on pose cette question. Refus du brouillon : on corrige ou on annule, sans envoi.

## Ce qu'on évite
- Activer un parcours avant d'avoir testé des cas incomplets.
- Annoncer des relances multiples ou agressives.
- Présenter des gains de temps non mesurés.
- Utiliser un contact de devis pour une campagne promotionnelle sans vérifier les règles.
