# Sources : devis et demandes (consultées le 10 novembre 2026)

## 1. n8n : n8n Form (Form Trigger)
- URL : https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.formtrigger
- Éditeur : n8n. Date non affichée.
- Lu : page de documentation HTML (URL d'essai/production, champ obligatoire, moment de la réponse).
- Retenu : un formulaire déclenche un parcours ; essayer avant de publier ; champs obligatoires choisis.
- Limite : documentation actuelle, aucun essai sur une instance ; ne prouve rien sur Pennylane/Gmail ni sur la version utilisée par Cyril.

## 2. n8n : Human-in-the-loop for tools
- URL : https://docs.n8n.io/build/integrate-ai/ai-examples/human-in-the-loop-for-tools.md
- Éditeur : n8n. Date non affichée.
- Lu : page de documentation (approbation/refus, outils concernés, gestion du refus). Documentation uniquement.
- Retenu : mettre en pause avant une action sensible, montrer ses paramètres, prévoir le refus.
- Limite : fonction actuelle, pas forcément celle de l'époque de Cyril ; une approbation ne garantit pas l'exactitude des prix.
