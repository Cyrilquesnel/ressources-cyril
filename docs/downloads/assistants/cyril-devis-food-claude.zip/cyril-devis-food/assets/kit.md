# Kit : de la demande au devis

Exemple **fictif**, sans lien avec une activité réelle de Cyril. Prix indicatifs en € HT (hors taxes) ; indiquez toujours si votre prix est HT ou TTC.

## 1. Démonstration
Demande de « Julie », anniversaire.

| Champ | Reçu | Statut |
|---|---|---|
| Occasion | Anniversaire 40 ans | complet |
| Date | 14 juin | complet |
| Lieu | « chez moi » | à confirmer (adresse) |
| Convives | 30 adultes, quelques enfants | manquant (nombre d'enfants) |
| Allergies | rien indiqué | à confirmer |
| Formule | Formule 2 | complet |

Calcul : 30 adultes × 28 € HT = 840 € HT ; menu enfants × ? = manquant. **Total non calculé** tant que le nombre d'enfants manque.

## 2. Fiche de demande à copier
Occasion : mariage / anniversaire / entreprise / autre · Date et horaires · Lieu (adresse, accès) · Convives (adultes / enfants) · Formule souhaitée · Contraintes alimentaires · Contact.
Champs nécessaires : occasion, date, lieu, convives, contact. Questions conditionnelles : menu enfants pour un anniversaire, horaires de livraison pour une entreprise, accès et électricité si installation sur place.

## 3. Modèle A : accusé de réception (demande complète)
« Bonjour [prénom], merci pour votre demande du [date]. Elle est complète. Nous vérifions notre disponibilité et nos coûts, puis nous revenons vers vous avant le [date convenue] avec une proposition. »

## 4. Modèle B : informations manquantes
« Bonjour [prénom], merci pour votre demande. Pour établir votre devis, il nous manque : [liste]. Pouvez-vous nous les confirmer ? »

## 5. Relance
À la date convenue avec le professionnel, après vérification du statut (déjà répondu ? devis lu ?) : « Bonjour [prénom], je reviens vers vous au sujet de votre devis du [date]. Souhaitez-vous des précisions ? » Nombre et rythme des relances : à décider, voir question 2.

## 6. Suivi
Reçue → infos demandées → disponibilité vérifiée → devis préparé → relu → envoyé → accepté / refusé / relancé, avec la date de chaque étape.

## 7. Calcul
Ligne = quantité × prix validé ; options séparées ; total = somme. Si une entrée manque, écrire « manquant ».

## 8. Contrôle avant envoi
Date, lieu, convives confirmés · prix issus de la liste validée, avec HT/TTC · allergènes vérifiés · conditions écrites seulement si décidées · envoi fait par le professionnel.

## 9. Action finale
Testez trois demandes : complète, sans lieu, brouillon refusé. Notez ce que vous recevez et ce qui reste flou.

## 10. Trois questions à arbitrer
1. Quel acompte et quel délai de validité ? (à confirmer avant de les écrire)
2. Quand relancer, combien de fois, ou pas du tout ?
3. Quelle demande refuser ou rediriger (date prise, zone trop éloignée) ?

## 11. Résultat opérationnel
Une fiche, deux modèles de réponse, une relance et un tableau de suivi utilisables dès aujourd'hui. Les prix viennent de vos offres ; tout envoi reste validé par vous.
