# Sources : offres food (consultées le 10 novembre 2026)

## 1. Alex Hormozi / Acquisition.com : Offer Creation Checklist
- URL : https://www.acquisition.com/files/offer-creation-checklist.pdf (page du cours : https://www.acquisition.com/training/offers5)
- Lu : texte du PDF (pages sur les composantes de l'offre et le « Delivery Cube »). La page du cours ne contenait que le menu. Ni livre ni vidéo.
- Retenu : partir du résultat voulu, lister les obstacles, comparer des solutions selon leur valeur et leur coût, varier le niveau d'effort du client.
- Limite : méthode d'auteur, pas une preuve en restauration. PDF protégé : lien seulement.

## 2. Acquisition.com : Bonus Creation Checklist
- URL : https://www.acquisition.com/hubfs/Offer%20Checklists%20-%20PDF%20Downloads/Bonus-Creation-Checklist.pdf?hsLang=en
- Lu : texte intégral des deux pages.
- Retenu : un complément utile répond au besoin suivant du client ; outils et listes réduisent son effort.
- Limite : le document recommande aussi rareté, urgence et valeur chiffrée : nous ne les reprenons pas. Pas d'affiliation supposée. PDF protégé : lien seulement.

## 3. Kurt Bostelaar / Strategyzer : How sales teams can create focused value for prospects with the Value Proposition Canvas
- URL : https://www.strategyzer.com/library/how-sales-teams-can-create-focused-value-for-prospects-with-the-value-proposition-canvas
- Date affichée : 29 octobre 2015.
- Lu : article HTML. Pas le livre Value Proposition Design.
- Retenu : profil par segment (tâches pratiques, émotionnelles, sociales), cibler les priorités plutôt que tout résoudre.
- Limite : outil de conception, ni prix de marché ni assurance de vente. Canvas protégé : modèle original dans nos fichiers.

## 4. Bercy Infos Entreprises : affichage des prix
- Titre : Professionnels, quelles sont vos obligations en matière d’affichage des prix ? Publication : 20 janvier 2026 ; consultation : 10 novembre 2026.
- URL : https://www.economie.gouv.fr/entreprises/gerer-son-entreprise-au-quotidien/gerer-un-commerce/professionnels-quelles-sont-vos-obligations-en-matiere-daffichage-des-prix
- Lu : sections « règles générales » et « prestations de services » du HTML officiel.
- Retenu : informer le consommateur du prix TTC et des frais avant la vente ; distinguer les options payantes et obtenir son choix explicite.
- Limite : cette page ne détermine aucun taux de TVA applicable à votre prestation.
