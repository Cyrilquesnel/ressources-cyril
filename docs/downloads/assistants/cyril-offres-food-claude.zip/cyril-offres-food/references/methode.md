# Méthode : construire une offre food sans la gonfler

## D'où viennent les idées
Trois lectures, adaptées à la restauration. Elles sont des méthodes d'auteurs, elles ne prouvent aucun résultat chez Cyril ni chez vous.

**1. Partir du résultat voulu (Hormozi / Acquisition.com).** La checklist invite à nommer le résultat rêvé du client, lister ce qui peut l'en empêcher, puis chercher des solutions et garder celles qui valent leur coût. Chez nous : un organisateur de mariage veut un repas qui se déroule sans qu'il y pense. Les obstacles : l'installation, la vaisselle, le service, le nettoyage, la coordination. Chaque composante doit être faisable et chiffrable.

**2. Compléter sans surcharger.** La même source parle de compléments qui répondent au besoin suivant du client. Nous gardons l'idée, pas les tactiques de rareté, d'urgence ou de valeur affichée gonflée : ici, une option est soit payante, soit réellement offerte, avec son coût.

**3. Comparer les clients (Strategyzer).** Ne pas supposer la même proposition pour tous : on décrit ce que chaque segment cherche (pratique, émotionnel, social) et on relie l'offre à ses priorités principales.

## Ce qu'on fait en situation
- **Entreprise** : hypothèse à vérifier : horaires et déroulé comptent le plus. On clarifie l'heure de service, le nombre de convives, l'accès au lieu.
- **Mariage** : hypothèse : l'expérience et la sérénité priment. On détaille le déroulé et qui fait quoi.
- **Anniversaire** : hypothèse : adultes et enfants n'ont pas les mêmes attentes. Menu enfants et format adapté.

## Le vécu de Cyril à garder en tête (déclaré, non mesuré)
Au Lunch Wagon, il avait des formulaires distincts pour anniversaires, entreprise et mariages, et un catalogue d'offres et de packs en ligne. Une même préparation pouvait servir plusieurs formules (ses aiguillettes de poulet : formule enfant, tapas, burger). Il avancerait aujourd'hui les prestations privées sur devis et le brasero, pour le spectacle devant les invités. Aucun gain démontré par ces choix.

## Choix et compromis
- **Une offre ou plusieurs ?** Une offre claire suffit quand les besoins sont proches. Plusieurs niveaux seulement si le service change vraiment ; sinon on complique la décision du client.
- **Options payantes ou incluses ?** Une option coûte du temps ou de l'argent (transport, vaisselle, personnel). L'inclure sans calcul grignote le reste après matières.
- **Spectacle ou simplicité ?** Un brasero marque les esprits, mais demande place, sécurité et personnel. Vérifiez ce qui est permis sur le lieu.

## Ce qu'on évite
- Inventer des prix, des partenariats, une commission ou une rareté.
- Confondre « reste après matières » et bénéfice net.
- Copier le catalogue d'un concurrent.
- Promettre un chiffre d'affaires.
- Redistribuer les PDF de l'auteur : lisez-les à la source.
