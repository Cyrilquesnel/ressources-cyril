# Kit : trois cartes d'offre prêtes à adapter

Les cartes ci-dessous sont des **exemples fictifs**, sans lien avec une activité réelle de Cyril. Remplacez chaque [crochet] par vos données validées. Si une donnée manque, laissez « à compléter » : ne la devinez pas.

## Carte 1 : Mariage, expérience brasero
**Promesse :** vos invités voient cuire leur repas devant eux et vous profitez de la soirée.
**Inclus :** menu en [nombre] temps, cuisson au brasero, mise en place, service, remise en état des lieux.
**Mode de service (à choisir selon votre capacité) :** *buffet autonome* (vous installez, les invités se servent, peu de personnel) ou *service avec équipe* ([nombre] personnes, service à l'assiette ou au passage). Le second demande plus de monde : n'annoncez que ce que votre équipe peut tenir.
**Options :** vaisselle et retour · personnel supplémentaire · installation/démontage · transport hors zone · décoration (seulement avec un prestataire réel).
**Prochaine étape :** envoyer date, lieu, nombre de convives ; vérification de disponibilité et de coûts avant devis.
**Prix client :** [prix TTC validé] € TTC par personne ; prix global pour [nombre] convives : [montant TTC validé] €. Options : [prix TTC validé] € chacune, listées une par une.

## Carte 2 : Entreprise, cocktail et finger food
**Promesse :** un buffet de bouchées prêt à l'heure, sans mobiliser vos équipes.
**Inclus :** [nombre] pièces par personne, livraison ou installation, [durée] de service.
**Mode de service :** buffet autonome (dépose et reprise) ou service avec équipe.
**Options :** boissons · vaisselle · personnel · matériel de réchauffe · horaire de reprise.
**Prochaine étape :** confirmer horaires, lieu, accès et nombre de convives.
**Prix client :** [prix TTC validé] € TTC par personne ; prix global pour [nombre] convives : [montant TTC validé] €. Options : [prix TTC validé] € chacune.

## Carte 3 : Anniversaire, adultes et enfants
**Promesse :** un menu pour les adultes et un format simple pour les enfants.
**Inclus :** formule adultes, menu enfants, mise en place.
**Options :** gâteau (prestataire réel) · vaisselle · personnel · installation.
**Prochaine étape :** indiquer nombre d'adultes et d'enfants, contraintes alimentaires, lieu.
**Prix client :** adultes [prix TTC validé] € TTC, enfants [prix TTC validé] € TTC ; prix global : [montant TTC validé] €. Options : [prix TTC validé] € chacune.

**Affichage du prix au client :** les cartes ci-dessus montrent un prix TTC, un prix global et des options claires. Vos calculs internes en HT restent séparés, ci-dessous. Ne reprenez aucun taux de TVA sans l'avoir vérifié pour votre activité. Voir la note de source en fin de kit.

## Exemple chiffré pour le professionnel (FICTIF, base HT)
Mariage, 60 convives, buffet autonome. Montants inventés pour illustrer la méthode.

| Ligne | Montant HT |
|---|---|
| Matières premières | 840 € |
| Main-d'œuvre (heures × taux réel) | 540 € |
| Transport | 90 € |
| Prix proposé (60 × 55 €) | 3 300 € |
| Reste après les seuls coûts renseignés | 1 830 € |

Ce n'est **pas** une marge complète. **Coûts manquants à ajouter :** pertes, carburant et amortissement du matériel, assurance, énergie (gaz du brasero), frais de structure, temps de préparation et de gestion, vaisselle si louée, charges sociales et impôts. Vérifiez allergènes, grammages et rendements avant tout prix.

## Action finale
Choisissez une carte, remplacez les crochets avec vos coûts réels et décidez : buffet autonome ou service avec équipe.

## Trois questions à arbitrer
1. Buffet autonome ou service avec équipe : lequel votre capacité permet-elle vraiment ?
2. Chaque option doit-elle être incluse ou payante, vu son coût ?
3. Votre prix par personne couvre-t-il tous les coûts, y compris ceux de la liste ci-dessus ?

## Référence pour présenter les prix au consommateur
Page Bercy « Professionnels : quelles sont vos obligations en matière d'affichage des prix » : https://www.economie.gouv.fr/entreprises/gerer-son-entreprise-au-quotidien/gerer-un-commerce/professionnels-quelles-sont-vos-obligations-en-matiere-daffichage-des-prix. Sections « règles générales » et « prestations de services », consultées le 10 novembre 2026. Elles précisent le prix TTC, l’information préalable sur les frais et le choix explicite des options payantes. Le kit ne détermine aucun taux de TVA.

## Résultat opérationnel
Une carte par occasion, des options chiffrées et une décision écrite. Si vos arbitrages restent bloqués, un échange avec Cyril est possible. Le kit reste utilisable de façon autonome.
