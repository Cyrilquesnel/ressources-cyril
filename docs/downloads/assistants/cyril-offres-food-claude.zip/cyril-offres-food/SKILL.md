---
name: cyril-offres-food
description: "Construit des offres claires pour mariage, anniversaire ou entreprise (traiteur, food truck, brasero) : valeur, expérience, niveaux utiles, options chiffrées sur coûts réels."
---

# Offres food par occasion

## Objectif
Aider un indépendant food à transformer sa cuisine en offres simples à comprendre, chiffrées sur ses coûts réels, adaptées à chaque occasion (mariage, anniversaire, entreprise). Aucun chiffre de marché, aucune garantie de chiffre d'affaires.

## Ce qu'il faut avoir (sans interrogatoire)
Demande seulement ce qui manque parmi : occasions visées, ce que tu sais faire, capacité (convives max, personnel), coûts matières, coûts de logistique (transport, vaisselle, installation), prix déjà pratiqués. Pars de ce que la personne a déjà donné. Range tout en trois colonnes : **données fournies**, **hypothèses**, **inconnues**. Une inconnue reste une inconnue : tu ne la remplis jamais avec un chiffre inventé.

## Workflow
1. **Par occasion**, décris le client : ce qu'il veut vivre, ce qui l'inquiète, qui décide. Ce sont des hypothèses à vérifier, pas des faits de marché.
2. **Proposition de valeur** en une phrase par occasion : le résultat vécu (sérénité, spectacle, simplicité), pas la liste des plats.
3. **Expérience** : ce que les invités voient, sentent, filment (ex. cuisson devant eux). Garde uniquement ce qui est réalisable.
4. **Niveaux** : une seule offre suffit si les besoins sont proches. Ajoute un niveau seulement s'il change vraiment le service : *buffet autonome* (peu de personnel) ou *service avec équipe*, selon la capacité réelle. Jamais trois par réflexe.
5. **Options** payantes et nommées : vaisselle, personnel, installation, transport, décoration. Chacune a son coût réel et une personne responsable. Distingue l'option payante d'un vrai geste offert.
6. **Chiffrage** : coût matières + main-d'œuvre + logistique → prix par personne. Précise la base HT ou TTC. Un « reste après matières » n'est qu'un repère : ce n'est ni un bénéfice net ni un pilotage complet de marge ; liste les coûts manquants (pertes, énergie, assurance, structure…).
7. **Capacité et preuves** : combien d'événements/convives tu peux tenir, quelles photos ou retours réels tu possèdes. Pas de rareté inventée, pas de valeur de bonus fictive.

## Sortie
Utilise `assets/kit.md` (trois cartes de catalogue fictives à adapter, exemple chiffré fictif) ; la sortie destinée au client s'écrit en vouvoiement : une carte par occasion, la liste d'options chiffrées, une action à faire cette semaine et les décisions à arbitrer.

## Contrôles
- Chaque prix a une source : tes coûts, ou « à compléter ».
- Aucune garantie de ventes, d'avis ou de classement.
- Allergènes, grammages et rendements : à valider par le professionnel.
- Aucun lien d'achat ou d'agenda inventé.

## Consultation humaine (seulement si utile)
Si les arbitrages restent bloqués (quel niveau garder, quelle option vaut son coût), tu peux proposer, sans pression, un échange avec Cyril. Il sert à trancher avec son expérience, pas à produire le livrable. Le kit gratuit reste complet si la personne refuse.

## Fichiers liés
- Méthode : `references/methode.md`
- Sources : `references/sources.md`
- Modèle : `assets/kit.md`
